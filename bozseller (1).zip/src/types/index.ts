export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'NGN' | 'JPY' | 'CAD' | 'AUD';

export interface Currency {
  code: CurrencyCode;
  symbol: string;
  name: string;
  rateToUsd: number; // e.g., 1 USD = 1500 NGN
}

export interface Product {
  id: string;
  title: string;
  description: string;
  priceUsd: number;
  category: string;
  sellerId: string;
  sellerName: string;
  sellerRating: number;
  stock: number;
  imageUrl: string;
  encryptedProductSignature: string;
  countryOfOrigin: string;
  shippingWeightKg: number;
  tags: string[];
  createdAt: string;
  isVerifiedVendor?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type CarrierCode = 'dhl' | 'fedex' | 'ups' | 'standard';

export interface CarrierQuote {
  code: CarrierCode;
  name: string;
  logo: string;
  estimatedDays: number;
  rateUsd: number;
  carbonFootprintKg: number;
  trackingPrefix: string;
}

export type PaymentGateway = 'stripe' | 'paystack' | 'flutterwave' | 'crypto_escrow';

export interface Order {
  id: string;
  buyerId: string;
  buyerEmail: string;
  buyerName: string;
  items: CartItem[];
  totalAmountUsd: number;
  currency: CurrencyCode;
  convertedTotal: number;
  paymentMethod: PaymentGateway;
  paymentStatus: 'paid' | 'pending' | 'escrowed' | 'refunded';
  shippingCarrier: CarrierCode;
  carrierName: string;
  shippingFeeUsd: number;
  trackingNumber: string;
  shippingAddress: string;
  destinationCountry: string;
  orderStatus: 'processing' | 'shipped' | 'in_transit' | 'delivered' | 'disputed' | 'cancelled';
  encryptedReceiptHash: string;
  encryptedSecurityKey: string;
  createdAt: string;
  updatedAt: string;
}

export interface SellerProfile {
  id: string;
  userId: string;
  storeName: string;
  country: string;
  verificationStatus: 'approved' | 'pending' | 'suspended';
  encryptedPayoutAccount: string;
  totalEarningsUsd: number;
  rating: number;
  totalOrdersFulfilled: number;
  createdAt: string;
}

export interface Dispute {
  id: string;
  orderId: string;
  buyerId: string;
  buyerEmail: string;
  sellerId: string;
  reason: string;
  evidenceText: string;
  encryptedLogSignature: string;
  status: 'open' | 'resolved_buyer' | 'resolved_seller' | 'under_review';
  aiArbitrationSummary?: string;
  suggestedActionText?: string;
  createdAt: string;
}

export interface Review {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  verifiedPurchase: boolean;
  createdAt: string;
}

export interface AIListingEnhancement {
  enhancedTitle: string;
  category: string;
  enhancedDescription: string;
  bulletPoints: string[];
  tags: string[];
  multilingualSnippets: {
    es?: string;
    fr?: string;
    de?: string;
  };
  suggestedHsCode: string;
  complianceNotice: string;
}

export interface AICustomsAnalysis {
  originCountry: string;
  destinationCountry: string;
  estimatedDutyPercentage: number;
  estimatedDutyAmountUsd: number;
  suggestedHsCode: string;
  requiresImportPermit: boolean;
  restrictedCategory: boolean;
  requiredDocs: string[];
  regulatoryNotes: string;
}

export interface AIDisputeArbitration {
  recommendation: 'refund_buyer' | 'release_seller' | 'partial_refund';
  confidenceScore: number;
  decisionSummary: string;
  suggestedActionText: string;
  auditFlags: string[];
}

export interface AIComplianceReport {
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  riskScore: number;
  flaggedReason: string;
  recommendedAction: 'APPROVE' | 'MANUAL_HOLD' | 'REQUEST_KYC_DOCS' | 'FREEZE_ESCROW';
  auditDetails: string[];
  sanctionsCheckPassed: boolean;
}

export type GovernmentIdType = 'passport' | 'drivers_license' | 'national_id' | 'tax_id';
export type KycVerificationStatus = 'not_submitted' | 'pending_verification' | 'approved' | 'rejected';

export interface SellerKycData {
  id: string;
  sellerId: string;
  sellerName: string;
  email: string;
  phone: string;
  country: string;
  governmentIdType: GovernmentIdType;
  idNumber: string;
  documentEncryptedHash: string;
  kycStatus: KycVerificationStatus;
  aiKycScore?: number;
  aiKycNotes?: string;
  submittedAt: string;
  approvedAt?: string;
}

export interface AISellerKycReport {
  aiScore: number;
  isDocAuthentic: boolean;
  tamperDetected: boolean;
  verificationNotes: string;
  recommendedStatus: 'APPROVED' | 'FLAGGED_FOR_MANUAL_REVIEW' | 'REJECTED';
  flags: string[];
}
