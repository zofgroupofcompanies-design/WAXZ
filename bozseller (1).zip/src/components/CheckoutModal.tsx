import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, ShieldCheck, Truck, CreditCard, Lock, CheckCircle2, ChevronRight, 
  MapPin, Phone, User, Building, AlertCircle, Loader2, Sparkles
} from 'lucide-react';
import { Listing, CourierQuote, PaymentGatewayType, Order } from '../types';
import { CurrencyCode, CURRENCIES, formatConvertedPrice } from '../utils/currency';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  listing: Listing;
  selectedCurrency?: CurrencyCode;
  onOrderCompleted?: (order: Order) => void;
}

export default function CheckoutModal({
  isOpen,
  onClose,
  listing,
  selectedCurrency = 'GHS',
  onOrderCompleted
}: CheckoutModalProps) {
  const [quantity, setQuantity] = useState(1);
  const [buyerName, setBuyerName] = useState(() => {
    const saved = localStorage.getItem('datazone4_user');
    if (saved) {
      try { return JSON.parse(saved).name || ''; } catch (e) {}
    }
    return 'Kwame Mensah';
  });
  const [buyerEmail, setBuyerEmail] = useState(() => {
    const saved = localStorage.getItem('datazone4_user');
    if (saved) {
      try { return JSON.parse(saved).email || ''; } catch (e) {}
    }
    return 'buyer@datazone4.com';
  });
  const [buyerPhone, setBuyerPhone] = useState('+233 24 123 4567');
  const [destinationCountry, setDestinationCountry] = useState('Ghana');
  const [shippingAddress, setShippingAddress] = useState('Plot 14 East Legon, Accra, Ghana');

  // Courier Quotes state
  const [courierQuotes, setCourierQuotes] = useState<CourierQuote[]>([]);
  const [selectedCourier, setSelectedCourier] = useState<CourierQuote | null>(null);
  const [loadingQuotes, setLoadingQuotes] = useState(false);

  // Payment Gateway selection
  const [paymentGateway, setPaymentGateway] = useState<PaymentGatewayType>('paystack');
  const [momoNetwork, setMomoNetwork] = useState<'mtn' | 'telecel' | 'at'>('mtn');
  const [momoNumber, setMomoNumber] = useState('+233 24 123 4567');

  // Checkout process states
  const [isProcessing, setIsProcessing] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<'details' | 'payment_processing' | 'success'>('details');
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  // Fetch Courier Quotes when destination or listing changes
  useEffect(() => {
    if (!listing) return;
    setLoadingQuotes(true);
    fetch('/api/shipping/quote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        originCountry: listing.country || 'Ghana',
        destinationCountry,
        weightKg: 1.5,
        categoryName: listing.categoryName
      })
    })
      .then(res => res.json())
      .then((data: CourierQuote[]) => {
        setCourierQuotes(data);
        if (data.length > 0) {
          setSelectedCourier(data[0]);
        }
        setLoadingQuotes(false);
      })
      .catch(err => {
        console.error('Failed to calculate shipping quotes:', err);
        setLoadingQuotes(false);
      });
  }, [listing, destinationCountry]);

  if (!isOpen) return null;

  const itemTotal = listing.price * quantity;
  const shippingFee = selectedCourier ? selectedCourier.price : 0;
  const platformFee = Math.round(itemTotal * 0.05); // 5% marketplace escrow fee
  const grandTotal = itemTotal + shippingFee;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCourier) {
      alert('Please select a shipping delivery method.');
      return;
    }

    setIsProcessing(true);
    setCheckoutStep('payment_processing');

    const token = localStorage.getItem('datazone4_jwt_token');

    fetch('/api/orders/checkout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      },
      body: JSON.stringify({
        listingId: listing.id,
        listingTitle: listing.title,
        listingPrice: listing.price,
        listingImage: listing.imageUrls?.[0] || '',
        sellerId: listing.sellerId,
        sellerName: listing.sellerName,
        quantity,
        itemTotal,
        shippingFee,
        platformFee,
        totalAmount: grandTotal,
        currency: listing.country === 'Nigeria' ? 'NGN' : listing.country === 'Togo' ? 'XOF' : 'GHS',
        courier: selectedCourier.name,
        paymentGateway,
        buyerName,
        buyerEmail,
        buyerPhone,
        shippingAddress,
        destinationCountry
      })
    })
      .then(res => res.json())
      .then((data) => {
        setTimeout(() => {
          setIsProcessing(false);
          setCompletedOrder(data.order);
          setCheckoutStep('success');
          if (onOrderCompleted && data.order) {
            onOrderCompleted(data.order);
          }
        }, 1800);
      })
      .catch(err => {
        console.error('Order checkout error:', err);
        setIsProcessing(false);
        setCheckoutStep('details');
        alert('Failed to complete checkout payment. Please try again.');
      });
  };

  const currencySymbol = listing.country === 'Nigeria' ? '₦' : listing.country === 'Togo' ? 'CFA' : 'GH₵';

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[999] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden border border-gray-100 flex flex-col my-auto max-h-[90vh]"
        >
          {/* Header */}
          <div className="bg-[#291f17] text-white p-5 flex items-center justify-between border-b border-amber-900/40 shrink-0">
            <div className="flex items-center gap-3">
              <div className="bg-amber-500 text-green-950 p-2 rounded-xl">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black tracking-tight flex items-center gap-2">
                  <span>Escrow Checkout Protection</span>
                  <span className="text-[10px] bg-amber-400 text-green-950 font-black px-2 py-0.5 rounded-full uppercase">
                    100% Safe
                  </span>
                </h3>
                <p className="text-[11px] text-amber-200/80 font-medium">
                  Payment held in escrow until you receive and verify your package.
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="text-white/80 hover:text-white p-1.5 hover:bg-white/10 rounded-full transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Modal Body */}
          <div className="p-6 overflow-y-auto space-y-6 flex-1">
            {checkoutStep === 'payment_processing' ? (
              <div className="py-12 text-center flex flex-col items-center justify-center space-y-4">
                <Loader2 className="w-12 h-12 text-amber-600 animate-spin" />
                <h4 className="text-base font-black text-gray-800">
                  Connecting to {paymentGateway.toUpperCase()} Payment Gateway...
                </h4>
                <p className="text-xs text-gray-500 max-w-sm">
                  Verifying transaction token and locking funds in datazone4 escrow vault. Please do not close this window.
                </p>
              </div>
            ) : checkoutStep === 'success' && completedOrder ? (
              <div className="py-8 text-center flex flex-col items-center justify-center space-y-4">
                <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <div>
                  <h4 className="text-lg font-black text-gray-900">Order Successfully Placed!</h4>
                  <p className="text-xs text-gray-500 mt-1">
                    Order ID: <strong className="font-mono text-gray-800">{completedOrder.id}</strong>
                  </p>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-left w-full space-y-2 text-xs">
                  <div className="flex justify-between text-amber-900 font-bold">
                    <span>Courier Carrier:</span>
                    <span>{completedOrder.courier}</span>
                  </div>
                  <div className="flex justify-between text-amber-900 font-bold">
                    <span>Tracking Number:</span>
                    <span className="font-mono bg-white px-2 py-0.5 rounded border border-amber-300">{completedOrder.courierTrackingCode}</span>
                  </div>
                  <div className="flex justify-between text-amber-900 font-bold">
                    <span>Total Paid (Escrowed):</span>
                    <span>{currencySymbol} {completedOrder.totalAmount.toLocaleString()}</span>
                  </div>
                </div>

                <p className="text-xs text-gray-600 font-medium leading-relaxed">
                  The seller <strong className="text-gray-800">{completedOrder.sellerName}</strong> has been notified to package your item. Once delivered, click "Confirm Delivery" on your orders page to release funds.
                </p>

                <button
                  onClick={onClose}
                  className="w-full py-3 bg-[#3e3023] hover:bg-[#291f17] text-white font-black text-xs uppercase tracking-wider rounded-xl transition cursor-pointer shadow-md"
                >
                  Done & Close
                </button>
              </div>
            ) : (
              <form onSubmit={handlePlaceOrder} className="space-y-6">
                {/* Product Summary */}
                <div className="flex items-center gap-4 bg-gray-50 p-4 rounded-2xl border border-gray-100">
                  <img
                    src={listing.imageUrls?.[0] || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e'}
                    alt={listing.title}
                    className="w-16 h-16 object-cover rounded-xl border border-gray-200 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-black text-gray-900 truncate">{listing.title}</h4>
                    <p className="text-xs text-gray-500 font-semibold mt-0.5">
                      Seller: <strong className="text-gray-800">{listing.sellerName}</strong> • {listing.country || 'Ghana'}
                    </p>
                    <span className="text-sm font-black text-amber-800 mt-1 block">
                      {currencySymbol} {listing.price.toLocaleString()}
                    </span>
                  </div>

                  {/* Quantity selector */}
                  <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-2 py-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
                      className="px-2 py-0.5 font-black text-gray-600 hover:text-black cursor-pointer"
                    >
                      -
                    </button>
                    <span className="text-xs font-black text-gray-800 w-4 text-center">{quantity}</span>
                    <button
                      type="button"
                      onClick={() => setQuantity(prev => prev + 1)}
                      className="px-2 py-0.5 font-black text-gray-600 hover:text-black cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Delivery & Shipping Section */}
                <div className="space-y-3">
                  <h4 className="text-xs font-black text-gray-800 uppercase tracking-wider flex items-center gap-2">
                    <Truck className="w-4 h-4 text-amber-700" />
                    <span>Select Courier & Shipping Carrier</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-wider block mb-1">
                        Destination Country
                      </label>
                      <select
                        value={destinationCountry}
                        onChange={(e) => setDestinationCountry(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs font-bold text-gray-800"
                      >
                        <option value="Ghana">Ghana 🇬🇭</option>
                        <option value="Nigeria">Nigeria 🇳🇬</option>
                        <option value="Togo">Togo 🇹🇬</option>
                        <option value="United Kingdom">United Kingdom 🇬🇧</option>
                        <option value="United States">United States 🇺🇸</option>
                        <option value="Kenya">Kenya 🇰🇪</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-wider block mb-1">
                        Full Delivery Address
                      </label>
                      <input
                        type="text"
                        required
                        value={shippingAddress}
                        onChange={(e) => setShippingAddress(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-xs font-semibold text-gray-800"
                        placeholder="House no, Street, Region/State"
                      />
                    </div>
                  </div>

                  {/* Courier options */}
                  {loadingQuotes ? (
                    <div className="py-4 text-center text-xs text-gray-400 font-bold flex items-center justify-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-amber-600" />
                      <span>Calculating live courier delivery rates...</span>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {courierQuotes.map((c) => (
                        <div
                          key={c.id}
                          onClick={() => setSelectedCourier(c)}
                          className={`p-3 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                            selectedCourier?.id === c.id
                              ? 'border-amber-600 bg-amber-50/60 ring-2 ring-amber-500/20'
                              : 'border-gray-200 hover:border-gray-300 bg-white'
                          }`}
                        >
                          <div className="flex flex-col">
                            <span className="text-xs font-black text-gray-900 flex items-center gap-1.5">
                              {c.name}
                              {c.badge && (
                                <span className="text-[9px] bg-amber-200 text-amber-900 px-1.5 py-0.2 rounded font-extrabold uppercase">
                                  {c.badge}
                                </span>
                              )}
                            </span>
                            <span className="text-[10px] text-gray-500 font-semibold">{c.estimatedDays}</span>
                          </div>
                          <span className="text-xs font-black text-amber-800">
                            {currencySymbol} {c.price.toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Payment Provider Selection */}
                <div className="space-y-3">
                  <h4 className="text-xs font-black text-gray-800 uppercase tracking-wider flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-amber-700" />
                    <span>Choose Payment Method</span>
                  </h4>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {[
                      { id: 'paystack', label: 'Paystack', desc: 'Cards / MoMo' },
                      { id: 'flutterwave', label: 'Flutterwave', desc: 'Pan-Africa' },
                      { id: 'stripe', label: 'Stripe', desc: 'Intl Credit Cards' },
                      { id: 'momo', label: 'Mobile Money', desc: 'Ghana Direct' }
                    ].map((gate) => (
                      <button
                        type="button"
                        key={gate.id}
                        onClick={() => setPaymentGateway(gate.id as PaymentGatewayType)}
                        className={`p-3 rounded-xl border text-left cursor-pointer transition ${
                          paymentGateway === gate.id
                            ? 'border-amber-600 bg-amber-50/60 font-black'
                            : 'border-gray-200 hover:border-gray-300 bg-white'
                        }`}
                      >
                        <span className="text-xs font-black text-gray-900 block">{gate.label}</span>
                        <span className="text-[9px] text-gray-500 font-medium block">{gate.desc}</span>
                      </button>
                    ))}
                  </div>

                  {paymentGateway === 'momo' && (
                    <div className="p-3 bg-amber-50/60 border border-amber-200 rounded-xl grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] font-black text-gray-600 uppercase block mb-1">Network</label>
                        <select
                          value={momoNetwork}
                          onChange={(e) => setMomoNetwork(e.target.value as any)}
                          className="w-full bg-white border border-gray-200 rounded-lg p-2 text-xs font-bold"
                        >
                          <option value="mtn">MTN Mobile Money</option>
                          <option value="telecel">Telecel Cash</option>
                          <option value="at">AT Money</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-[10px] font-black text-gray-600 uppercase block mb-1">MoMo Number</label>
                        <input
                          type="text"
                          value={momoNumber}
                          onChange={(e) => setMomoNumber(e.target.value)}
                          className="w-full bg-white border border-gray-200 rounded-lg p-2 text-xs font-bold"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Price Breakdown */}
                <div className="bg-gray-50 p-4 rounded-2xl border border-gray-200/80 space-y-2 text-xs">
                  <div className="flex justify-between text-gray-600 font-semibold">
                    <span>Items ({quantity}x):</span>
                    <span>{currencySymbol} {itemTotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-gray-600 font-semibold">
                    <span>Shipping Delivery ({selectedCourier?.name || 'Selected'}):</span>
                    <span>{currencySymbol} {shippingFee.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-gray-600 font-semibold">
                    <span>Escrow Buyer Guarantee:</span>
                    <span className="text-green-700 font-bold">FREE</span>
                  </div>
                  <div className="border-t border-gray-200 pt-2 flex justify-between text-sm font-black text-gray-900">
                    <span>Grand Total:</span>
                    <span className="text-amber-800">{currencySymbol} {grandTotal.toLocaleString()}</span>
                  </div>
                </div>

                {/* Submit Checkout */}
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full py-3.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-black text-xs uppercase tracking-wider rounded-xl transition shadow-lg cursor-pointer flex items-center justify-center gap-2 transform active:scale-98"
                >
                  <Lock className="w-4 h-4" />
                  <span>Pay {currencySymbol} {grandTotal.toLocaleString()} & Lock Escrow</span>
                </button>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
