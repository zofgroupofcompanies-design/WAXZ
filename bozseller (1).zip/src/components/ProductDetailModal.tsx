import React, { useState } from 'react';
import { Product, CurrencyCode, Review, AICustomsAnalysis } from '../types';
import { formatPrice } from '../lib/currencies';
import { calculateCarrierQuotes } from '../lib/carriers';
import { calculateCustomsDutiesAi } from '../services/aiService';
import { X, Lock, Star, Truck, ShieldCheck, Sparkles, CheckCircle2, ShoppingBag, Globe, Loader2, MessageSquare } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product;
  activeCurrency: CurrencyCode;
  onClose: () => void;
  onAddToCart: (p: Product) => void;
  deliverToCountry: string;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  activeCurrency,
  onClose,
  onAddToCart,
  deliverToCountry,
}) => {
  const [selectedCountry, setSelectedCountry] = useState(deliverToCountry || 'United States');
  const [customsLoading, setCustomsLoading] = useState(false);
  const [customsData, setCustomsData] = useState<AICustomsAnalysis | null>(null);

  // Reviews State
  const [reviews, setReviews] = useState<Review[]>([
    {
      id: 'rev-1',
      productId: product.id,
      userId: 'usr-101',
      userName: 'Dr. Marcus Vance',
      rating: 5,
      comment: 'Exceptional build quality. Cryptographic receipt signature was verified successfully on the chain vault.',
      verifiedPurchase: true,
      createdAt: '2026-10-19',
    },
    {
      id: 'rev-2',
      productId: product.id,
      userId: 'usr-102',
      userName: 'Elena Rostova',
      rating: 5,
      comment: 'Shipped via DHL Express to Germany in 3 business days. Packaging and seller responsiveness were top tier.',
      verifiedPurchase: true,
      createdAt: '2026-10-15',
    },
  ]);
  const [newComment, setNewComment] = useState('');
  const [newRating, setNewRating] = useState(5);

  // Compute live carrier quotes
  const carrierQuotes = calculateCarrierQuotes(product.shippingWeightKg, selectedCountry);

  // Handle AI Customs Check
  const handleCheckCustoms = async () => {
    setCustomsLoading(true);
    try {
      const data = await calculateCustomsDutiesAi({
        productTitle: product.title,
        category: product.category,
        originCountry: product.countryOfOrigin,
        destinationCountry: selectedCountry,
        declaredValueUsd: product.priceUsd,
      });
      setCustomsData(data);
    } catch (e) {
      console.error(e);
    } finally {
      setCustomsLoading(false);
    }
  };

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    const rev: Review = {
      id: `rev-${Date.now()}`,
      productId: product.id,
      userId: 'usr-current',
      userName: 'Verified Buyer',
      rating: newRating,
      comment: newComment,
      verifiedPurchase: true,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setReviews([rev, ...reviews]);
    setNewComment('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8 relative flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="bg-emerald-500 text-slate-950 text-xs font-bold px-2 py-0.5 rounded flex items-center gap-1">
              <Lock className="w-3 h-3" /> 256-Bit Encrypted Listing
            </span>
            <span className="text-xs text-slate-400">ID: {product.id}</span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Left: Product Image & Technical Signatures */}
            <div className="space-y-4">
              <div className="aspect-[4/3] rounded-xl bg-slate-100 overflow-hidden border border-slate-200 relative">
                <img
                  src={product.imageUrl}
                  alt={product.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                {product.isVerifiedVendor && (
                  <span className="absolute top-3 left-3 bg-slate-950/90 text-emerald-400 text-xs font-bold px-2.5 py-1 rounded border border-emerald-500/40 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Verified Global Vendor
                  </span>
                )}
              </div>

              {/* Cryptographic Authenticity Box */}
              <div className="p-3.5 bg-slate-900 text-slate-300 rounded-xl border border-slate-800 text-xs space-y-2">
                <div className="flex items-center justify-between text-emerald-400 font-bold">
                  <span className="flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4" /> SHA-256 HMAC Authenticity Seal
                  </span>
                  <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-500/30">
                    VERIFIED
                  </span>
                </div>
                <p className="font-mono text-[11px] text-slate-400 bg-slate-950 p-2 rounded border border-slate-800 break-all">
                  {product.encryptedProductSignature}
                </p>
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>Origin: <strong className="text-white">{product.countryOfOrigin}</strong></span>
                  <span>Weight: <strong className="text-white">{product.shippingWeightKg} kg</strong></span>
                </div>
              </div>
            </div>

            {/* Right: Spec, Pricing, Carrier Calculator */}
            <div className="space-y-5">
              <div>
                <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">
                  {product.category}
                </span>
                <h1 className="text-2xl font-black text-slate-900 leading-tight mt-1">
                  {product.title}
                </h1>
                <div className="flex items-center gap-3 mt-2 text-xs text-slate-600">
                  <span>Vendor: <strong className="text-slate-900">{product.sellerName}</strong></span>
                  <span>·</span>
                  <div className="flex items-center gap-1 text-amber-500 font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>{product.sellerRating.toFixed(1)}</span>
                  </div>
                  <span>·</span>
                  <span className="text-emerald-600 font-semibold">{product.stock} units in stock</span>
                </div>
              </div>

              {/* Price Banner */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-500 block">Unit Price ({activeCurrency})</span>
                  <div className="text-3xl font-black text-slate-900 font-mono">
                    {formatPrice(product.priceUsd, activeCurrency)}
                  </div>
                </div>
                <button
                  onClick={() => onAddToCart(product)}
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-6 py-3 rounded-xl transition-all shadow-lg shadow-emerald-500/20 flex items-center gap-2"
                >
                  <ShoppingBag className="w-5 h-5" />
                  Add to Cart
                </button>
              </div>

              {/* Description */}
              <p className="text-sm text-slate-600 leading-relaxed">
                {product.description}
              </p>

              {/* Carrier Shipping Calculator */}
              <div className="p-4 bg-slate-900 text-white rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                    <Truck className="w-4 h-4" /> Live Carrier Logistics Quotes
                  </span>
                  <div className="flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5 text-slate-400" />
                    <select
                      value={selectedCountry}
                      onChange={(e) => setSelectedCountry(e.target.value)}
                      className="bg-slate-800 text-white text-xs px-2 py-1 rounded border border-slate-700"
                    >
                      <option value="United States">Dest: 🇺🇸 US</option>
                      <option value="United Kingdom">Dest: 🇬🇧 UK</option>
                      <option value="Germany">Dest: 🇩🇪 Germany</option>
                      <option value="Nigeria">Dest: 🇳🇬 Nigeria</option>
                      <option value="Japan">Dest: 🇯🇵 Japan</option>
                      <option value="Canada">Dest: 🇨🇦 Canada</option>
                      <option value="Australia">Dest: 🇦🇺 Australia</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  {carrierQuotes.slice(0, 2).map((q) => (
                    <div key={q.code} className="p-2 bg-slate-950 rounded border border-slate-800 flex flex-col justify-between">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white">{q.name}</span>
                        <span className="text-emerald-400 font-mono font-bold">{formatPrice(q.rateUsd, activeCurrency)}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 mt-1">Est. {q.estimatedDays} Business Days</span>
                    </div>
                  ))}
                </div>

                {/* AI Customs Check Action */}
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                  <button
                    onClick={handleCheckCustoms}
                    disabled={customsLoading}
                    className="text-xs bg-slate-800 hover:bg-slate-700 text-amber-300 px-3 py-1.5 rounded flex items-center gap-1.5 transition-colors font-medium"
                  >
                    {customsLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-amber-400" />}
                    AI Customs & Tariff Duty Advisor
                  </button>
                  {customsData && (
                    <span className="text-[11px] text-emerald-400 font-mono">
                      Duty: ~{customsData.estimatedDutyPercentage}% (${customsData.estimatedDutyAmountUsd})
                    </span>
                  )}
                </div>

                {customsData && (
                  <div className="p-2.5 bg-slate-950 rounded border border-amber-500/30 text-xs text-slate-300 space-y-1">
                    <p className="font-bold text-amber-400 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> HS Code: {customsData.suggestedHsCode}
                    </p>
                    <p className="text-[11px] text-slate-400">{customsData.regulatoryNotes}</p>
                    <div className="text-[10px] text-slate-500 flex flex-wrap gap-1 pt-1">
                      Docs Required: {customsData.requiredDocs.join(', ')}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Customer Reviews Section */}
          <div className="pt-6 border-t border-slate-200 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-emerald-600" />
              Verified Buyer Reviews ({reviews.length})
            </h3>

            {/* Write Review Form */}
            <form onSubmit={handleAddReview} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <span className="text-xs font-bold text-slate-700 block">Write a Verified Buyer Review</span>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button
                      type="button"
                      key={s}
                      onClick={() => setNewRating(s)}
                      className="p-0.5 focus:outline-none"
                    >
                      <Star
                        className={`w-4 h-4 ${
                          s <= newRating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
                <span className="text-xs text-slate-500 font-medium">{newRating} / 5 Stars</span>
              </div>
              <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Share your experience with product authenticity, carrier speed, and encrypted transaction security..."
                rows={2}
                className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              <button
                type="submit"
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors"
              >
                Submit Verified Review
              </button>
            </form>

            {/* Review List */}
            <div className="space-y-3">
              {reviews.map((rev) => (
                <div key={rev.id} className="p-3.5 bg-white rounded-xl border border-slate-200 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{rev.userName}</span>
                      {rev.verifiedPurchase && (
                        <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] px-1.5 py-0.5 rounded font-medium">
                          Verified Purchase
                        </span>
                      )}
                    </div>
                    <span className="text-slate-400 text-[11px]">{rev.createdAt}</span>
                  </div>
                  <div className="flex items-center gap-1 text-amber-400">
                    {Array.from({ length: rev.rating }).map((_, i) => (
                      <Star key={i} className="w-3 h-3 fill-amber-400" />
                    ))}
                  </div>
                  <p className="text-slate-600">{rev.comment}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
