import React, { useState, useEffect, useMemo } from 'react';
import { Heart, Search, Filter, ArrowUpDown, Trash2, ShoppingBag, Sparkles, SlidersHorizontal, Grid } from 'lucide-react';
import ListingCard from './ListingCard';
import { Listing } from '../types';
import { CurrencyCode, CURRENCIES } from '../utils/currency';
import { CATEGORIES } from '../data/mockData';

interface SavedAdsProps {
  favorites: string[];
  onToggleFavorite: (id: string) => void;
  onViewDetails: (id: string) => void;
  onInitiateChat: (listing: Listing) => void;
  selectedCurrency: CurrencyCode;
  onBrowseClick: () => void;
}

export default function SavedAds({
  favorites,
  onToggleFavorite,
  onViewDetails,
  onInitiateChat,
  selectedCurrency,
  onBrowseClick
}: SavedAdsProps) {
  const [savedListings, setSavedListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'price-asc' | 'price-desc' | 'popular'>('newest');

  // Fetch all active listings and filter down to favorited IDs
  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    fetch('/api/listings')
      .then(res => res.json())
      .then((data: Listing[]) => {
        if (isMounted) {
          const favoritedItems = data.filter(item => favorites.includes(item.id));
          setSavedListings(favoritedItems);
          setLoading(false);
        }
      })
      .catch(err => {
        console.error('Failed to load saved ads:', err);
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [favorites]);

  // Filtered and sorted listings
  const filteredListings = useMemo(() => {
    return savedListings
      .filter(item => {
        // Search filter
        if (searchQuery.trim()) {
          const term = searchQuery.toLowerCase();
          const matchesTitle = item.title.toLowerCase().includes(term);
          const matchesDesc = item.description.toLowerCase().includes(term);
          const matchesCat = item.categoryName.toLowerCase().includes(term);
          const matchesRegion = item.region.toLowerCase().includes(term);
          if (!matchesTitle && !matchesDesc && !matchesCat && !matchesRegion) {
            return false;
          }
        }

        // Category filter
        if (selectedCategory !== 'all' && item.categoryId !== selectedCategory) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') {
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        }
        if (sortBy === 'price-asc') {
          return a.price - b.price;
        }
        if (sortBy === 'price-desc') {
          return b.price - a.price;
        }
        if (sortBy === 'popular') {
          return b.views - a.views;
        }
        return 0;
      });
  }, [savedListings, searchQuery, selectedCategory, sortBy]);

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSortBy('newest');
  };

  return (
    <div className="flex-1 flex flex-col bg-[#f0faf3] py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
      {/* Page Header */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6 sm:p-8 shadow-xs mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-red-50 text-red-500 rounded-2xl border border-red-100 shadow-xs">
              <Heart className="w-7 h-7 fill-red-500 stroke-red-500" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">
                  Saved Ads
                </h1>
                <span className="bg-[#b08865] text-white text-xs font-black px-2.5 py-0.5 rounded-full">
                  {favorites.length}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-gray-500 font-medium mt-1">
                Your bookmarked listings saved locally on this browser.
              </p>
            </div>
          </div>

          <button
            onClick={onBrowseClick}
            className="self-start sm:self-auto bg-[#4a3a2c] hover:bg-[#382b20] text-white text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Explore Marketplace</span>
          </button>
        </div>

        {/* Filter Controls Bar (Visible if there are saved ads) */}
        {savedListings.length > 0 && (
          <div className="mt-6 pt-6 border-t border-gray-100 grid grid-cols-1 md:grid-cols-12 gap-3.5 items-center">
            {/* Search Input */}
            <div className="md:col-span-5 relative">
              <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search within saved ads..."
                className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-10 pr-4 py-2 text-xs text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#b08865] focus:bg-white transition"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-xs font-bold"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Category Select */}
            <div className="md:col-span-4 relative">
              <select
                value={selectedCategory}
                onChange={e => setSelectedCategory(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2 text-xs text-gray-700 font-semibold focus:outline-none focus:ring-2 focus:ring-[#b08865] focus:bg-white cursor-pointer transition appearance-none"
              >
                <option value="all">All Categories ({savedListings.length})</option>
                {CATEGORIES.map(cat => {
                  const count = savedListings.filter(item => item.categoryId === cat.id).length;
                  if (count === 0) return null;
                  return (
                    <option key={cat.id} value={cat.id}>
                      {cat.name} ({count})
                    </option>
                  );
                })}
              </select>
            </div>

            {/* Sort Select */}
            <div className="md:col-span-3 relative">
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2 text-xs text-gray-700 font-semibold focus:outline-none focus:ring-2 focus:ring-[#b08865] focus:bg-white cursor-pointer transition"
              >
                <option value="newest">Sort: Newest First</option>
                <option value="price-asc">Sort: Price (Low to High)</option>
                <option value="price-desc">Sort: Price (High to Low)</option>
                <option value="popular">Sort: Most Popular</option>
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Grid Content Section */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="bg-white rounded-xl border border-gray-100 p-3 animate-pulse h-[340px]">
              <div className="w-full aspect-4/3 bg-gray-100 rounded-lg mb-3"></div>
              <div className="w-2/3 h-4 bg-gray-100 rounded mb-2"></div>
              <div className="w-1/2 h-5 bg-gray-100 rounded"></div>
            </div>
          ))}
        </div>
      ) : favorites.length === 0 ? (
        /* Empty State: Zero favorites total */
        <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center flex flex-col items-center justify-center flex-1 my-4">
          <div className="w-20 h-20 bg-red-50 text-red-400 rounded-full flex items-center justify-center mb-4 border border-red-100">
            <Heart className="w-10 h-10 stroke-[1.5]" />
          </div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">No Saved Ads Yet</h2>
          <p className="text-xs sm:text-sm text-gray-500 max-w-md mb-6 leading-relaxed">
            Click the heart icon on any classified ad while browsing to save items you are interested in for quick access later.
          </p>
          <button
            onClick={onBrowseClick}
            className="bg-[#b08865] hover:bg-[#937153] text-white font-extrabold text-xs px-6 py-3 rounded-xl transition shadow-md flex items-center gap-2 cursor-pointer transform active:scale-95"
          >
            <Grid className="w-4 h-4" />
            <span>Browse All Classifieds</span>
          </button>
        </div>
      ) : filteredListings.length === 0 ? (
        /* Empty State: Filter produced no matches */
        <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center flex flex-col items-center justify-center flex-1 my-4">
          <Search className="w-12 h-12 text-gray-300 mb-3" />
          <h3 className="font-bold text-gray-700 text-base mb-1">No Saved Ads Match Your Search</h3>
          <p className="text-xs text-gray-400 max-w-sm mb-4">
            Try adjusting your search terms or clearing the selected category.
          </p>
          <button
            onClick={clearFilters}
            className="bg-[#b08865] hover:bg-[#937153] text-white font-bold text-xs px-4 py-2 rounded-lg cursor-pointer transition shadow-xs"
          >
            Clear Filters
          </button>
        </div>
      ) : (
        /* Grid View of Saved Ads */
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between text-xs text-gray-500 font-semibold px-1">
            <span>Showing {filteredListings.length} of {savedListings.length} saved ads</span>
            {(searchQuery || selectedCategory !== 'all') && (
              <button
                onClick={clearFilters}
                className="text-[#b08865] hover:underline cursor-pointer font-bold"
              >
                Reset Saved Filters
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            {filteredListings.map(ad => (
              <div key={ad.id} className="h-full">
                <ListingCard
                  listing={ad}
                  isFavorite={favorites.includes(ad.id)}
                  onToggleFavorite={e => {
                    e.stopPropagation();
                    onToggleFavorite(ad.id);
                  }}
                  onViewDetails={() => onViewDetails(ad.id)}
                  onChatClick={e => {
                    e.stopPropagation();
                    onInitiateChat(ad);
                  }}
                  selectedCurrency={selectedCurrency}
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
