import React, { useState, useEffect, useRef } from 'react';
import { X, Send, ChevronLeft, MapPin, ExternalLink, ShieldAlert, Sparkles } from 'lucide-react';
import { ChatSession, ChatMessage, Listing } from '../types';

interface ChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeListing: Listing | null; // If starting from a specific listing detail
  onCloseActiveListing: () => void; // Clears the trigger
}

export default function ChatDrawer({
  isOpen,
  onClose,
  activeListing,
  onCloseActiveListing
}: ChatDrawerProps) {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [selectedSession, setSelectedSession] = useState<ChatSession | null>(null);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Poll for messages every 2 seconds to simulate real-time replies
  useEffect(() => {
    if (!isOpen) return;

    const fetchSessions = () => {
      fetch('/api/chats?userId=usr-current')
        .then(res => res.json())
        .then((data: ChatSession[]) => {
          setSessions(data);
          setLoading(false);

          // Update active conversation in real time if open
          if (selectedSession) {
            const updated = data.find(s => s.chatId === selectedSession.chatId);
            if (updated && JSON.stringify(updated.messages) !== JSON.stringify(selectedSession.messages)) {
              setSelectedSession(updated);
            }
          }
        })
        .catch(err => console.error('Failed to poll chats:', err));
    };

    fetchSessions();
    const interval = setInterval(fetchSessions, 2000);
    return () => clearInterval(interval);
  }, [isOpen, selectedSession?.chatId]);

  // Handle initialization when starting chat directly from an ad detail
  useEffect(() => {
    if (isOpen && activeListing) {
      setLoading(true);
      // Check if there is already an active session for this listing
      const existing = sessions.find(s => s.listingId === activeListing.id);
      if (existing) {
        setSelectedSession(existing);
        setLoading(false);
      } else {
        // Mock temporary session until first message sent
        const tempSession: ChatSession = {
          chatId: `temp-${Date.now()}`,
          listingId: activeListing.id,
          listingTitle: activeListing.title,
          listingPrice: activeListing.price,
          listingImage: activeListing.imageUrls[0],
          buyerId: 'usr-current',
          buyerName: 'Kofi Mensah',
          sellerId: activeListing.sellerId,
          sellerName: activeListing.sellerName,
          messages: [],
          lastUpdated: new Date().toISOString()
        };
        setSelectedSession(tempSession);
        setLoading(false);
      }
    }
  }, [isOpen, activeListing, sessions.length]);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [selectedSession?.messages]);

  if (!isOpen) return null;

  // Send message
  const handleSendMessage = (textToSend: string) => {
    if (!textToSend.trim() || !selectedSession) return;

    const payload = {
      listingId: selectedSession.listingId,
      text: textToSend.trim(),
      senderId: 'usr-current',
      senderName: 'Kofi Mensah',
      receiverId: selectedSession.sellerId === 'usr-current' ? selectedSession.buyerId : selectedSession.sellerId,
      receiverName: selectedSession.sellerId === 'usr-current' ? selectedSession.buyerName : selectedSession.sellerName
    };

    setInputText('');

    fetch('/api/chats', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(res => res.json())
      .then((updatedSession: ChatSession) => {
        setSelectedSession(updatedSession);
        onCloseActiveListing(); // Clear start listing context

        // Optimistically add to lists
        setSessions(prev => {
          const filtered = prev.filter(s => s.chatId !== updatedSession.chatId);
          return [updatedSession, ...filtered];
        });
      })
      .catch(err => console.error('Failed to send message:', err));
  };

  // Pre-written responses for Quick Reply
  const quickMessageChips = [
    "Is this still available?",
    "What is your best price?",
    "Can I come see it today?",
    "Is this negotiable?",
    "Where is your shop located?"
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Background overlay */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
      />

      {/* Drawer Container */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col z-10 border-l border-gray-100">
        
        {/* DRAWER HEADER */}
        <div className="bg-[#3e3023] text-white px-4 py-4 flex items-center justify-between border-b border-green-800 shrink-0">
          <div className="flex items-center gap-2">
            {selectedSession && (
              <button 
                onClick={() => {
                  setSelectedSession(null);
                  onCloseActiveListing();
                }}
                className="hover:bg-white/10 p-1 rounded-full transition mr-1 cursor-pointer"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
            )}
            <h2 className="font-extrabold text-sm sm:text-base tracking-tight">
              {selectedSession ? `Chat with ${selectedSession.sellerId === 'usr-current' ? selectedSession.buyerName : selectedSession.sellerName}` : 'Messages'}
            </h2>
          </div>
          <button 
            onClick={onClose}
            className="hover:bg-white/10 p-1.5 rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* LOADING STATE */}
        {loading ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-gray-400">
            <div className="w-8 h-8 rounded-full border-2 border-t-[#b08865] border-gray-100 animate-spin mb-3"></div>
            <span className="text-xs font-semibold">Syncing chat logs...</span>
          </div>
        ) : !selectedSession ? (
          
          /* VIEW 1: CHATS LIST */
          <div className="flex-1 overflow-y-auto divide-y divide-gray-100">
            {sessions.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center p-8 text-center text-gray-400">
                <Sparkles className="w-10 h-10 text-gray-300 mb-2" />
                <h4 className="font-bold text-gray-700 text-sm mb-1">No Conversations Yet</h4>
                <p className="text-xs max-w-xs">Start a chat from any ad listing details page to negotiate with sellers.</p>
              </div>
            ) : (
              sessions.map(sess => {
                const isSellerCurrent = sess.sellerId === 'usr-current';
                const partnerName = isSellerCurrent ? sess.buyerName : sess.sellerName;
                const lastMsg = sess.messages[sess.messages.length - 1];

                return (
                  <div
                    key={sess.chatId}
                    onClick={() => setSelectedSession(sess)}
                    className="p-4 flex gap-3 hover:bg-gray-50/70 cursor-pointer transition relative"
                  >
                    {/* Item Thumbnail */}
                    <img
                      src={sess.listingImage}
                      alt={sess.listingTitle}
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 object-cover rounded-lg border border-gray-100 shrink-0"
                    />

                    {/* Chat meta details */}
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div className="flex justify-between items-baseline">
                        <h4 className="font-extrabold text-gray-800 text-xs truncate max-w-[150px]">
                          {partnerName}
                        </h4>
                        <span className="text-[10px] text-gray-400 font-bold shrink-0">
                          GH₵ {sess.listingPrice.toLocaleString()}
                        </span>
                      </div>

                      <span className="text-[11px] font-semibold text-gray-500 truncate mt-0.5">
                        Regarding: {sess.listingTitle}
                      </span>

                      <p className="text-[10px] text-[#b08865] font-bold truncate mt-1">
                        {lastMsg ? `${lastMsg.senderId === 'usr-current' ? 'You' : partnerName}: ${lastMsg.text}` : 'Started a conversation...'}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        ) : (
          
          /* VIEW 2: ACTIVE CHAT CONVERSATION */
          <div className="flex-1 flex flex-col bg-gray-50 overflow-hidden">
            
            {/* Listing details bar */}
            <div className="bg-white border-b border-gray-100 p-3 flex gap-3 items-center shadow-xs shrink-0">
              <img
                src={selectedSession.listingImage}
                alt={selectedSession.listingTitle}
                referrerPolicy="no-referrer"
                className="w-10 h-10 object-cover rounded-md border border-gray-100 shrink-0"
              />
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-extrabold text-gray-800 truncate">
                  {selectedSession.listingTitle}
                </h4>
                <p className="text-xs font-black text-green-700 mt-0.5">
                  GH₵ {selectedSession.listingPrice.toLocaleString()}
                </p>
              </div>
            </div>

            {/* Safety guidelines alert */}
            <div className="bg-orange-50 border-b border-orange-100/70 p-2.5 flex items-start gap-2 text-[10px] text-orange-800 shrink-0">
              <ShieldAlert className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
              <p className="leading-relaxed font-semibold">
                <strong>Safety Notice:</strong> Meet in a secure public place. Inspect item quality. Do NOT make advance payments.
              </p>
            </div>

            {/* Messages box log */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
              {selectedSession.messages.length === 0 ? (
                <div className="my-auto text-center p-6 text-gray-400 flex flex-col items-center gap-1.5">
                  <span className="bg-green-100 text-green-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full">Secure Chat active</span>
                  <p className="text-xs leading-normal max-w-xs font-semibold">
                    Send a quick greeting below to start negotiating with the seller!
                  </p>
                </div>
              ) : (
                selectedSession.messages.map(msg => {
                  const isOwn = msg.senderId === 'usr-current';
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col max-w-[80%] ${isOwn ? 'self-end items-end' : 'self-start items-start'}`}
                    >
                      <div
                        className={`rounded-2xl px-3.5 py-2 text-xs font-semibold shadow-2xs leading-relaxed ${
                          isOwn
                            ? 'bg-[#3e3023] text-white rounded-tr-none'
                            : 'bg-white text-gray-800 rounded-tl-none border border-gray-100'
                        }`}
                      >
                        {msg.text}
                      </div>
                      <span className="text-[8px] text-gray-400 font-bold mt-1 px-1">
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Reply panel */}
            <div className="bg-white border-t border-gray-100 px-4 py-2.5 shrink-0 flex flex-col gap-1.5" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-[#b08865]" />
                <span className="text-[9px] font-black uppercase tracking-wider text-gray-400">Quick Replies</span>
              </div>
              <div className="flex gap-2 overflow-x-auto py-1 scrollbar-none">
                {quickMessageChips.map(chip => (
                  <button
                    key={chip}
                    type="button"
                    onClick={() => handleSendMessage(chip)}
                    className="bg-gray-50 hover:bg-[#b08865]/10 hover:text-[#7a5e45] border border-gray-200 hover:border-[#b08865]/20 text-gray-700 rounded-lg px-3 py-1.5 text-[11px] font-black whitespace-nowrap shrink-0 transition cursor-pointer active:scale-95 shadow-2xs"
                  >
                    {chip}
                  </button>
                ))}
              </div>
            </div>

            {/* Text input form */}
            <div className="bg-white p-3 border-t border-gray-100 shrink-0 flex gap-2">
              <input
                type="text"
                placeholder="Write a message..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage(inputText)}
                className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:bg-white focus:border-[#b08865] font-semibold"
              />
              <button
                onClick={() => handleSendMessage(inputText)}
                className="bg-[#b08865] hover:bg-[#937153] text-white p-2.5 rounded-xl flex items-center justify-center transition shrink-0 cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
