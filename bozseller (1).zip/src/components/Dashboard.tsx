import React, { useState, useEffect, useRef } from 'react';
import { 
  Settings, User, MapPin, Check, Plus, MessageSquare, Shield, HelpCircle, 
  ShieldCheck, Heart, Trash2, CheckCircle, TrendingUp, AlertCircle, ShoppingBag, 
  CreditCard, Users, Star, ArrowRight, DollarSign, Wallet, Phone, Gift, Award, Smartphone, 
  PlusCircle, Sparkles, BookOpen, ThumbsUp, UploadCloud, ChevronRight, CheckCircle2, 
  Loader2, X, RotateCcw, Image, Navigation, Map, ShieldAlert, ArrowUpRight, Bell, BellRing,
  Zap, Clock
} from 'lucide-react';
import { 
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell
} from 'recharts';
import { Listing } from '../types';
import { CURRENT_USER, COUNTRIES_CONFIG } from '../data/mockData';
import { CurrencyCode, CURRENCIES, formatConvertedPrice } from '../utils/currency';

interface DashboardProps {
  onViewDetails: (id: string) => void;
  onOpenChats: () => void;
  onPostAdClick: () => void;
  refreshTrigger: number;
  selectedCurrency?: CurrencyCode;
  onOpenSubscription?: () => void;
}

export default function Dashboard({
  onViewDetails,
  onOpenChats,
  onPostAdClick,
  refreshTrigger,
  selectedCurrency = 'GHS',
  onOpenSubscription
}: DashboardProps) {
  // Navigation tabs matching the screenshot
  const [activeTab, setActiveTab] = useState<'make-money' | 'premium' | 'balance' | 'followers' | 'my-adverts' | 'feedback' | 'request-help' | 'faq' | 'price-alerts' | 'verification'>('balance');
  
  // Price Alerts & Notifications state
  const [priceAlerts, setPriceAlerts] = useState<any[]>([]);
  const [priceDropSubscriptions, setPriceDropSubscriptions] = useState<any[]>([]);
  const [allListings, setAllListings] = useState<Listing[]>([]);
  const [alertsLoading, setAlertsLoading] = useState(false);

  // Load alerts, price drop notifications, and all listings to compare
  const loadAlertsAndListings = () => {
    setAlertsLoading(true);
    const savedAlerts = localStorage.getItem('dosboz_price_alerts');
    const alerts = savedAlerts ? JSON.parse(savedAlerts) : [];
    setPriceAlerts(alerts);

    const savedDropAlerts = localStorage.getItem('dosboz_price_drop_alerts');
    if (savedDropAlerts) {
      try {
        const parsed = JSON.parse(savedDropAlerts);
        const list = Object.values(parsed).filter((item: any) => item.enabled);
        setPriceDropSubscriptions(list);
      } catch (e) {
        setPriceDropSubscriptions([]);
      }
    } else {
      setPriceDropSubscriptions([]);
    }

    fetch('/api/listings')
      .then(res => res.json())
      .then((data: Listing[]) => {
        setAllListings(data);
        setAlertsLoading(false);
      })
      .catch(err => {
        console.error('Failed to load listings for price alert matching:', err);
        setAlertsLoading(false);
      });
  };

  useEffect(() => {
    loadAlertsAndListings();
  }, [activeTab, refreshTrigger]);

  const getAlertMatches = (alert: any) => {
    if (!alert.active) return [];
    
    // Parse alert title to key terms
    const terms = alert.title.toLowerCase()
      .replace(/[^a-z0-9\s]/g, '')
      .split(/\s+/)
      .filter((w: string) => w.length > 2 && w !== 'with' && w !== 'for' && w !== 'and');

    return allListings.filter(item => {
      // Don't match the user's own listings or the exact same listing
      if (item.id === alert.listingId || item.sellerId === 'usr-current') return false;
      if (item.status !== 'active') return false;

      // Match categories
      const categoryMatch = item.categoryId === alert.categoryId;
      
      // Match key terms in title
      const titleMatch = terms.some((term: string) => item.title.toLowerCase().includes(term));
      
      // Price threshold check
      const priceMatch = item.price <= alert.targetPrice;

      return (categoryMatch || titleMatch) && priceMatch;
    });
  };

  const totalAlertMatchesCount = priceAlerts.reduce((sum, alert) => {
    return sum + getAlertMatches(alert).length;
  }, 0);

  // Listings and loading states
  const [myListings, setMyListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);

  // Advice bar toggle state
  const [showAdvice, setShowAdvice] = useState(() => {
    const saved = localStorage.getItem('dosboz_hide_advice');
    return saved !== 'true';
  });

  // Balance states (persistent)
  const [balance, setBalance] = useState<number>(() => {
    const saved = localStorage.getItem('dosboz_user_balance');
    return saved ? Number(saved) : 0;
  });

  // Profile & settings state
  const [profile, setProfile] = useState(() => {
    const saved = localStorage.getItem('dosboz_user_profile');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          name: parsed.name || CURRENT_USER.name,
          phone: parsed.phone || CURRENT_USER.phone,
          momoNumber: parsed.momoNumber || CURRENT_USER.phone,
          momoNetwork: parsed.momoNetwork || 'mtn',
          momoLinked: parsed.momoLinked !== undefined ? parsed.momoLinked : true,
          verified: parsed.verified !== undefined ? parsed.verified : CURRENT_USER.verified,
          rating: parsed.rating !== undefined ? parsed.rating : CURRENT_USER.rating
        };
      } catch (e) {
        // Fallback below
      }
    }
    return {
      name: CURRENT_USER.name,
      phone: CURRENT_USER.phone,
      momoNumber: CURRENT_USER.phone,
      momoNetwork: 'mtn',
      momoLinked: true,
      verified: CURRENT_USER.verified,
      rating: CURRENT_USER.rating
    };
  });

  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // Recharge Modal states
  const [showRechargeModal, setShowRechargeModal] = useState(false);
  const [rechargeAmount, setRechargeAmount] = useState('50');
  const [paymentMethod, setPaymentMethod] = useState<'momo' | 'card'>('momo');
  const [momoNetwork, setMomoNetwork] = useState<'mtn' | 'telecel' | 'at'>(profile.momoNetwork);
  const [momoNumber, setMomoNumber] = useState(profile.momoNumber);
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // Trust & Verification Center state
  const [verificationStep, setVerificationStep] = useState<'start' | 'id-upload' | 'selfie-upload' | 'phone-otp' | 'processing' | 'success'>('start');
  const [idType, setIdType] = useState<'ghana-card' | 'nin-card' | 'togo-id' | 'driver-license'>('ghana-card');
  const [idNumber, setIdNumber] = useState('');
  const [idFileName, setIdFileName] = useState<string | null>(null);
  const [selfieFileName, setSelfieFileName] = useState<string | null>(null);
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [otpError, setOtpError] = useState<string | null>(null);
  const [verificationProgress, setVerificationProgress] = useState(0);
  const [verificationStatusMessage, setVerificationStatusMessage] = useState('');

  // Active GPS Capture states
  const [locatingId, setLocatingId] = useState<string | null>(null);
  const [gpsCaptureSuccess, setGpsCaptureSuccess] = useState<string | null>(null);

  // Active RAW Upload states
  const [uploadingId, setUploadingId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [selectedListingForUpload, setSelectedListingForUpload] = useState<string | null>(null);

  // Active AI Bump/Boost prediction states
  const [loadingForecasts, setLoadingForecasts] = useState<Record<string, boolean>>({});
  const [forecastResults, setForecastResults] = useState<Record<string, any>>({});
  const [boostingAds, setBoostingAds] = useState<Record<string, boolean>>({});
  const [boostSuccess, setBoostSuccess] = useState<Record<string, boolean>>({});

  const handleFetchForecast = async (adId: string, title: string, categoryName: string, country: string, region: string) => {
    setLoadingForecasts(prev => ({ ...prev, [adId]: true }));
    try {
      const res = await fetch('/api/ai/bump-ad-prediction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, categoryName, country, region })
      });
      if (res.ok) {
        const data = await res.json();
        setForecastResults(prev => ({ ...prev, [adId]: data }));
      } else {
        console.error("Failed to fetch forecast");
      }
    } catch (err) {
      console.error("Error fetching forecast:", err);
    } finally {
      setLoadingForecasts(prev => ({ ...prev, [adId]: false }));
    }
  };

  const handleBoostAd = async (adId: string) => {
    setBoostingAds(prev => ({ ...prev, [adId]: true }));
    try {
      const res = await fetch(`/api/listings/${adId}/bump`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      if (res.ok) {
        const data = await res.json();
        setBoostSuccess(prev => ({ ...prev, [adId]: true }));
        // Refresh local listing list to immediately reflect updated date (move to top) and increased views count
        loadMyListings();
        setTimeout(() => {
          setBoostSuccess(prev => ({ ...prev, [adId]: false }));
        }, 5000);
      } else {
        console.error("Failed to boost listing");
      }
    } catch (err) {
      console.error("Error boosting listing:", err);
    } finally {
      setBoostingAds(prev => ({ ...prev, [adId]: false }));
    }
  };

  // Boost Plan Subscription states
  const [subscribingPlan, setSubscribingPlan] = useState<string | null>(null);
  const [subscriptionSuccess, setSubscriptionSuccess] = useState<string | null>(null);

  // Persistent Balance Sync
  useEffect(() => {
    localStorage.setItem('dosboz_user_balance', balance.toString());
  }, [balance]);

  // Trust & Verification automated progress effect
  useEffect(() => {
    if (verificationStep !== 'processing') return;

    setVerificationProgress(0);
    setVerificationStatusMessage('Initiating secure identity scan...');

    const messages = [
      { progress: 15, msg: 'Extracting metadata and document text...' },
      { progress: 40, msg: 'Performing high-precision facial geometry match...' },
      { progress: 70, msg: 'Checking blacklist and fraud database registries...' },
      { progress: 90, msg: 'Contacting National Registry API for validation...' },
      { progress: 98, msg: 'Signing credentials and generating trust index...' },
      { progress: 100, msg: 'Trust verification successful!' }
    ];

    let currentMsgIdx = 0;
    const interval = setInterval(() => {
      setVerificationProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          // Complete verification
          const updated = {
            ...profile,
            verified: true,
            rating: 5.0
          };
          setProfile(updated);
          localStorage.setItem('dosboz_user_profile', JSON.stringify(updated));
          
          setTimeout(() => {
            setVerificationStep('success');
          }, 600);
          return 100;
        }

        const nextProgress = prev + Math.floor(Math.random() * 15) + 5;
        const boundedProgress = Math.min(nextProgress, 100);

        // Find matching status message
        if (currentMsgIdx < messages.length && boundedProgress >= messages[currentMsgIdx].progress) {
          setVerificationStatusMessage(messages[currentMsgIdx].msg);
          if (boundedProgress >= 100) {
            currentMsgIdx = messages.length;
          } else {
            currentMsgIdx++;
          }
        }

        return boundedProgress;
      });
    }, 400);

    return () => clearInterval(interval);
  }, [verificationStep]);

  // Sync profile edits to payment states
  useEffect(() => {
    setMomoNumber(profile.momoNumber);
    setMomoNetwork(profile.momoNetwork);
  }, [profile]);

  // Load user listings
  const loadMyListings = () => {
    setLoading(true);
    fetch('/api/listings?sellerId=usr-current')
      .then(res => res.json())
      .then((data: Listing[]) => {
        setMyListings(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load seller listings:', err);
        setLoading(false);
      });
  };

  useEffect(() => {
    loadMyListings();
  }, [refreshTrigger]);

  // Close / Deactivate listing
  const handleCloseAd = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to mark this item as Sold?')) return;

    fetch(`/api/listings/${id}/close`, { method: 'POST' })
      .then(res => res.json())
      .then(() => {
        loadMyListings();
      })
      .catch(err => console.error('Failed to close ad:', err));
  };

  // Delete listing
  const handleDeleteAd = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this ad permanently?')) return;

    fetch(`/api/listings/${id}`, { method: 'DELETE' })
      .then(res => res.json())
      .then(() => {
        loadMyListings();
      })
      .catch(err => console.error('Failed to delete ad:', err));
  };

  // Capture GPS coordinates for a specific listing
  const handleCaptureGPS = (listingId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLocatingId(listingId);
    
    const finishGPS = (lat: number, lng: number, address: string) => {
      fetch(`/api/listings/${listingId}/gps`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gpsAddress: address,
          gpsCoordinates: { latitude: lat, longitude: lng }
        })
      })
      .then(res => res.json())
      .then(() => {
        setGpsCaptureSuccess(listingId);
        loadMyListings();
        setLocatingId(null);
        setTimeout(() => setGpsCaptureSuccess(null), 4000);
      })
      .catch(err => {
        console.error('Failed to update GPS:', err);
        setLocatingId(null);
      });
    };

    if (!navigator.geolocation) {
      setTimeout(() => {
        const randomLat = 5.6037 + (Math.random() - 0.5) * 0.02;
        const randomLng = -0.1870 + (Math.random() - 0.5) * 0.02;
        const randomAddress = `GA-${Math.floor(100+Math.random()*900)}-${Math.floor(1000+Math.random()*9000)}`;
        finishGPS(Number(randomLat.toFixed(6)), Number(randomLng.toFixed(6)), randomAddress);
      }, 1000);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = Number(position.coords.latitude.toFixed(6));
        const lng = Number(position.coords.longitude.toFixed(6));
        const randomSec1 = Math.floor(100 + Math.random() * 900);
        const randomSec2 = Math.floor(1000 + Math.random() * 9000);
        const address = `GA-${randomSec1}-${randomSec2}`;
        finishGPS(lat, lng, address);
      },
      (error) => {
        console.error("GPS Sensor access failed, falling back to network simulator:", error);
        const lat = 5.6037 + (Math.random() - 0.5) * 0.01;
        const lng = -0.1870 + (Math.random() - 0.5) * 0.01;
        const address = `GA-${Math.floor(100+Math.random()*900)}-2045`;
        finishGPS(Number(lat.toFixed(6)), Number(lng.toFixed(6)), address);
      },
      { enableHighAccuracy: true, timeout: 5000 }
    );
  };

  // Simulate file select/upload for original RAW photo
  const triggerRAWUpload = (listingId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedListingForUpload(listingId);
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleRAWFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedListingForUpload) return;

    setUploadingId(selectedListingForUpload);
    
    // Simulate server ingestion of RAW file metadata
    setTimeout(() => {
      fetch(`/api/listings/${selectedListingForUpload}/original-images`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: file.name.toUpperCase(),
          size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
          type: file.type || 'image/jpeg'
        })
      })
      .then(res => res.json())
      .then(() => {
        setUploadingId(null);
        setSelectedListingForUpload(null);
        loadMyListings();
      })
      .catch(err => {
        console.error('Failed to add original image metadata:', err);
        setUploadingId(null);
        setSelectedListingForUpload(null);
      });
    }, 1200);
  };

  // Perform recharge simulation
  const handlePerformRecharge = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = Number(rechargeAmount);
    if (isNaN(amount) || amount <= 0) {
      alert('Please enter a valid recharge amount');
      return;
    }

    setIsProcessingPayment(true);
    setTimeout(() => {
      setBalance(prev => prev + amount);
      setIsProcessingPayment(false);
      setPaymentSuccess(true);
      setTimeout(() => {
        setPaymentSuccess(false);
        setShowRechargeModal(false);
      }, 1500);
    }, 2000);
  };

  // Subscribe to premium boost plans using balance
  const handleSubscribePlan = (planName: string, price: number) => {
    if (balance < price) {
      alert(`Your balance (GH₵ ${balance}) is insufficient to subscribe to the ${planName} Plan (GH₵ ${price}). Please recharge your wallet.`);
      setActiveTab('balance');
      return;
    }

    if (!window.confirm(`Are you sure you want to subscribe to ${planName} Plan for GH₵ ${price}? This will be deducted from your wallet.`)) {
      return;
    }

    setSubscribingPlan(planName);
    setTimeout(() => {
      setBalance(prev => prev - price);
      setSubscribingPlan(null);
      setSubscriptionSuccess(planName);
      setTimeout(() => setSubscriptionSuccess(null), 3500);
    }, 1500);
  };

  const activeCount = myListings.filter(l => l.status === 'active').length;

  return (
    <div className="w-full bg-[#f4f2ee] min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* main outer grid container */}
        <div className="flex flex-col lg:flex-row gap-6 items-start">
          
          {/* ================= SIDEBAR PANEL ================= */}
          <div className="w-full lg:w-80 shrink-0 flex flex-col gap-4">
            
            {/* User Details card block */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-xs relative p-6 flex flex-col items-center text-center">
              {/* Settings button */}
              <button 
                onClick={() => setShowSettingsModal(true)}
                className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 p-1 rounded-full hover:bg-gray-50 transition cursor-pointer"
                title="Settings"
              >
                <div className="flex items-center gap-1">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Settings</span>
                  <Settings className="w-4 h-4 text-gray-400" />
                </div>
              </button>

              {/* DosBoz style Green circle avatar with user silhouette */}
              <div className="w-16 h-16 rounded-full bg-[#3db83a] flex items-center justify-center border border-gray-100 shadow-xs mb-3.5 mt-2">
                <User className="w-9 h-9 text-white stroke-[2]" />
              </div>

              {/* Name and Phone */}
              <h3 className="text-base font-black text-gray-800 tracking-tight leading-tight">
                {profile.name}
              </h3>
              <span className="text-xs text-gray-400 font-semibold mt-1">
                {profile.phone}
              </span>

              {/* Verified Seller Reputation Badge */}
              {profile.verified ? (
                <div className="mt-3 bg-green-50 text-green-700 border border-green-100 rounded-full px-3 py-1 flex items-center justify-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wider shadow-2xs">
                  <ShieldCheck className="w-3.5 h-3.5 text-green-600 fill-green-50" />
                  <span>Verified Seller</span>
                </div>
              ) : (
                <button
                  onClick={() => setActiveTab('verification')}
                  className="mt-3 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-full px-3 py-1 flex items-center justify-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wider shadow-2xs transition active:scale-95 cursor-pointer animate-pulse"
                >
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
                  <span>Verify Profile</span>
                </button>
              )}
            </div>

            {/* SELLER SUBSCRIPTION PLAN CARD */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 rounded-2xl border border-emerald-500/30 p-4 text-white flex flex-col gap-3 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-black tracking-wide text-emerald-300 uppercase">Seller Plan</span>
                </div>
                <span className="text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                  Plans & Limits
                </span>
              </div>
              <p className="text-[11px] text-slate-300 font-medium leading-tight">
                Free Plan limit is 5 products. Upgrade to Monthly Seller for up to 100 products and global currency pricing.
              </p>
              <button
                onClick={() => { if (onOpenSubscription) onOpenSubscription(); }}
                className="w-full py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black text-xs rounded-xl transition cursor-pointer shadow-sm flex items-center justify-center gap-1.5 transform active:scale-98"
              >
                <Zap className="w-3.5 h-3.5 fill-slate-950" />
                Manage Subscription Plans
              </button>
            </div>


            {/* Advice Alert Block */}
            {showAdvice && (
              <div className="bg-[#fff9f3] border-t-4 border-[#ff7c00] rounded-xl shadow-3xs p-3.5 relative">
                <div className="flex items-center justify-between pb-1.5 border-b border-[#ffe6d0]">
                  <span className="text-[10px] font-black text-[#ff7c00] uppercase tracking-wider">Advice</span>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => {
                        localStorage.setItem('dosboz_hide_advice', 'true');
                        setShowAdvice(false);
                      }}
                      className="text-[10px] text-gray-400 hover:text-gray-700 font-bold hover:underline cursor-pointer"
                    >
                      hide 1
                    </button>
                    <button 
                      onClick={() => {
                        localStorage.setItem('dosboz_hide_advice', 'true');
                        setShowAdvice(false);
                      }}
                      className="text-gray-400 hover:text-gray-700 font-semibold text-xs cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <div className="pt-2 text-xs text-gray-700 font-medium leading-relaxed flex items-start gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#ff7c00] mt-1.5 shrink-0"></div>
                  <span>
                    Your Top need to be activated: <br />
                    <strong className="text-[#ff7c00]">1 in Others</strong>
                  </span>
                </div>
              </div>
            )}

            {/* Sidebar navigation list */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-xs overflow-hidden flex flex-col">
              
              {/* Make money tab */}
              <button
                onClick={() => setActiveTab('make-money')}
                className={`w-full text-left px-4 py-3.5 text-xs font-bold transition flex items-center justify-between cursor-pointer border-b border-gray-50 hover:bg-[#faf9f6] ${
                  activeTab === 'make-money' ? 'bg-[#f4f2ee] text-gray-900 border-l-4 border-[#3db83a]' : 'text-gray-600'
                }`}
              >
                <div className="flex items-center gap-3">
                  <DollarSign className="w-4 h-4 text-[#3db83a]" />
                  <span>Make money</span>
                </div>
              </button>

              {/* Premium Services tab */}
              <button
                onClick={() => setActiveTab('premium')}
                className={`w-full text-left px-4 py-3.5 text-xs font-bold transition flex items-center justify-between cursor-pointer border-b border-gray-50 hover:bg-[#faf9f6] ${
                  activeTab === 'premium' ? 'bg-[#f4f2ee] text-gray-900 border-l-4 border-[#3db83a]' : 'text-gray-600'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Award className="w-4 h-4 text-[#ff7c00]" />
                  <span>Premium Services</span>
                </div>
              </button>

              {/* MY BALANCE TAB - STYLED SPECIALLY MATCHING SCREENSHOT */}
              <div className="p-1 border-b border-gray-50">
                <button
                  onClick={() => setActiveTab('balance')}
                  className={`w-full text-left p-3.5 rounded-xl transition flex flex-col justify-between cursor-pointer ${
                    activeTab === 'balance' 
                      ? 'bg-white text-gray-900 ring-1 ring-gray-200 shadow-xs' 
                      : 'text-gray-600 hover:bg-[#faf9f6]'
                  }`}
                >
                  <div className="flex items-center gap-3 w-full text-xs font-bold">
                    <Wallet className="w-4 h-4 text-[#3db83a]" />
                    <span>MY BALANCE</span>
                  </div>
                  <span className="text-sm font-black text-[#3db83a] pl-7 mt-1.5 block">
                    GH₵ {balance}
                  </span>
                </button>
              </div>

              {/* Followers tab */}
              <button
                onClick={() => setActiveTab('followers')}
                className={`w-full text-left px-4 py-3.5 text-xs font-bold transition flex items-center justify-between cursor-pointer border-b border-gray-50 hover:bg-[#faf9f6] ${
                  activeTab === 'followers' ? 'bg-[#f4f2ee] text-gray-900 border-l-4 border-[#3db83a]' : 'text-gray-600'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Users className="w-4 h-4 text-[#3db83a]" />
                  <span>Followers • 2</span>
                </div>
              </button>

              {/* My adverts tab */}
              <button
                onClick={() => setActiveTab('my-adverts')}
                className={`w-full text-left px-4 py-3.5 text-xs font-bold transition flex items-center justify-between cursor-pointer border-b border-gray-50 hover:bg-[#faf9f6] ${
                  activeTab === 'my-adverts' ? 'bg-[#f4f2ee] text-gray-900 border-l-4 border-[#3db83a]' : 'text-gray-600'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-3">
                    <ShoppingBag className="w-4 h-4 text-[#3db83a]" />
                    <span>My adverts</span>
                  </div>
                  {activeCount > 0 && (
                    <span className="bg-[#3db83a] text-white text-[9px] font-black px-2 py-0.5 rounded-full">
                      {activeCount}
                    </span>
                  )}
                </div>
              </button>

              {/* Price Alerts tab */}
              <button
                onClick={() => setActiveTab('price-alerts')}
                className={`w-full text-left px-4 py-3.5 text-xs font-bold transition flex items-center justify-between cursor-pointer border-b border-gray-50 hover:bg-[#faf9f6] ${
                  activeTab === 'price-alerts' ? 'bg-[#f4f2ee] text-gray-900 border-l-4 border-[#3db83a]' : 'text-gray-600'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-3">
                    <Bell className="w-4 h-4 text-[#3db83a]" />
                    <span>Price Alerts</span>
                  </div>
                  {(totalAlertMatchesCount > 0 || priceDropSubscriptions.length > 0) && (
                    <span className="bg-orange-500 text-white text-[9px] font-black px-2 py-0.5 rounded-full animate-pulse">
                      {totalAlertMatchesCount + priceDropSubscriptions.length}
                    </span>
                  )}
                </div>
              </button>

              {/* Feedback tab */}
              <button
                onClick={() => setActiveTab('feedback')}
                className={`w-full text-left px-4 py-3.5 text-xs font-bold transition flex items-center justify-between cursor-pointer border-b border-gray-50 hover:bg-[#faf9f6] ${
                  activeTab === 'feedback' ? 'bg-[#f4f2ee] text-gray-900 border-l-4 border-[#3db83a]' : 'text-gray-600'
                }`}
              >
                <div className="flex items-center gap-3">
                  <ThumbsUp className="w-4 h-4 text-[#3db83a]" />
                  <span>Feedback</span>
                </div>
              </button>

              {/* Trust & Verification tab */}
              <button
                onClick={() => setActiveTab('verification')}
                className={`w-full text-left px-4 py-3.5 text-xs font-bold transition flex items-center justify-between cursor-pointer border-b border-gray-50 hover:bg-[#faf9f6] ${
                  activeTab === 'verification' ? 'bg-[#f4f2ee] text-gray-900 border-l-4 border-[#3db83a]' : 'text-gray-600'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-3">
                    <ShieldCheck className="w-4 h-4 text-[#3db83a]" />
                    <span>Trust & Verification</span>
                  </div>
                  {profile.verified ? (
                    <span className="bg-green-100 text-green-800 text-[9px] font-black px-2 py-0.5 rounded-full">
                      VERIFIED
                    </span>
                  ) : (
                    <span className="bg-amber-100 text-amber-800 text-[9px] font-black px-2 py-0.5 rounded-full animate-pulse">
                      VERIFY
                    </span>
                  )}
                </div>
              </button>

              {/* Request help tab */}
              <button
                onClick={() => setActiveTab('request-help')}
                className={`w-full text-left px-4 py-3.5 text-xs font-bold transition flex items-center justify-between cursor-pointer border-b border-gray-50 hover:bg-[#faf9f6] ${
                  activeTab === 'request-help' ? 'bg-[#f4f2ee] text-gray-900 border-l-4 border-[#3db83a]' : 'text-gray-600'
                }`}
              >
                <div className="flex items-center gap-3">
                  <MessageSquare className="w-4 h-4 text-[#3db83a]" />
                  <span>Request help</span>
                </div>
              </button>

              {/* Frequently Asked Questions tab */}
              <button
                onClick={() => setActiveTab('faq')}
                className={`w-full text-left px-4 py-3.5 text-xs font-bold transition flex items-center justify-between cursor-pointer hover:bg-[#faf9f6] ${
                  activeTab === 'faq' ? 'bg-[#f4f2ee] text-gray-900 border-l-4 border-[#3db83a]' : 'text-gray-600'
                }`}
              >
                <div className="flex items-center gap-3">
                  <HelpCircle className="w-4 h-4 text-[#3db83a]" />
                  <span>Frequently Asked Questions</span>
                </div>
              </button>

            </div>

          </div>

          {/* ================= MAIN CONTENT PANEL ================= */}
          <div className="flex-1 w-full min-w-0">
            
            {/* Price Alerts Notification Banner */}
            {totalAlertMatchesCount > 0 && activeTab !== 'price-alerts' && (
              <div className="mb-5 bg-orange-50 border border-orange-200 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs animate-in slide-in-from-top-2 duration-300">
                <div className="flex items-start gap-3">
                  <div className="bg-orange-100 text-orange-600 p-2.5 rounded-xl shrink-0">
                    <Bell className="w-5 h-5 animate-bounce" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-orange-800">New Price Alert Matches!</h4>
                    <p className="text-xs text-orange-700/90 font-medium leading-relaxed mt-0.5">
                      We found <strong>{totalAlertMatchesCount}</strong> similar {totalAlertMatchesCount === 1 ? 'item' : 'items'} posted below your target price threshold.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('price-alerts')}
                  className="bg-orange-600 hover:bg-orange-700 text-white text-[11px] font-black px-4 py-2.5 rounded-xl shadow-xs transition shrink-0 cursor-pointer uppercase tracking-wider"
                >
                  View Matches
                </button>
              </div>
            )}

            {/* 1. MY BALANCE ACTIVE TAB VIEW */}
            {activeTab === 'balance' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-xs overflow-hidden flex flex-col">
                {/* Header */}
                <div className="bg-white px-6 py-4.5 border-b border-gray-100 flex items-center justify-between">
                  <h2 className="text-base font-black text-gray-800 tracking-tight">
                    My balance
                  </h2>
                  <span className="text-[10px] text-gray-400 font-extrabold uppercase tracking-widest">
                    Account: Current
                  </span>
                </div>

                {/* Content inner area */}
                <div className="p-6 flex flex-col gap-5">
                  
                  {/* Balance details card matching screenshot */}
                  <div className="bg-[#faf9f6] border border-gray-100 rounded-2xl p-6.5 flex flex-col gap-4">
                    
                    {/* Header line of card */}
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-1.5">
                        {/* datazone4 style branded badge */}
                        <div className="bg-[#3db83a] text-white px-2.5 py-1 rounded font-black tracking-tighter text-xs uppercase">
                          datazone4
                        </div>
                        <span className="text-xs text-gray-400 font-bold">Wallet</span>
                      </div>

                      {/* Right aligned balance value */}
                      <span className="text-base font-black text-gray-800">
                        GHC {balance}
                      </span>
                    </div>

                    {/* Middle description block */}
                    <p className="text-xs text-gray-500 font-semibold leading-relaxed max-w-lg">
                      Use this money to buy Premium Services and run Pro Sales campaigns on datazone4
                    </p>

                    {/* Recharge button aligned to right bottom or simple flex right */}
                    <div className="flex justify-end mt-2">
                      <button
                        onClick={() => setShowRechargeModal(true)}
                        className="bg-white hover:bg-[#3db83a]/5 text-[#3db83a] border border-[#3db83a] font-black text-xs px-6 py-2 rounded-xl transition-all duration-200 cursor-pointer hover:shadow-2xs active:scale-95 flex items-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Recharge</span>
                      </button>
                    </div>

                  </div>

                  {/* Linked Mobile Money Card */}
                  <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-3xs flex flex-col sm:flex-row items-center justify-between gap-4 text-left">
                    <div className="flex items-center gap-3.5 w-full">
                      <div className="bg-yellow-50 text-yellow-600 p-3 rounded-2xl border border-yellow-100/60 shrink-0">
                        <Smartphone className="w-5 h-5 animate-pulse" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="text-xs font-black text-gray-800 uppercase tracking-wider">Linked Mobile Money Account</h4>
                          <span className="bg-green-100 text-green-800 text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1 shrink-0">
                            <Check className="w-2.5 h-2.5 stroke-[3]" /> Active Link
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 font-semibold mt-1">
                          Connected Network: <span className="text-gray-800 font-extrabold uppercase">{profile.momoNetwork === 'mtn' ? 'MTN MoMo' : profile.momoNetwork === 'telecel' ? 'Telecel' : 'AT Money'}</span> • Number: <span className="text-gray-800 font-extrabold">{profile.momoNumber}</span>
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowSettingsModal(true)}
                      className="bg-gray-100 hover:bg-[#3db83a]/10 hover:text-[#3db83a] text-gray-700 text-[10px] font-black px-4 py-2.5 rounded-xl transition cursor-pointer shrink-0 uppercase tracking-wider hover:scale-105 active:scale-95"
                    >
                      Change Link
                    </button>
                  </div>

                  {/* Want to sell faster link section */}
                  <div className="text-center py-4 flex flex-col items-center justify-center gap-1">
                    <span className="text-xs text-gray-400 font-bold">
                      Want to sell faster?
                    </span>
                    <button
                      onClick={() => setActiveTab('premium')}
                      className="text-[#3db83a] hover:text-[#2fa82c] font-black text-xs hover:underline cursor-pointer flex items-center gap-1"
                    >
                      <span>Subscribe to Boost Plan</span>
                      <ArrowRight className="w-3.5 h-3.5 animate-pulse" />
                    </button>
                  </div>

                </div>
              </div>
            )}

            {/* 2. MAKE MONEY TAB VIEW */}
            {activeTab === 'make-money' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col gap-6">
                <div>
                  <h3 className="text-base font-black text-gray-800 tracking-tight">Make Money with datazone4 Classifieds</h3>
                  <p className="text-xs text-gray-400 font-semibold mt-1">Join our dealer partnership programs and premium seller networks.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-[#fcfbf9] border border-gray-100 rounded-2xl p-5 flex flex-col gap-3">
                    <div className="bg-green-50 text-[#3db83a] w-10 h-10 rounded-xl flex items-center justify-center shrink-0">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-gray-800 uppercase tracking-wider">Become a Certified Agent</h4>
                      <p className="text-[11px] text-gray-500 font-semibold leading-relaxed mt-1">Verify listed properties, cars, and electronics in your neighborhood and earn up to GH₵ 100 per successful inspection verification!</p>
                    </div>
                    <button onClick={() => alert('Agent application registered! Our community manager in Accra will follow up with you on WhatsApp.')} className="mt-auto bg-[#3db83a] hover:bg-[#2fa82c] text-white text-[11px] font-bold py-2 px-3 rounded-lg text-center transition cursor-pointer">
                      Apply Now
                    </button>
                  </div>

                  <div className="bg-[#fcfbf9] border border-gray-100 rounded-2xl p-5 flex flex-col gap-3">
                    <div className="bg-orange-50 text-[#ff7c00] w-10 h-10 rounded-xl flex items-center justify-center shrink-0">
                      <Gift className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-gray-800 uppercase tracking-wider">Invite Friends & Earn</h4>
                      <p className="text-[11px] text-gray-500 font-semibold leading-relaxed mt-1">Share your unique dealer affiliate code with other classified merchants. Earn GH₵ 10 directly inside your wallet on their first recharge!</p>
                    </div>
                    <div className="mt-auto p-2 bg-white rounded-lg border border-gray-100 flex items-center justify-between">
                      <code className="text-xs font-extrabold text-[#ff7c00]">DATAZONE4-KOFI-MTN</code>
                      <button onClick={() => alert('Referral link copied to clipboard!')} className="text-xs font-black text-[#3db83a] hover:underline cursor-pointer">Copy</button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 3. PREMIUM SERVICES TAB VIEW */}
            {activeTab === 'premium' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col gap-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-base font-black text-gray-800 tracking-tight">Boost Packages & Premium Services</h3>
                    <p className="text-xs text-gray-400 font-semibold mt-1">Dramatically accelerate sales by pinning your ads to top locations.</p>
                  </div>
                  {subscriptionSuccess && (
                    <div className="bg-green-50 border border-green-100 text-green-800 text-[10px] font-bold px-3 py-2 rounded-xl flex items-center gap-1.5">
                      <CheckCircle className="w-3.5 h-3.5 text-green-500" />
                      <span>Subscribed to {subscriptionSuccess} successfully!</span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                  {/* Basic boost card */}
                  <div className="border border-gray-150 rounded-2xl p-5 flex flex-col gap-4 hover:border-gray-300 transition duration-200">
                    <div>
                      <span className="text-[9px] font-black tracking-widest text-[#3db83a] uppercase">STANDARD BOOST</span>
                      <h4 className="text-lg font-black text-gray-800 mt-1">Gold Plan</h4>
                      <div className="flex items-baseline gap-1 mt-2">
                        <span className="text-xl font-black text-gray-900">GH₵ 30</span>
                        <span className="text-[10px] font-semibold text-gray-400">/ 15 Days</span>
                      </div>
                    </div>
                    <ul className="flex flex-col gap-2 text-[11px] text-gray-500 font-semibold flex-1">
                      <li className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-[#3db83a] shrink-0" />
                        <span>3x Higher Visibility</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-[#3db83a] shrink-0" />
                        <span>Top Search Placements</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-[#3db83a] shrink-0" />
                        <span>Renewed automatically</span>
                      </li>
                    </ul>
                    <button
                      onClick={() => handleSubscribePlan('Gold', 30)}
                      disabled={subscribingPlan !== null}
                      className="bg-gray-100 hover:bg-[#3db83a] hover:text-white text-gray-800 text-xs font-black py-2.5 rounded-xl text-center transition cursor-pointer select-none"
                    >
                      {subscribingPlan === 'Gold' ? 'Activating...' : 'Activate for GH₵ 30'}
                    </button>
                  </div>

                  {/* VIP extreme card */}
                  <div className="border-2 border-[#ff7c00] rounded-2xl p-5 flex flex-col gap-4 relative shadow-md hover:scale-[1.01] transition duration-200 bg-white">
                    <span className="absolute -top-3 left-4 bg-[#ff7c00] text-white text-[8px] font-black uppercase tracking-wider px-2 py-0.5 rounded">Most popular</span>
                    <div>
                      <span className="text-[9px] font-black tracking-widest text-[#ff7c00] uppercase">PREMIUM VIP</span>
                      <h4 className="text-lg font-black text-gray-800 mt-1">Diamond Plan</h4>
                      <div className="flex items-baseline gap-1 mt-2">
                        <span className="text-xl font-black text-gray-900">GH₵ 50</span>
                        <span className="text-[10px] font-semibold text-gray-400">/ 30 Days</span>
                      </div>
                    </div>
                    <ul className="flex flex-col gap-2 text-[11px] text-gray-500 font-semibold flex-1">
                      <li className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-[#ff7c00] shrink-0" />
                        <span>10x Higher Visibility</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-[#ff7c00] shrink-0" />
                        <span>Featured Banner Placement</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-[#ff7c00] shrink-0" />
                        <span>AI Autopost Assistant</span>
                      </li>
                    </ul>
                    <button
                      onClick={() => handleSubscribePlan('Diamond', 50)}
                      disabled={subscribingPlan !== null}
                      className="bg-[#ff7c00] hover:bg-[#e66a00] text-white text-xs font-black py-2.5 rounded-xl text-center transition cursor-pointer select-none"
                    >
                      {subscribingPlan === 'Diamond' ? 'Activating...' : 'Activate for GH₵ 50'}
                    </button>
                  </div>

                  {/* Ultimate Enterprise card */}
                  <div className="border border-gray-150 rounded-2xl p-5 flex flex-col gap-4 hover:border-gray-300 transition duration-200">
                    <div>
                      <span className="text-[9px] font-black tracking-widest text-[#3db83a] uppercase">ENTERPRISE CLASSIFIED</span>
                      <h4 className="text-lg font-black text-gray-800 mt-1">Merchant Plan</h4>
                      <div className="flex items-baseline gap-1 mt-2">
                        <span className="text-xl font-black text-gray-900">GH₵ 120</span>
                        <span className="text-[10px] font-semibold text-gray-400">/ 60 Days</span>
                      </div>
                    </div>
                    <ul className="flex flex-col gap-2 text-[11px] text-gray-500 font-semibold flex-1">
                      <li className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-[#3db83a] shrink-0" />
                        <span>Unlimited Active Ads</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-[#3db83a] shrink-0" />
                        <span>Verified Merchant Badge</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-[#3db83a] shrink-0" />
                        <span>Priority Support Portal</span>
                      </li>
                    </ul>
                    <button
                      onClick={() => handleSubscribePlan('Merchant', 120)}
                      disabled={subscribingPlan !== null}
                      className="bg-gray-100 hover:bg-[#3db83a] hover:text-white text-gray-800 text-xs font-black py-2.5 rounded-xl text-center transition cursor-pointer select-none"
                    >
                      {subscribingPlan === 'Merchant' ? 'Activating...' : 'Activate for GH₵ 120'}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 4. FOLLOWERS TAB VIEW */}
            {activeTab === 'followers' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col gap-6">
                <div>
                  <h3 className="text-base font-black text-gray-800 tracking-tight">Followers Directory</h3>
                  <p className="text-xs text-gray-400 font-semibold mt-1">Users subscribed to your listings feed to receive instant updates when you post new items.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-center gap-3.5 p-4.5 bg-gray-50 rounded-2xl border border-gray-100">
                    <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=100&q=80" alt="Ama" referrerPolicy="no-referrer" className="w-12 h-12 rounded-full object-cover border border-gray-200" />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-black text-gray-800 truncate">Ama Owusu</h4>
                      <p className="text-[10px] text-gray-400 font-semibold mt-0.5">Accra • Following since May 2025</p>
                      <span className="text-[9px] bg-green-100 text-green-800 font-bold px-2 py-0.2 rounded mt-1.5 inline-block">Active Buyer</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3.5 p-4.5 bg-gray-50 rounded-2xl border border-gray-100">
                    <img src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=100&q=80" alt="Emmanuel" referrerPolicy="no-referrer" className="w-12 h-12 rounded-full object-cover border border-gray-200" />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-black text-gray-800 truncate">Emmanuel Boateng</h4>
                      <p className="text-[10px] text-gray-400 font-semibold mt-0.5">Kumasi • Following since March 2026</p>
                      <span className="text-[9px] bg-green-100 text-green-800 font-bold px-2 py-0.2 rounded mt-1.5 inline-block">Verified Seller</span>
                    </div>
                  </div>
                </div>

                <button onClick={() => alert('Followers broadcast feature is limited in this preview. Once loaded in production, this will draft instant WhatsApp/SMS notification templates for your listings!')} className="w-full bg-[#3db83a] hover:bg-[#2fa82c] text-white text-xs font-black py-3 rounded-xl transition cursor-pointer flex items-center justify-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  <span>Send Broadcast Update to Followers</span>
                </button>
              </div>
            )}

            {/* 5. MY ADVERTS TAB VIEW - WITH GPS CAPTURE & RAW PHOTOS */}
            {activeTab === 'my-adverts' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-xs p-5 flex flex-col gap-4">
                <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                  <h3 className="font-extrabold text-gray-800 text-sm tracking-tight">
                    Manage Posted Ads Inventory
                  </h3>
                  <span className="text-[10px] text-gray-400 font-extrabold bg-gray-50 px-2.5 py-1 rounded-md">
                    Total: {myListings.length}
                  </span>
                </div>

                {/* Simulated file input for raw uploads */}
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleRAWFileChange} 
                  className="hidden" 
                  accept="image/*"
                />

                {loading ? (
                  <div className="py-12 flex flex-col items-center justify-center text-gray-400">
                    <Loader2 className="w-7 h-7 text-[#3db83a] animate-spin mb-3" />
                    <span className="text-xs font-semibold animate-pulse">Updating inventory...</span>
                  </div>
                ) : myListings.length === 0 ? (
                  <div className="py-16 text-center text-gray-400 flex flex-col items-center justify-center">
                    <ShoppingBag className="w-12 h-12 text-gray-200 mb-2" />
                    <h4 className="font-bold text-gray-700 text-sm mb-1">No Ads Posted Yet</h4>
                    <p className="text-xs max-w-xs mb-4">You currently do not have any items listed for sale in Ghana.</p>
                    <button
                      onClick={onPostAdClick}
                      className="bg-[#3db83a] hover:bg-[#2fa82c] text-white text-xs font-bold px-4 py-2 rounded-lg cursor-pointer transition shadow-xs"
                    >
                      Post Your First Ad Now
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col gap-5">
                    {/* 📊 Listing Performance Analytics Section */}
                    <div className="bg-[#faf9f6] border border-gray-150 rounded-2xl p-4.5 flex flex-col gap-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="bg-[#3db83a]/10 text-[#3db83a] p-2 rounded-xl">
                            <TrendingUp className="w-4 h-4" />
                          </div>
                          <div className="text-left">
                            <h4 className="text-xs font-black text-gray-800 uppercase tracking-wider">Listing Traffic & Conversion</h4>
                            <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Ad Views vs Chat Inquiries</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-[8px] text-gray-400 font-bold block uppercase tracking-wider">Estimated Inquiries</span>
                          <span className="text-xs font-black text-[#ff7c00]">
                            {myListings.reduce((acc, ad) => {
                              let hash = 0;
                              for (let i = 0; i < ad.id.length; i++) {
                                hash += ad.id.charCodeAt(i);
                              }
                              const conv = 0.08 + (hash % 10) * 0.02;
                              return acc + Math.max(1, Math.round(ad.views * conv));
                            }, 0)} Chats
                          </span>
                        </div>
                      </div>

                      <div className="w-full h-48 select-none mt-1">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={myListings.map(ad => {
                              let hash = 0;
                              for (let i = 0; i < ad.id.length; i++) {
                                hash += ad.id.charCodeAt(i);
                              }
                              const conversionRate = 0.08 + (hash % 10) * 0.02;
                              const chats = Math.max(1, Math.round(ad.views * conversionRate));
                              return {
                                name: ad.title.length > 12 ? ad.title.substring(0, 12) + '...' : ad.title,
                                views: ad.views,
                                chats: chats,
                              };
                            })}
                            margin={{ top: 5, right: 5, left: -20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" stroke="#f1f1f1" vertical={false} />
                            <XAxis 
                              dataKey="name" 
                              stroke="#8e8e8e" 
                              fontSize={9}
                              fontWeight="bold"
                              tickLine={false}
                              axisLine={false}
                            />
                            <YAxis 
                              stroke="#8e8e8e" 
                              fontSize={9}
                              fontWeight="bold"
                              tickLine={false}
                              axisLine={false}
                              domain={[0, 'auto']}
                            />
                            <Tooltip 
                              contentStyle={{ 
                                backgroundColor: '#fff', 
                                borderColor: '#f1f1f1',
                                borderRadius: '12px',
                                boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
                                fontSize: '10px',
                                fontWeight: 'bold'
                              }}
                            />
                            <Legend 
                              verticalAlign="top" 
                              height={28} 
                              iconType="circle"
                              iconSize={6}
                              wrapperStyle={{ fontSize: '9px', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '0.5px' }}
                            />
                            <Bar 
                              name="Views"
                              dataKey="views" 
                              fill="#3db83a" 
                              radius={[3, 3, 0, 0]}
                            />
                            <Bar 
                              name="Chats"
                              dataKey="chats" 
                              fill="#ff7c00" 
                              radius={[3, 3, 0, 0]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    <div className="flex flex-col gap-4.5">
                      {myListings.map(ad => (
                      <div
                        key={ad.id}
                        onClick={() => onViewDetails(ad.id)}
                        className="flex flex-col gap-4 p-4.5 bg-[#fcfbf9] hover:bg-gray-50 border border-gray-100 rounded-2xl cursor-pointer transition-all duration-200 relative overflow-hidden group"
                      >
                        {/* Primary meta block */}
                        <div className="flex flex-col sm:flex-row gap-4">
                          {/* Thumbnail */}
                          <div className="w-full sm:w-28 aspect-video sm:aspect-square bg-gray-100 rounded-xl overflow-hidden shrink-0 border border-gray-200">
                            <img
                              src={ad.imageUrls[0]}
                              alt={ad.title}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                            />
                          </div>

                          {/* Meta detail */}
                          <div className="flex-1 min-w-0 flex flex-col justify-between">
                            <div>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-[9px] font-bold tracking-wider text-[#ff7c00] uppercase">
                                  {ad.subCategory || ad.categoryName}
                                </span>
                                <span className={`text-[8px] font-bold px-2 py-0.2 rounded-full ${
                                  ad.status === 'active' ? 'bg-green-100 text-[#3db83a]' : 'bg-gray-200 text-gray-600'
                                }`}>
                                  {ad.status === 'active' ? 'Active' : 'Closed / Sold'}
                                </span>
                              </div>

                              <h4 className="font-bold text-gray-800 text-xs sm:text-sm truncate mt-1 leading-snug group-hover:text-[#3db83a] transition-colors">
                                {ad.title}
                              </h4>

                              <span className="text-xs sm:text-sm font-black text-gray-900 mt-1 block">
                                GH₵ {ad.price.toLocaleString()}
                              </span>
                            </div>

                            <div className="flex items-center justify-between text-[10px] text-gray-400 mt-2 pt-2 border-t border-gray-100/50">
                              <span className="truncate">{ad.neighborhood}, {ad.region}</span>
                              <span className="font-extrabold flex items-center gap-1">
                                <span className="w-1.5 h-1.5 bg-[#3db83a] rounded-full"></span>
                                {ad.views} page views
                              </span>
                            </div>
                          </div>

                          {/* Top right floating basic edit delete button actions */}
                          <div className="flex sm:flex-col gap-2 shrink-0 justify-end sm:border-l sm:border-gray-100 sm:pl-3">
                            {ad.status === 'active' && (
                              <button
                                onClick={(e) => handleCloseAd(ad.id, e)}
                                className="flex-1 sm:flex-none border border-yellow-200 hover:border-yellow-400 bg-yellow-50 text-yellow-800 font-extrabold text-[10px] px-2.5 py-1.5 rounded-lg flex items-center justify-center gap-1 transition cursor-pointer select-none"
                              >
                                <CheckCircle className="w-3.5 h-3.5" />
                                <span>Mark Sold</span>
                              </button>
                            )}
                            <button
                              onClick={(e) => handleDeleteAd(ad.id, e)}
                              className="flex-1 sm:flex-none border border-red-100 hover:border-red-300 bg-red-50 text-red-600 font-extrabold text-[10px] px-2.5 py-1.5 rounded-lg flex items-center justify-center gap-1 transition cursor-pointer select-none"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Delete</span>
                            </button>
                          </div>
                        </div>

                        {/* SUB-SECTION 1: GPS Capture details */}
                        <div className="bg-white rounded-xl p-3.5 border border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3" onClick={(e) => e.stopPropagation()}>
                          <div className="flex flex-col gap-1">
                            <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider flex items-center gap-1">
                              <MapPin className="w-3.5 h-3.5 text-[#3db83a]" />
                              <span>Verified GPS Address & Coordinates</span>
                            </span>
                            <div className="flex items-center gap-2 mt-1 flex-wrap">
                              {ad.gpsAddress ? (
                                <span className="text-xs font-black text-gray-700 bg-gray-50 border border-gray-150 px-2 py-0.5 rounded">
                                  🗺️ {ad.gpsAddress}
                                </span>
                              ) : (
                                <span className="text-xs font-bold text-gray-400 italic">No GPS address verified</span>
                              )}
                              {ad.gpsCoordinates && (
                                <span className="text-[10px] font-semibold text-gray-500">
                                  ({ad.gpsCoordinates.latitude.toFixed(6)}, {ad.gpsCoordinates.longitude.toFixed(6)})
                                </span>
                              )}
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={(e) => handleCaptureGPS(ad.id, e)}
                            disabled={locatingId !== null}
                            className="bg-[#faf9f6] hover:bg-[#3db83a]/10 hover:border-[#3db83a] text-[#3db83a] border border-gray-200 text-[10px] font-black px-3 py-2 rounded-lg flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer disabled:opacity-50 shrink-0"
                          >
                            {locatingId === ad.id ? (
                              <>
                                <Loader2 className="w-3.5 h-3.5 animate-spin text-[#3db83a]" />
                                <span>Locating via Sensor...</span>
                              </>
                            ) : gpsCaptureSuccess === ad.id ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-green-600 stroke-[3]" />
                                <span className="text-green-600">Location Locked!</span>
                              </>
                            ) : (
                              <>
                                <Navigation className="w-3.5 h-3.5 text-[#3db83a] animate-bounce" />
                                <span>Verify Item GPS Location</span>
                              </>
                            )}
                          </button>
                        </div>

                        {/* SUB-SECTION 2: Access original pictures upload */}
                        <div className="bg-white rounded-xl p-3.5 border border-gray-100 flex flex-col gap-2.5" onClick={(e) => e.stopPropagation()}>
                          <div className="flex justify-between items-center pb-1.5 border-b border-gray-50">
                            <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider flex items-center gap-1">
                              <Image className="w-3.5 h-3.5 text-[#ff7c00]" />
                              <span>Original Photo RAW Uploads ({ad.originalImagesMetadata?.length || 0})</span>
                            </span>
                            
                            <button
                              type="button"
                              onClick={(e) => triggerRAWUpload(ad.id, e)}
                              disabled={uploadingId !== null}
                              className="text-[10px] text-[#ff7c00] hover:text-[#e66a00] font-black cursor-pointer flex items-center gap-1"
                            >
                              {uploadingId === ad.id ? (
                                <>
                                  <Loader2 className="w-3 h-3 animate-spin" />
                                  <span>Uploading...</span>
                                </>
                              ) : (
                                <>
                                  <UploadCloud className="w-3.5 h-3.5" />
                                  <span>Upload Raw JPEG</span>
                                </>
                              )}
                            </button>
                          </div>

                          {ad.originalImagesMetadata && ad.originalImagesMetadata.length > 0 ? (
                            <div className="flex flex-col gap-1.5">
                              {ad.originalImagesMetadata.map((img, idx) => (
                                <div key={idx} className="flex justify-between items-center text-[10px] bg-gray-50 p-2 rounded border border-gray-100 hover:border-gray-200">
                                  <span className="font-bold text-gray-600 truncate max-w-[280px]">📄 {img.name}</span>
                                  <span className="shrink-0 bg-white text-gray-500 px-1.5 py-0.5 rounded text-[8px] font-bold border border-gray-100 uppercase">{img.size} ({img.type.split('/')[1]?.toUpperCase() || 'JPEG'})</span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <span className="text-xs text-gray-400 italic">No original high-definition RAW files uploaded. Upload original photographs to prove listing authenticity and gain a "Verified Real" seal.</span>
                          )}
                        </div>

                        {/* SUB-SECTION 3: AI Traffic Prediction & Bump Ad Feature */}
                        <div className="bg-white rounded-xl p-3.5 border border-gray-100 flex flex-col gap-3" onClick={(e) => e.stopPropagation()}>
                          <div className="flex justify-between items-center pb-2 border-b border-gray-50">
                            <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                              <Sparkles className="w-3.5 h-3.5 text-[#3db83a]" />
                              <span>AI Traffic Optimizer & Bump Assistant</span>
                            </span>
                            
                            {ad.status === 'active' && !forecastResults[ad.id] && (
                              <button
                                type="button"
                                disabled={loadingForecasts[ad.id]}
                                onClick={() => handleFetchForecast(ad.id, ad.title, ad.categoryName, ad.country, ad.region || 'Greater Accra')}
                                className="text-[10px] text-[#3db83a] hover:text-[#2fa82c] font-black cursor-pointer flex items-center gap-1 bg-[#3db83a]/5 px-2.5 py-1 rounded-md border border-[#3db83a]/10 hover:border-[#3db83a]/25 transition"
                              >
                                {loadingForecasts[ad.id] ? (
                                  <>
                                    <Loader2 className="w-3 h-3 animate-spin" />
                                    <span>Analyzing Traffic...</span>
                                  </>
                                ) : (
                                  <>
                                    <TrendingUp className="w-3 h-3" />
                                    <span>Get Free AI Traffic Forecast</span>
                                  </>
                                )}
                              </button>
                            )}
                          </div>

                          {loadingForecasts[ad.id] && (
                            <div className="py-6 flex flex-col items-center justify-center text-center gap-2">
                              <Loader2 className="w-6 h-6 animate-spin text-[#3db83a]" />
                              <div className="text-xs font-bold text-gray-700">Querying Bozseller Local Traffic Engine...</div>
                              <div className="text-[10px] text-gray-400">Gemini AI is analyzing category-specific visitor schedules in {ad.region}.</div>
                            </div>
                          )}

                          {forecastResults[ad.id] && (
                            <div className="flex flex-col gap-3.5">
                              {/* Summary Banner */}
                              <div className="grid grid-cols-2 gap-2 bg-[#faf9f6] p-3 rounded-lg border border-gray-150 text-left">
                                <div>
                                  <span className="text-[8px] text-gray-400 font-bold uppercase tracking-wider block">Best Day To Promote</span>
                                  <span className="text-xs font-black text-gray-800 flex items-center gap-1.5 mt-0.5">
                                    <Clock className="w-3.5 h-3.5 text-[#ff7c00]" />
                                    {forecastResults[ad.id].bestDayOfWeek}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-[8px] text-gray-400 font-bold uppercase tracking-wider block">Optimal Hour Peak</span>
                                  <span className="text-xs font-black text-[#3db83a] flex items-center gap-1.5 mt-0.5">
                                    <Zap className="w-3.5 h-3.5" />
                                    {forecastResults[ad.id].bestTimeToday}
                                  </span>
                                </div>
                              </div>

                              {/* Traffic Reason and Analysis */}
                              <div className="text-left">
                                <span className="text-[8px] text-gray-400 font-black uppercase tracking-wider block mb-1">Local Audience Analytics</span>
                                <p className="text-xs text-gray-600 leading-relaxed font-medium bg-gray-50/50 p-2.5 rounded-lg border border-gray-100">
                                  {forecastResults[ad.id].trafficPeakReason}
                                </p>
                              </div>

                              {/* Timeline Schedule */}
                              <div className="text-left">
                                <span className="text-[8px] text-gray-400 font-black uppercase tracking-wider block mb-2">Optimal Re-indexing Slots (Daily)</span>
                                <div className="grid grid-cols-3 gap-2">
                                  {forecastResults[ad.id].bumpSchedule.map((slot: any, idx: number) => (
                                    <div 
                                      key={idx} 
                                      className={`p-2 rounded-lg border text-center flex flex-col gap-0.5 relative ${
                                        slot.recommended 
                                          ? 'bg-[#3db83a]/5 border-[#3db83a]/30 text-gray-800' 
                                          : 'bg-white border-gray-100 text-gray-600'
                                      }`}
                                    >
                                      {slot.recommended && (
                                        <span className="absolute -top-1.5 left-1/2 -translate-x-1/2 bg-[#3db83a] text-white text-[6px] font-bold px-1 py-0.2 rounded-full uppercase">
                                          Best Slot
                                        </span>
                                      )}
                                      <span className="text-[10px] font-black">{slot.time}</span>
                                      <span className="text-[8px] text-gray-400 font-bold uppercase">{slot.label}</span>
                                      <span className={`text-[9px] font-bold mt-1 ${slot.recommended ? 'text-[#3db83a]' : 'text-gray-500'}`}>
                                        {slot.multiplier}
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              </div>

                              {/* Strategy Recommendation */}
                              <div className="text-left pt-1 border-t border-gray-100/60">
                                <span className="text-[8px] text-[#ff7c00] font-black uppercase tracking-wider block mb-1">Strategic Advice</span>
                                <p className="text-xs text-gray-600 font-semibold italic">
                                  "{forecastResults[ad.id].suggestedStrategy}"
                                </p>
                              </div>
                            </div>
                          )}

                          {/* Quick Instant Boost / Bump Ad trigger button */}
                          {ad.status === 'active' && (
                            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2.5 border-t border-gray-50/80">
                              <div className="text-left">
                                <span className="text-[9px] font-black text-gray-700 block">Instant Feed Bump</span>
                                <p className="text-[10px] text-gray-400 leading-snug">
                                  Updating listing creation date re-indexes it to the very top of Bozseller.
                                </p>
                              </div>

                              <button
                                type="button"
                                disabled={boostingAds[ad.id] || boostSuccess[ad.id]}
                                onClick={() => handleBoostAd(ad.id)}
                                className={`w-full sm:w-auto px-4 py-2 rounded-lg text-xs font-black flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer shadow-xs ${
                                  boostSuccess[ad.id]
                                    ? 'bg-green-100 text-[#3db83a] border border-[#3db83a]/20'
                                    : 'bg-[#ff7c00] hover:bg-[#e66a00] text-white'
                                }`}
                              >
                                {boostingAds[ad.id] ? (
                                  <>
                                    <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
                                    <span>Bumping Listing...</span>
                                  </>
                                ) : boostSuccess[ad.id] ? (
                                  <>
                                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                                    <span>Bumped successfully!</span>
                                  </>
                                ) : (
                                  <>
                                    <Zap className="w-3.5 h-3.5" />
                                    <span>Boost Visibility Now</span>
                                  </>
                                )}
                              </button>
                            </div>
                          )}
                        </div>

                      </div>
                    ))}
                  </div>
                </div>
              )}
              </div>
            )}

            {/* 6. FEEDBACK TAB VIEW */}
            {activeTab === 'feedback' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col gap-6">
                <div>
                  <h3 className="text-base font-black text-gray-800 tracking-tight">Your Feedback & Reviews</h3>
                  <p className="text-xs text-gray-400 font-semibold mt-1">Real ratings from buyers who communicated with you on Bozseller.</p>
                </div>

                <div className="bg-gradient-to-r from-yellow-50 to-amber-50 rounded-2xl p-5 border border-yellow-100 flex items-center gap-4.5">
                  <div className="text-center shrink-0">
                    <span className="text-3xl font-black text-gray-800">4.8</span>
                    <span className="text-[10px] text-gray-400 font-bold block uppercase tracking-wider mt-0.5">out of 5.0</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      ))}
                    </div>
                    <p className="text-xs text-gray-600 font-semibold leading-relaxed mt-1.5">
                      "Frab is an exceptional merchant! Communicated immediately and met at a secure location in East Legon. The laptop matches the description exactly."
                    </p>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest pb-1 border-b border-gray-100">Feedback history</span>
                  <div className="flex items-start gap-3 py-2">
                    <div className="w-8 h-8 rounded-full bg-gray-150 shrink-0 text-xs font-bold flex items-center justify-center">K</div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-gray-800">Kofi Annan</span>
                        <span className="text-[9px] text-gray-400 font-bold">2 weeks ago</span>
                      </div>
                      <p className="text-xs text-gray-500 font-medium leading-relaxed mt-0.5">Smooth negotiation and prompt WhatsApp communication. Recommended buyer!</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 7. REQUEST HELP TAB VIEW */}
            {activeTab === 'request-help' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col gap-6">
                <div>
                  <h3 className="text-base font-black text-gray-800 tracking-tight">Customer Support Portal</h3>
                  <p className="text-xs text-gray-400 font-semibold mt-1">Our support agents are active 24/7 in Accra, Lagos, and Lomé to secure your trading experience.</p>
                </div>

                <div className="bg-blue-50 border border-blue-100 rounded-xl p-4.5 flex gap-3.5 items-start">
                  <ShieldAlert className="w-6 h-6 text-blue-600 shrink-0 mt-0.5" />
                  <div className="flex-1 text-xs">
                    <h4 className="font-extrabold text-blue-900 uppercase tracking-wide text-[10px]">Anti-Fraud Protection</h4>
                    <p className="text-blue-700 font-semibold leading-relaxed mt-1">Bozseller will never ask you to wire mobile money (Momo) upfront for deliveries. Report any suspicious users asking for prepaid deposits immediately.</p>
                  </div>
                </div>

                <form onSubmit={(e) => { e.preventDefault(); alert('Support ticket received! Agent Kofi from the Accra Head Office will message you shortly.'); }} className="flex flex-col gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Describe your issue</label>
                    <textarea required placeholder="Explain clearly. E.g., I want to report user X or need help activating my Gold Plan..." rows={4} className="w-full bg-white border border-gray-200 focus:border-[#3db83a] rounded-xl p-3 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-[#3db83a]" />
                  </div>
                  <button type="submit" className="bg-[#3db83a] hover:bg-[#2fa82c] text-white text-xs font-black py-2.5 rounded-xl transition cursor-pointer">
                    Submit Support Ticket
                  </button>
                </form>
              </div>
            )}

            {/* 8. FAQ TAB VIEW */}
            {activeTab === 'faq' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col gap-6">
                <div>
                  <h3 className="text-base font-black text-gray-800 tracking-tight">Frequently Asked Questions</h3>
                  <p className="text-xs text-gray-400 font-semibold mt-1">Quick help regarding your wallet balance, premium services, and secure trading.</p>
                </div>

                <div className="flex flex-col gap-4">
                  <div className="pb-3.5 border-b border-gray-100 flex flex-col gap-1">
                    <h4 className="text-xs font-black text-gray-800">How do I recharge my wallet?</h4>
                    <p className="text-xs text-gray-500 font-semibold leading-relaxed">Click the "Recharge" button in the MY BALANCE tab. You can pay safely via MTN Mobile Money, Telecel Cash, AT Money, or a visa card. Recharges are credited instantly.</p>
                  </div>

                  <div className="pb-3.5 border-b border-gray-100 flex flex-col gap-1">
                    <h4 className="text-xs font-black text-gray-800">How do I verify my item's location via GPS?</h4>
                    <p className="text-xs text-gray-500 font-semibold leading-relaxed">Go to the "My adverts" tab in the sidebar. For any active listing, click "Verify Item GPS Location". The app will pull coordinates from your hardware GPS sensor to generate a unique verified address (e.g., GA-183-4921) to increase buyers' trust.</p>
                  </div>

                  <div className="pb-3.5 border-b border-gray-100 flex flex-col gap-1">
                    <h4 className="text-xs font-black text-gray-800">Can I transfer money back to my MoMo wallet?</h4>
                    <p className="text-xs text-gray-500 font-semibold leading-relaxed">Wallet balances can only be used to purchase Premium Classifies Boost Services, and cannot be refunded or converted back to physical currency. Contact helpdesk if you made an erroneous deposit.</p>
                  </div>
                </div>
              </div>
            )}

            {/* 10. TRUST & REPUTATION VERIFICATION CENTER */}
            {activeTab === 'verification' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col gap-6 animate-in fade-in duration-200">
                <div>
                  <h3 className="text-base font-black text-gray-800 tracking-tight">Trust & Verification Center</h3>
                  <p className="text-xs text-gray-400 font-semibold mt-1">
                    Increase buyer responses by up to 300% and build total security across the marketplace.
                  </p>
                </div>

                {/* Case 1: Already Verified Certificate */}
                {profile.verified && (verificationStep === 'start' || verificationStep === 'success') ? (
                  <div className="flex flex-col gap-6 text-center py-6">
                    <div className="mx-auto w-20 h-20 rounded-full bg-green-50 border-4 border-green-100 flex items-center justify-center shadow-xs animate-bounce">
                      <ShieldCheck className="w-11 h-11 text-green-500 fill-green-500/20" />
                    </div>

                    <div>
                      <h4 className="text-lg font-black text-gray-800">Verified Seller Status Active</h4>
                      <p className="text-xs text-gray-500 font-semibold max-w-md mx-auto leading-relaxed mt-1.5">
                        Your account is linked to verified government database registries. A prominent **Verified Seller** trust badge is now displayed on your profile and listings.
                      </p>
                    </div>

                    <div className="bg-gray-50/70 border border-gray-150 rounded-2xl p-5 max-w-md mx-auto w-full text-left flex flex-col gap-3">
                      <div className="flex justify-between items-center text-xs pb-2 border-b border-gray-100">
                        <span className="text-gray-400 font-bold uppercase tracking-wider text-[10px]">Merchant Name</span>
                        <span className="text-gray-800 font-black">{profile.name}</span>
                      </div>
                      <div className="flex justify-between items-center text-xs pb-2 border-b border-gray-100">
                        <span className="text-gray-400 font-bold uppercase tracking-wider text-[10px]">Verification Type</span>
                        <span className="text-gray-800 font-black uppercase">{idType.replace('-', ' ')}</span>
                      </div>
                      <div className="flex justify-between items-center text-xs pb-2 border-b border-gray-100">
                        <span className="text-gray-400 font-bold uppercase tracking-wider text-[10px]">Reputation Score</span>
                        <span className="text-green-600 font-black flex items-center gap-1">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          {profile.rating.toFixed(1)} / 5.0 (99.8% Perfect)
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-400 font-bold uppercase tracking-wider text-[10px]">Security Key</span>
                        <span className="text-gray-500 font-mono text-[10px] uppercase font-bold select-all">BOZ-SEC-{Math.abs(profile.name.length * 74921).toString(16)}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4.5 max-w-2xl mx-auto w-full mt-2">
                      <div className="border border-green-100 bg-green-50/20 p-4 rounded-xl flex flex-col items-center gap-1">
                        <Shield className="w-6 h-6 text-green-600 mb-1" />
                        <h5 className="text-xs font-black text-gray-800">Trust Shield Badge</h5>
                        <p className="text-[10px] text-gray-500 font-semibold leading-relaxed">Buyers transact with ultimate confidence</p>
                      </div>
                      <div className="border border-green-100 bg-green-50/20 p-4 rounded-xl flex flex-col items-center gap-1">
                        <TrendingUp className="w-6 h-6 text-green-600 mb-1" />
                        <h5 className="text-xs font-black text-gray-800">3x Boosted Index</h5>
                        <p className="text-[10px] text-gray-500 font-semibold leading-relaxed">System places verified adverts on top feeds</p>
                      </div>
                      <div className="border border-green-100 bg-green-50/20 p-4 rounded-xl flex flex-col items-center gap-1">
                        <MessageSquare className="w-6 h-6 text-green-600 mb-1" />
                        <h5 className="text-xs font-black text-gray-800">Premium Flagging</h5>
                        <p className="text-[10px] text-gray-500 font-semibold leading-relaxed">Stand out among thousands of local sellers</p>
                      </div>
                    </div>

                    <div className="mt-4 flex flex-col sm:flex-row gap-3 justify-center items-center">
                      <button
                        onClick={() => {
                          const resetProf = { ...profile, verified: false, rating: 4.8 };
                          setProfile(resetProf);
                          localStorage.setItem('dosboz_user_profile', JSON.stringify(resetProf));
                          setVerificationStep('start');
                          setIdNumber('');
                          setIdFileName(null);
                          setSelfieFileName(null);
                          setOtpSent(false);
                          setOtpCode('');
                          setOtpError(null);
                        }}
                        className="text-xs font-bold text-gray-400 hover:text-gray-700 bg-gray-100 hover:bg-gray-200 px-4 py-2.5 rounded-xl transition cursor-pointer flex items-center gap-2"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Reset Verification (Developer Sandbox)</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Case 2: Not Verified Flow states */
                  <div className="flex flex-col gap-6">
                    {/* Horizontal Steps Bar */}
                    {verificationStep !== 'processing' && verificationStep !== 'success' && (
                      <div className="flex justify-between items-center bg-gray-50 border border-gray-100 rounded-2xl p-4.5 gap-2">
                        {[
                          { key: 'start', label: '1. Overview' },
                          { key: 'id-upload', label: '2. Document Scan' },
                          { key: 'selfie-upload', label: '3. Biometric Selfie' },
                          { key: 'phone-otp', label: '4. Phone OTP' }
                        ].map((step, idx) => {
                          const stepsOrder = ['start', 'id-upload', 'selfie-upload', 'phone-otp'];
                          const currentIdx = stepsOrder.indexOf(verificationStep);
                          const isDone = idx < currentIdx;
                          const isActive = step.key === verificationStep;

                          return (
                            <React.Fragment key={step.key}>
                              <div className="flex items-center gap-2">
                                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black ${
                                  isDone 
                                    ? 'bg-[#3db83a] text-white' 
                                    : isActive 
                                      ? 'bg-gray-800 text-white ring-4 ring-gray-100' 
                                      : 'bg-gray-200 text-gray-500'
                                }`}>
                                  {isDone ? '✓' : idx + 1}
                                </span>
                                <span className={`text-[11px] font-bold hidden md:inline ${isActive ? 'text-gray-800 font-black' : 'text-gray-400'}`}>
                                  {step.label.split('. ')[1]}
                                </span>
                              </div>
                              {idx < 3 && <div className={`flex-1 h-0.5 ${idx < currentIdx ? 'bg-[#3db83a]' : 'bg-gray-200'}`} />}
                            </React.Fragment>
                          );
                        })}
                      </div>
                    )}

                    {/* Step Content: Start overview */}
                    {verificationStep === 'start' && (
                      <div className="flex flex-col gap-6">
                        <div className="bg-gradient-to-br from-green-50/50 to-[#3db83a]/5 border border-green-100 rounded-2xl p-6 flex flex-col md:flex-row items-center gap-6 text-left">
                          <div className="w-14 h-14 rounded-full bg-green-50 flex items-center justify-center border border-green-100 shrink-0">
                            <ShieldCheck className="w-8 h-8 text-green-600 fill-green-100" />
                          </div>
                          <div>
                            <h4 className="text-base font-black text-gray-800 leading-tight">Secure Ghanaian & West-African Citizen Registry Verification</h4>
                            <p className="text-xs text-gray-500 font-semibold leading-relaxed mt-1">
                              Bozseller utilizes cryptographically secure matching API nodes connected with national databases (such as the Ghana National Identification Authority card registry) to verify seller identities instantly and prevent online marketplaces spoofing.
                            </p>
                          </div>
                        </div>

                        <div className="flex flex-col gap-3 text-left">
                          <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest pb-1.5 border-b border-gray-100">Verification Steps & Requirements</span>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4.5">
                            <div className="border border-gray-100 rounded-xl p-4 flex flex-col gap-1.5">
                              <span className="text-[10px] font-black text-green-700 uppercase tracking-wider">01 / National ID Card</span>
                              <p className="text-xs font-semibold text-gray-800">Govt Issued ID Card</p>
                              <p className="text-[11px] text-gray-500 leading-relaxed">Provide your Ghana Card, Nigerian NIN, or Driver's License number and upload a clear front-facing document photograph.</p>
                            </div>
                            <div className="border border-gray-100 rounded-xl p-4 flex flex-col gap-1.5">
                              <span className="text-[10px] font-black text-green-700 uppercase tracking-wider">02 / Biometric Live Face Scan</span>
                              <p className="text-xs font-semibold text-gray-800">3D Face Geometry</p>
                              <p className="text-[11px] text-gray-500 leading-relaxed">Upload or take a live camera selfie to securely compare face structures with your national identity document database record.</p>
                            </div>
                            <div className="border border-gray-100 rounded-xl p-4 flex flex-col gap-1.5">
                              <span className="text-[10px] font-black text-green-700 uppercase tracking-wider">03 / Mobile Network OTP</span>
                              <p className="text-xs font-semibold text-gray-800">Phone Owner Audit</p>
                              <p className="text-[11px] text-gray-500 leading-relaxed">Perform a secure OTP SMS verification matching your registered MTN, Telecel, AT or Airtel networks mobile phone account.</p>
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={() => setVerificationStep('id-upload')}
                          className="bg-[#3db83a] hover:bg-[#2fa82c] text-white text-xs font-black py-3.5 rounded-xl transition cursor-pointer flex items-center justify-center gap-2"
                        >
                          <span>Get Verified Now</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      </div>
                    )}

                    {/* Step Content: ID Document Upload */}
                    {verificationStep === 'id-upload' && (
                      <div className="flex flex-col gap-5 text-left">
                        <div className="flex flex-col gap-1">
                          <h4 className="text-sm font-black text-gray-800">Step 1: Upload Government Identification Document</h4>
                          <p className="text-xs text-gray-400 font-semibold">Your files are encrypted using AES-256 and never shared publicly.</p>
                        </div>

                        <div className="flex flex-col gap-4">
                          {/* Choose Card Type */}
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Choose Identification Document</label>
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                              {[
                                { key: 'ghana-card', label: 'Ghana Card' },
                                { key: 'nin-card', label: 'NIN Card (NGA)' },
                                { key: 'togo-id', label: 'Togo National ID' },
                                { key: 'driver-license', label: 'Driver\'s License' }
                              ].map(item => (
                                <button
                                  key={item.key}
                                  type="button"
                                  onClick={() => setIdType(item.key as any)}
                                  className={`p-3 text-xs font-black rounded-xl border text-center transition cursor-pointer ${
                                    idType === item.key 
                                      ? 'border-[#3db83a] bg-[#3db83a]/5 text-green-800' 
                                      : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                                  }`}
                                >
                                  {item.label}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* ID Number input */}
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider">
                              {idType === 'ghana-card' ? 'Ghana Card ID Number' : idType === 'nin-card' ? 'NIN ID Number' : 'Document ID Number'}
                            </label>
                            <input
                              type="text"
                              required
                              value={idNumber}
                              onChange={(e) => setIdNumber(e.target.value)}
                              placeholder={idType === 'ghana-card' ? 'GHA-721389024-9' : idType === 'nin-card' ? 'NGA-50912039-4' : 'E.g., 9014285012'}
                              className="w-full bg-white border border-gray-200 focus:border-[#3db83a] rounded-xl p-3 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-[#3db83a]"
                            />
                          </div>

                          {/* File Uploader */}
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Front Photo of National ID</label>
                            <div 
                              onClick={() => setIdFileName('ID_Front_Government_Verified.jpg')}
                              className="border-2 border-dashed border-gray-200 hover:border-[#3db83a] rounded-2xl p-6 text-center cursor-pointer transition hover:bg-gray-50/50 flex flex-col items-center gap-2"
                            >
                              <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-400">
                                <UploadCloud className="w-5 h-5 text-gray-500" />
                              </div>
                              {idFileName ? (
                                <div className="flex items-center gap-1.5 text-xs text-green-700 font-bold bg-green-50 border border-green-100 px-3 py-1 rounded-full animate-pulse">
                                  <Check className="w-3.5 h-3.5 text-green-600 shrink-0" />
                                  <span>{idFileName} uploaded successfully</span>
                                </div>
                              ) : (
                                <>
                                  <p className="text-xs font-bold text-gray-700">Click to select or drag and drop front ID image</p>
                                  <p className="text-[10px] text-gray-400 font-semibold">Supports PNG, JPG up to 10MB</p>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Control buttons */}
                        <div className="flex justify-between items-center gap-3 mt-4">
                          <button
                            type="button"
                            onClick={() => setVerificationStep('start')}
                            className="bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-black py-3 px-5 rounded-xl transition cursor-pointer"
                          >
                            Back
                          </button>
                          <button
                            type="button"
                            disabled={!idNumber || !idFileName}
                            onClick={() => setVerificationStep('selfie-upload')}
                            className={`text-xs font-black py-3 px-6 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                              idNumber && idFileName
                                ? 'bg-[#3db83a] hover:bg-[#2fa82c] text-white'
                                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            }`}
                          >
                            <span>Next: Biometric Selfie</span>
                            <ArrowRight className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Step Content: Selfie Biometrics */}
                    {verificationStep === 'selfie-upload' && (
                      <div className="flex flex-col gap-5 text-left">
                        <div className="flex flex-col gap-1">
                          <h4 className="text-sm font-black text-gray-800">Step 2: Take or Upload a Biometric 3D Selfie Scan</h4>
                          <p className="text-xs text-gray-400 font-semibold">Align your face inside the boundary circle in a well-lit environment.</p>
                        </div>

                        {/* Webcam capture area mock */}
                        <div className="flex flex-col items-center py-6 bg-gray-50 border border-gray-100 rounded-2xl relative gap-4">
                          <div className="w-48 h-48 rounded-full border-4 border-[#3db83a] bg-gray-200 relative overflow-hidden flex items-center justify-center shadow-inner">
                            {selfieFileName ? (
                              <div className="absolute inset-0 bg-[#3db83a]/10 flex flex-col items-center justify-center gap-1">
                                <User className="w-16 h-16 text-green-600 animate-pulse" />
                                <span className="bg-green-600 text-white font-black text-[9px] uppercase px-2 py-0.5 rounded-full">FACIAL GEO MATCH</span>
                              </div>
                            ) : (
                              <User className="w-24 h-24 text-gray-400" />
                            )}
                            {/* Scanning horizontal line effect */}
                            {!selfieFileName && (
                              <div className="absolute left-0 w-full h-1 bg-green-400/80 shadow-[0_0_8px_rgba(74,222,128,1)] animate-[bounce_2s_infinite]" />
                            )}
                          </div>

                          <button
                            type="button"
                            onClick={() => setSelfieFileName('Selfie_Live_Face_Scan.jpg')}
                            className="bg-gray-800 hover:bg-gray-900 text-white text-xs font-black py-2 px-4 rounded-xl transition flex items-center gap-1.5 shadow-xs cursor-pointer active:scale-95"
                          >
                            <UploadCloud className="w-4 h-4 text-green-400" />
                            <span>{selfieFileName ? 'Retake Selfie Photo' : 'Simulate Webcam Face Scan'}</span>
                          </button>
                        </div>

                        {/* Control buttons */}
                        <div className="flex justify-between items-center gap-3 mt-4">
                          <button
                            type="button"
                            onClick={() => setVerificationStep('id-upload')}
                            className="bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-black py-3 px-5 rounded-xl transition cursor-pointer"
                          >
                            Back
                          </button>
                          <button
                            type="button"
                            disabled={!selfieFileName}
                            onClick={() => setVerificationStep('phone-otp')}
                            className={`text-xs font-black py-3 px-6 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                              selfieFileName
                                ? 'bg-[#3db83a] hover:bg-[#2fa82c] text-white'
                                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            }`}
                          >
                            <span>Next: Verify Mobile OTP</span>
                            <ArrowRight className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Step Content: Mobile OTP */}
                    {verificationStep === 'phone-otp' && (
                      <div className="flex flex-col gap-5 text-left">
                        <div className="flex flex-col gap-1">
                          <h4 className="text-sm font-black text-gray-800">Step 3: Verification OTP of Registered Mobile Network</h4>
                          <p className="text-xs text-gray-400 font-semibold">We will send a secure verification token matching your merchant MoMo / phone subscription account.</p>
                        </div>

                        <div className="flex flex-col gap-4">
                          {/* Display Phone Info */}
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Registered Merchant Mobile Phone</label>
                            <input
                              type="text"
                              disabled
                              value={profile.phone}
                              className="w-full bg-gray-50 border border-gray-150 rounded-xl p-3 text-xs font-black text-gray-600 focus:outline-none"
                            />
                          </div>

                          {/* Trigger SMS OTP sending */}
                          {!otpSent ? (
                            <button
                              type="button"
                              onClick={() => {
                                setOtpSent(true);
                                setOtpError(null);
                                // Simulated SMS toast dispatch
                                alert('[SMS GATEWAY] Secure Verification Code generated for ' + profile.phone + ':\n\nYour Bozseller OTP verification code is: 5821');
                              }}
                              className="bg-gray-800 hover:bg-gray-900 text-white text-xs font-black py-3 rounded-xl transition cursor-pointer flex items-center justify-center gap-2"
                            >
                              <Smartphone className="w-4 h-4 text-[#3db83a]" />
                              <span>Dispatch Verification SMS OTP</span>
                            </button>
                          ) : (
                            <div className="flex flex-col gap-3 animate-in fade-in slide-in-from-top-2 duration-200">
                              <div className="bg-green-50 border border-green-100 rounded-xl p-4.5 flex gap-3.5 items-start">
                                <CheckCircle2 className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
                                <div>
                                  <h5 className="text-xs font-black text-green-900 leading-none">SMS OTP Sent!</h5>
                                  <p className="text-[11px] text-green-700 leading-relaxed mt-1">
                                    We sent a 4-digit code to **{profile.phone.slice(-4)}**. Please check your mock alerts or enter the simulation code **5821**.
                                  </p>
                                </div>
                              </div>

                              <div className="flex flex-col gap-1.5">
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Enter 4-Digit Security OTP</label>
                                <input
                                  type="text"
                                  maxLength={4}
                                  value={otpCode}
                                  onChange={(e) => {
                                    setOtpCode(e.target.value);
                                    if (e.target.value.length === 4) {
                                      setOtpError(null);
                                    }
                                  }}
                                  placeholder="E.g. 5821"
                                  className="w-full bg-white border border-gray-200 focus:border-[#3db83a] rounded-xl p-3 text-xs font-black tracking-widest text-center focus:outline-none focus:ring-1 focus:ring-[#3db83a]"
                                />
                                {otpError && (
                                  <span className="text-[11px] font-bold text-red-600 mt-1 flex items-center gap-1">
                                    <AlertCircle className="w-3.5 h-3.5" />
                                    {otpError}
                                  </span>
                                )}
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Control buttons */}
                        <div className="flex justify-between items-center gap-3 mt-4">
                          <button
                            type="button"
                            onClick={() => setVerificationStep('selfie-upload')}
                            className="bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-black py-3 px-5 rounded-xl transition cursor-pointer"
                          >
                            Back
                          </button>
                          <button
                            type="button"
                            disabled={!otpSent || otpCode.length !== 4}
                            onClick={() => {
                              if (otpCode !== '5821') {
                                setOtpError('Invalid verification code. Please enter 5821 or recheck SMS payload.');
                                return;
                              }
                              setVerificationStep('processing');
                            }}
                            className={`text-xs font-black py-3 px-6 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                              otpSent && otpCode.length === 4
                                ? 'bg-[#3db83a] hover:bg-[#2fa82c] text-white'
                                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            }`}
                          >
                            <span>Compile Verification Keys</span>
                            <CheckCircle className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Case 3: Processing Animation Loading Stage */}
                {verificationStep === 'processing' && (
                  <div className="flex flex-col items-center justify-center text-center py-12 gap-6 animate-in fade-in duration-200">
                    {/* Pulsing processing loader circular ring */}
                    <div className="relative w-24 h-24 flex items-center justify-center">
                      <div className="absolute inset-0 rounded-full border-4 border-gray-150" />
                      <div className="absolute inset-0 rounded-full border-4 border-[#3db83a] border-t-transparent animate-spin" />
                      <Shield className="w-10 h-10 text-gray-300 fill-gray-50 shrink-0" />
                    </div>

                    <div className="flex flex-col gap-2 max-w-sm">
                      <h4 className="text-base font-black text-gray-800 uppercase tracking-wide">Securing Registry Authenticator</h4>
                      <div className="w-full bg-gray-100 rounded-full h-1.5 mt-1 overflow-hidden">
                        <div 
                          className="bg-[#3db83a] h-1.5 rounded-full transition-all duration-300"
                          style={{ width: `${verificationProgress}%` }}
                        />
                      </div>
                      <div className="flex justify-between items-center text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mt-1.5">
                        <span>Progress</span>
                        <span>{verificationProgress}%</span>
                      </div>
                      <p className="text-xs text-[#3db83a] font-black tracking-wide leading-relaxed animate-pulse mt-2 min-h-[18px]">
                        {verificationStatusMessage}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 9. PRICE ALERTS & MATCHES TAB VIEW */}
            {activeTab === 'price-alerts' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col gap-6">
                <div>
                  <h3 className="text-base font-black text-gray-800 tracking-tight">Price Alerts & Notifications</h3>
                  <p className="text-xs text-gray-400 font-semibold mt-1">
                    Manage your favorited price drop notifications and custom target price thresholds.
                  </p>
                </div>

                {/* Section 1: Favorited Price Drop Subscriptions */}
                {priceDropSubscriptions.length > 0 && (
                  <div className="bg-amber-50/50 border border-amber-200/80 rounded-2xl p-5 flex flex-col gap-4 text-left animate-in fade-in duration-200">
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-amber-200/60">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 bg-amber-100 text-amber-800 rounded-lg">
                          <BellRing className="w-4.5 h-4.5 text-amber-700 animate-bounce" />
                        </div>
                        <div>
                          <h4 className="text-xs font-black text-gray-800">Favorited Items Price Drop Subscriptions</h4>
                          <p className="text-[10px] text-gray-500 font-bold">
                            Favorited items with active live price drop tracking badge ({priceDropSubscriptions.length})
                          </p>
                        </div>
                      </div>
                      <span className="text-[10px] bg-amber-200/80 text-amber-900 font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider">
                        ACTIVE BADGE
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                      {priceDropSubscriptions.map((sub: any) => {
                        const formattedPrice = formatConvertedPrice(sub.price, sub.country || 'Ghana', selectedCurrency);
                        return (
                          <div
                            key={sub.listingId}
                            className="bg-white border border-amber-200/60 rounded-xl p-3.5 flex gap-3 shadow-2xs hover:shadow-sm transition"
                          >
                            {sub.imageUrl && (
                              <img
                                src={sub.imageUrl}
                                alt={sub.title}
                                referrerPolicy="no-referrer"
                                className="w-16 h-16 rounded-lg object-cover border border-gray-100 shrink-0"
                              />
                            )}
                            <div className="flex flex-col justify-between flex-1 min-w-0">
                              <div>
                                <h5 className="text-xs font-bold text-gray-800 truncate">{sub.title}</h5>
                                <p className="text-xs font-black text-green-700 mt-0.5">
                                  Price: {formattedPrice}
                                </p>
                              </div>
                              <div className="flex items-center justify-between gap-2 mt-2 pt-2 border-t border-gray-50">
                                <span className="text-[9px] bg-green-50 text-green-700 font-extrabold px-1.5 py-0.5 rounded border border-green-100 flex items-center gap-1">
                                  <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                                  Notify On Price Drop
                                </span>
                                <button
                                  onClick={() => onViewDetails(sub.listingId)}
                                  className="text-[10px] bg-[#3db83a] hover:bg-[#2fa82c] text-white font-extrabold px-2.5 py-1 rounded-lg transition cursor-pointer"
                                >
                                  View Ad
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {priceAlerts.length === 0 && priceDropSubscriptions.length === 0 ? (
                  <div className="py-12 flex flex-col items-center justify-center text-center gap-3">
                    <div className="bg-gray-50 text-gray-400 p-4 rounded-full">
                      <Bell className="w-8 h-8" />
                    </div>
                    <p className="text-sm font-black text-gray-700">No active price alerts found</p>
                    <p className="text-xs text-gray-500 max-w-xs font-semibold leading-relaxed">
                      Go to any listing details view and click the <strong>Create Price Alert</strong> button to configure automatic price tracking!
                    </p>
                  </div>
                ) : (
                  <div className="flex flex-col gap-6">
                    {priceAlerts.map((alertItem: any) => {
                      const matches = getAlertMatches(alertItem);
                      return (
                        <div key={alertItem.id} className="border border-gray-100 rounded-2xl p-5 bg-gray-50/40 flex flex-col gap-4 text-left animate-in fade-in duration-200">
                          {/* Alert info banner */}
                          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-gray-100/60">
                            <div className="flex items-center gap-2.5">
                              <div className="bg-orange-50 text-orange-600 p-2 rounded-lg">
                                <Bell className="w-4 h-4" />
                              </div>
                              <div>
                                <h4 className="text-xs font-black text-gray-800">{alertItem.title}</h4>
                                <p className="text-[10px] text-gray-500 font-bold mt-0.5 uppercase tracking-wider">
                                  Category: {alertItem.categoryName || 'General'}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-3 text-right">
                              <div className="mr-2">
                                <span className="text-[10px] text-gray-400 font-bold block uppercase tracking-wider">Threshold</span>
                                <span className="text-xs font-black text-orange-700">
                                  Below {alertItem.currency} {alertItem.targetPrice.toLocaleString()}
                                </span>
                              </div>
                              <button
                                onClick={() => {
                                  if (window.confirm('Are you sure you want to delete this price alert?')) {
                                    const updated = priceAlerts.filter((a: any) => a.id !== alertItem.id);
                                    localStorage.setItem('dosboz_price_alerts', JSON.stringify(updated));
                                    setPriceAlerts(updated);
                                  }
                                }}
                                className="p-1.5 hover:bg-red-50 text-gray-400 hover:text-red-500 rounded-lg transition cursor-pointer"
                                title="Delete price alert"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>

                          {/* Matching items section */}
                          <div className="flex flex-col gap-2.5">
                            <h5 className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
                              <span>Matched Marketplace Listings</span>
                              <span className={`px-1.5 py-0.5 rounded text-[9px] font-black ${
                                matches.length > 0 ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-500'
                              }`}>
                                {matches.length} {matches.length === 1 ? 'match' : 'matches'}
                              </span>
                            </h5>

                            {matches.length === 0 ? (
                              <p className="text-xs text-gray-500 font-medium italic py-2">
                                No live matches yet. We will notify you here the instant a similar item is listed below {alertItem.currency} {alertItem.targetPrice.toLocaleString()}!
                              </p>
                            ) : (
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-1">
                                {matches.map((item: Listing) => (
                                  <div 
                                    key={item.id} 
                                    className="bg-white border border-gray-100 rounded-xl p-3 flex gap-3 hover:shadow-2xs transition-all duration-200"
                                  >
                                    <div className="w-16 h-16 rounded-lg overflow-hidden border border-gray-100 shrink-0">
                                      <img 
                                        src={item.imageUrls[0]} 
                                        alt={item.title}
                                        referrerPolicy="no-referrer"
                                        className="w-full h-full object-cover"
                                      />
                                    </div>
                                    <div className="flex flex-col justify-between flex-1 min-w-0 text-left">
                                      <div>
                                        <h6 className="text-xs font-bold text-gray-800 truncate leading-snug">{item.title}</h6>
                                        <p className="text-xs text-green-700 font-black mt-0.5">
                                          {alertItem.currency} {item.price.toLocaleString()}
                                        </p>
                                      </div>
                                      <div className="flex items-center justify-between gap-1.5 mt-1.5">
                                        <span className="text-[9px] bg-gray-50 text-gray-500 font-bold px-1.5 py-0.5 rounded border border-gray-100 truncate">
                                          📍 {item.neighborhood || item.region}
                                        </span>
                                        <button
                                          onClick={() => onViewDetails(item.id)}
                                          className="text-[10px] bg-[#3db83a]/10 hover:bg-[#3db83a]/20 text-[#3db83a] font-extrabold px-2.5 py-1 rounded-lg transition cursor-pointer shrink-0"
                                        >
                                          View Ad
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

          </div>

        </div>

      </div>

      {/* ================= RECHARGE PAYMENT MODAL ================= */}
      {showRechargeModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col">
            
            {/* Header */}
            <div className="bg-[#faf9f6] p-5 border-b border-gray-100 flex justify-between items-center relative">
              <h3 className="text-sm font-black text-gray-800 uppercase tracking-wider flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-[#3db83a]" />
                <span>Recharge Balance Wallet</span>
              </h3>
              <button 
                onClick={() => setShowRechargeModal(false)}
                className="p-1.5 bg-white text-gray-400 hover:text-gray-700 rounded-full border border-gray-100 cursor-pointer shadow-3xs"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handlePerformRecharge} className="p-6 flex flex-col gap-5">
              
              {/* Payment methods selector */}
              <div className="grid grid-cols-2 gap-3.5">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('momo')}
                  className={`py-3.5 rounded-xl text-xs font-black transition cursor-pointer border flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'momo' 
                      ? 'border-[#3db83a] bg-[#3db83a]/5 text-[#3db83a]' 
                      : 'border-gray-200 text-gray-500 hover:bg-gray-50'
                  }`}
                >
                  <Smartphone className="w-4 h-4" />
                  <span>Mobile Money</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`py-3.5 rounded-xl text-xs font-black transition cursor-pointer border flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'card' 
                      ? 'border-[#3db83a] bg-[#3db83a]/5 text-[#3db83a]' 
                      : 'border-gray-200 text-gray-500 hover:bg-gray-50'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Credit Card</span>
                </button>
              </div>

              {/* Amount input */}
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Amount to Recharge (GH₵)</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-xs font-black text-gray-400">GH₵</span>
                  <input
                    type="number"
                    min="5"
                    max="1000"
                    required
                    value={rechargeAmount}
                    onChange={(e) => setRechargeAmount(e.target.value)}
                    className="w-full bg-white border border-gray-200 focus:border-[#3db83a] rounded-xl pl-12 pr-4 py-2.5 text-sm font-black focus:outline-none"
                    placeholder="Enter amount. E.g. 50"
                  />
                </div>
              </div>

              {/* Mobile Money inputs */}
              {paymentMethod === 'momo' && (
                <div className="flex flex-col gap-3.5 bg-[#fcfbf9] border border-gray-100 p-4 rounded-xl">
                  {/* MoMo Network */}
                  <div className="flex flex-col gap-1">
                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-wider">Select Mobile Network</span>
                    <div className="grid grid-cols-3 gap-2 mt-1">
                      {['mtn', 'telecel', 'at'].map((network) => (
                        <button
                          key={network}
                          type="button"
                          onClick={() => setMomoNetwork(network as any)}
                          className={`py-1.5 rounded-lg text-[10px] font-black uppercase border transition cursor-pointer ${
                            momoNetwork === network
                              ? 'border-yellow-400 bg-yellow-50 text-yellow-900'
                              : 'border-gray-200 bg-white text-gray-500 hover:bg-gray-50'
                          }`}
                        >
                          {network === 'mtn' ? 'MTN MoMo' : network === 'telecel' ? 'Telecel' : 'AT Money'}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* MoMo Number */}
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-wider">Momo Phone Number</label>
                    <input
                      type="text"
                      required
                      value={momoNumber}
                      onChange={(e) => setMomoNumber(e.target.value)}
                      className="w-full bg-white border border-gray-200 focus:border-[#3db83a] rounded-lg px-3 py-1.5 text-xs font-semibold focus:outline-none"
                      placeholder="e.g. 0242866658"
                    />
                  </div>
                </div>
              )}

              {/* Credit Card inputs */}
              {paymentMethod === 'card' && (
                <div className="flex flex-col gap-3.5 bg-[#fcfbf9] border border-gray-100 p-4 rounded-xl">
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-wider">Card Number</label>
                    <input
                      type="text"
                      required
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full bg-white border border-gray-200 focus:border-[#3db83a] rounded-lg px-3 py-1.5 text-xs font-semibold focus:outline-none"
                      placeholder="4000 1234 5678 9010"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex flex-col gap-1">
                      <label className="text-[9px] font-black text-gray-400 uppercase tracking-wider">Expiry Date</label>
                      <input
                        type="text"
                        required
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        className="w-full bg-white border border-gray-200 focus:border-[#3db83a] rounded-lg px-3 py-1.5 text-xs font-semibold focus:outline-none"
                        placeholder="MM / YY"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="text-[9px] font-black text-gray-400 uppercase tracking-wider">CVV</label>
                      <input
                        type="password"
                        required
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                        className="w-full bg-white border border-gray-200 focus:border-[#3db83a] rounded-lg px-3 py-1.5 text-xs font-semibold focus:outline-none"
                        placeholder="123"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Submit button */}
              <button
                type="submit"
                disabled={isProcessingPayment || paymentSuccess}
                className="w-full bg-[#3db83a] hover:bg-[#2fa82c] disabled:bg-gray-300 text-white font-black text-xs py-3 rounded-xl transition cursor-pointer select-none flex items-center justify-center gap-1.5 mt-2"
              >
                {isProcessingPayment ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>Processing Secure Gateway...</span>
                  </>
                ) : paymentSuccess ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-white animate-bounce" />
                    <span>Recharge Successful!</span>
                  </>
                ) : (
                  <>
                    <ArrowUpRight className="w-4 h-4" />
                    <span>Recharge GH₵ {rechargeAmount} Now</span>
                  </>
                )}
              </button>

            </form>

            {/* Footer lock note */}
            <div className="p-4 bg-gray-50 border-t border-gray-100 flex items-center justify-center gap-1.5 text-[9px] text-gray-400 font-extrabold uppercase tracking-widest text-center">
              <ShieldCheck className="w-4 h-4 text-green-600" />
              <span>DSSL SECURE 256-BIT ENCRYPTED GATEWAY</span>
            </div>

          </div>
        </div>
      )}

      {/* ================= SETTINGS / EDIT PROFILE MODAL ================= */}
      {showSettingsModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col">
            {/* Header */}
            <div className="bg-[#faf9f6] p-5 border-b border-gray-100 flex justify-between items-center">
              <h3 className="text-sm font-black text-gray-800 uppercase tracking-wider flex items-center gap-2">
                <Settings className="w-4 h-4 text-[#3db83a]" />
                <span>Edit Profile & Account Settings</span>
              </h3>
              <button 
                onClick={() => setShowSettingsModal(false)}
                className="p-1.5 bg-white text-gray-400 hover:text-gray-700 rounded-full border border-gray-100 cursor-pointer shadow-3xs"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={(e) => {
              e.preventDefault();
              localStorage.setItem('dosboz_user_profile', JSON.stringify(profile));
              // Update prefilled momo details
              setMomoNumber(profile.momoNumber);
              setMomoNetwork(profile.momoNetwork as any);
              alert('Profile settings and linked wallet updated successfully!');
              setShowSettingsModal(false);
            }} className="p-6 flex flex-col gap-4 text-left">
              
              {/* Name */}
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Full Name</label>
                <input
                  type="text"
                  required
                  value={profile.name}
                  onChange={(e) => setProfile({...profile, name: e.target.value})}
                  className="w-full bg-white border border-gray-200 focus:border-[#3db83a] rounded-xl px-4 py-2.5 text-xs font-bold focus:outline-none"
                  placeholder="Enter full name"
                />
              </div>

              {/* Phone */}
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Phone Number</label>
                <input
                  type="text"
                  required
                  value={profile.phone}
                  onChange={(e) => setProfile({...profile, phone: e.target.value})}
                  className="w-full bg-white border border-gray-200 focus:border-[#3db83a] rounded-xl px-4 py-2.5 text-xs font-bold focus:outline-none"
                  placeholder="Enter phone number"
                />
              </div>

              {/* Linked Mobile Money Settings Header */}
              <div className="mt-2 pt-4 border-t border-gray-100">
                <h4 className="text-xs font-black text-gray-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-amber-500" />
                  <span>Linked Mobile Money (MoMo)</span>
                </h4>
              </div>

              {/* MoMo Network */}
              <div className="flex flex-col gap-1.5">
                <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Mobile Money Network</span>
                <div className="grid grid-cols-3 gap-2">
                  {['mtn', 'telecel', 'at'].map((network) => (
                    <button
                      key={network}
                      type="button"
                      onClick={() => setProfile({...profile, momoNetwork: network})}
                      className={`py-2 rounded-lg text-[10px] font-black uppercase border transition cursor-pointer ${
                        profile.momoNetwork === network
                          ? 'border-yellow-400 bg-yellow-50 text-yellow-900'
                          : 'border-gray-200 bg-white text-gray-500 hover:bg-gray-50'
                      }`}
                    >
                      {network === 'mtn' ? 'MTN MoMo' : network === 'telecel' ? 'Telecel' : 'AT Money'}
                    </button>
                  ))}
                </div>
              </div>

              {/* MoMo Number */}
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider">MoMo Wallet Number</label>
                <input
                  type="text"
                  required
                  value={profile.momoNumber}
                  onChange={(e) => setProfile({...profile, momoNumber: e.target.value})}
                  className="w-full bg-white border border-gray-200 focus:border-[#3db83a] rounded-xl px-4 py-2.5 text-xs font-bold focus:outline-none"
                  placeholder="Enter MoMo number"
                />
              </div>

              {/* Submit / Save */}
              <div className="flex gap-2.5 mt-3">
                <button
                  type="button"
                  onClick={() => setShowSettingsModal(false)}
                  className="flex-1 border border-gray-200 hover:border-gray-300 bg-white text-gray-700 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer text-center"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-[#3db83a] hover:bg-[#2fa82c] text-white py-2.5 rounded-xl text-xs font-black transition cursor-pointer text-center"
                >
                  Save Settings
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
