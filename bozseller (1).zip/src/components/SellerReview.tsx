import React, { useState, useEffect } from 'react';
import { Star, CheckCircle2, ShieldCheck, X, ThumbsUp, MessageSquare, Send, Loader2, Award, TrendingUp } from 'lucide-react';
import { SellerReview as SellerReviewType, CurrencyCode } from '../types';
import { formatConvertedPrice } from '../utils/currency';
import { supabase } from '../lib/supabaseClient';

interface SellerReviewProps {
  sellerId: string;
  sellerName: string;
  country?: string;
  onClose?: () => void;
  selectedCurrency?: CurrencyCode;
}

export const SellerReview: React.FC<SellerReviewProps> = ({
  sellerId,
  sellerName,
  country = 'Ghana',
  onClose,
  selectedCurrency = 'GHS',
}) => {
  const [reviews, setReviews] = useState<SellerReviewType[]>([]);
  const [loading, setLoading] = useState(true);
  const [ratingStats, setRatingStats] = useState({
    avgRating: 4.9,
    reputationScore: 98.8,
    totalCount: 0,
  });

  // New Review Form state
  const [newRating, setNewRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [reviewText, setReviewText] = useState('');
  const [buyerName, setBuyerName] = useState('Kwame Mensah');
  const [submitting, setSubmitting] = useState(false);
  const [submitNotice, setSubmitNotice] = useState<string | null>(null);

  // Fetch reviews from Supabase and fallback Express API
  const fetchReviews = async () => {
    setLoading(true);
    let loadedReviews: SellerReviewType[] = [];

    // 1. Try Supabase
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .eq('seller_id', sellerId)
        .order('created_at', { ascending: false });

      if (!error && data && data.length > 0) {
        loadedReviews = data.map((r: any) => ({
          id: r.id || `rev-${Date.now()}`,
          sellerId: r.seller_id || r.sellerId,
          sellerName: r.seller_name || r.sellerName || sellerName,
          buyerId: r.buyer_id || r.buyerId || 'usr-buyer',
          buyerName: r.buyer_name || r.buyerName || 'Verified Buyer',
          listingId: r.listing_id || r.listingId || 'list-1',
          listingTitle: r.listing_title || r.listingTitle || 'Verified Item',
          rating: Number(r.rating) || 5,
          reviewText: r.comment || r.review_text || r.reviewText || '',
          transactionCompleted: true,
          createdAt: r.created_at || r.createdAt || new Date().toISOString(),
        }));
      }
    } catch (sbErr) {
      console.warn('Supabase reviews fetch error:', sbErr);
    }

    // 2. Fallback to Express backend API if empty
    if (loadedReviews.length === 0) {
      try {
        const res = await fetch(`/api/sellers/${sellerId}/reviews`);
        if (res.ok) {
          const apiData = await res.json();
          if (apiData.reviews && Array.isArray(apiData.reviews)) {
            loadedReviews = apiData.reviews;
          }
        }
      } catch (apiErr) {
        console.warn('Express API reviews fetch error:', apiErr);
      }
    }

    // Default mock fallback seed if still empty for demo seller
    if (loadedReviews.length === 0) {
      loadedReviews = [
        {
          id: 'rev-seed-1',
          sellerId,
          sellerName,
          buyerId: 'usr-buyer-1',
          buyerName: 'Justice Osei',
          listingId: 'list-1',
          listingTitle: 'Registered Vehicle / Tech Item',
          rating: 5,
          reviewText: 'Extremely fast dispatch and genuine registered product! Paperwork transferred smoothly at East Legon. Escrow protection made payment stress-free.',
          transactionCompleted: true,
          createdAt: new Date(Date.now() - 3600000 * 36).toISOString(),
        },
        {
          id: 'rev-seed-2',
          sellerId,
          sellerName,
          buyerId: 'usr-buyer-2',
          buyerName: 'Ama Serwaa',
          listingId: 'list-2',
          listingTitle: 'Premium Mobile Smartphone',
          rating: 5,
          reviewText: 'Brand new in original box. Verified serial number on manufacturer warranty portal. Excellent communication and safe public meetup.',
          transactionCompleted: true,
          createdAt: new Date(Date.now() - 3600000 * 96).toISOString(),
        },
        {
          id: 'rev-seed-3',
          sellerId,
          sellerName,
          buyerId: 'usr-buyer-3',
          buyerName: 'Emmanuel Boateng',
          listingId: 'list-3',
          listingTitle: 'High-Spec Laptop',
          rating: 4,
          reviewText: 'Good transaction. Item matches description exactly and battery health is 100%. Highly recommended seller.',
          transactionCompleted: true,
          createdAt: new Date(Date.now() - 3600000 * 200).toISOString(),
        },
      ];
    }

    setReviews(loadedReviews);

    // Compute rating metrics
    if (loadedReviews.length > 0) {
      const sum = loadedReviews.reduce((acc, r) => acc + r.rating, 0);
      const avg = parseFloat((sum / loadedReviews.length).toFixed(1));
      const positiveCount = loadedReviews.filter((r) => r.rating >= 4).length;
      const repScore = parseFloat(((positiveCount / loadedReviews.length) * 100).toFixed(1));
      setRatingStats({
        avgRating: avg,
        reputationScore: repScore,
        totalCount: loadedReviews.length,
      });
    }

    setLoading(false);
  };

  useEffect(() => {
    fetchReviews();
  }, [sellerId]);

  // Submit review
  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewText.trim()) return;

    setSubmitting(true);
    setSubmitNotice(null);

    const newRev: SellerReviewType = {
      id: `rev-${Date.now()}`,
      sellerId,
      sellerName,
      buyerId: `usr-buyer-${Math.floor(Math.random() * 1000)}`,
      buyerName: buyerName.trim() || 'Verified Buyer',
      listingId: 'list-current',
      listingTitle: 'Verified Purchase',
      rating: newRating,
      reviewText: reviewText.trim(),
      transactionCompleted: true,
      createdAt: new Date().toISOString(),
    };

    // 1. Insert into Supabase 'reviews' table
    try {
      await supabase.from('reviews').insert([
        {
          id: newRev.id,
          seller_id: sellerId,
          seller_name: sellerName,
          buyer_id: newRev.buyerId,
          buyer_name: newRev.buyerName,
          rating: newRev.rating,
          comment: newRev.reviewText,
          created_at: newRev.createdAt,
        },
      ]);
    } catch (sbErr) {
      console.warn('Supabase review insert warning:', sbErr);
    }

    // 2. Post to Express backend
    try {
      await fetch(`/api/sellers/${sellerId}/reviews`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rating: newRev.rating,
          reviewText: newRev.reviewText,
          buyerName: newRev.buyerName,
          buyerId: newRev.buyerId,
        }),
      });
    } catch (apiErr) {
        console.warn('Express API review submit warning:', apiErr);
    }

    setReviews((prev) => [newRev, ...prev]);
    setReviewText('');
    setSubmitNotice('Thank you! Your seller review and rating have been posted to the database.');
    setSubmitting(false);

    // Recalculate
    const updated = [newRev, ...reviews];
    const sum = updated.reduce((acc, r) => acc + r.rating, 0);
    const avg = parseFloat((sum / updated.length).toFixed(1));
    const pos = updated.filter((r) => r.rating >= 4).length;
    const rep = parseFloat(((pos / updated.length) * 100).toFixed(1));
    setRatingStats({
      avgRating: avg,
      reputationScore: rep,
      totalCount: updated.length,
    });
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200/80 shadow-2xl max-w-2xl w-full p-6 space-y-6 relative animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-800 font-extrabold text-lg flex items-center justify-center">
            <Award className="w-6 h-6 text-amber-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-extrabold text-gray-900">{sellerName}</h2>
              <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-600" /> Verified Merchant
              </span>
            </div>
            <p className="text-xs text-gray-500 mt-0.5">
              Customer Feedback & Verified Escrow Reputation Ratings ({country})
            </p>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Seller Summary Score Banner */}
      <div className="grid grid-cols-3 gap-3 bg-slate-900 text-white p-4 rounded-xl border border-slate-800">
        <div className="text-center space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Overall Rating
          </span>
          <div className="flex items-center justify-center gap-1 font-black text-xl text-amber-400 font-mono">
            <Star className="w-5 h-5 fill-amber-400" />
            <span>{ratingStats.avgRating} / 5.0</span>
          </div>
        </div>

        <div className="text-center space-y-1 border-x border-slate-800">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Positive Feedback
          </span>
          <div className="font-black text-xl text-emerald-400 font-mono">
            {ratingStats.reputationScore}%
          </div>
        </div>

        <div className="text-center space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Total Reviews
          </span>
          <div className="font-black text-xl text-slate-100 font-mono">
            {ratingStats.totalCount} Orders
          </div>
        </div>
      </div>

      {/* Write a Review Section */}
      <form onSubmit={handleSubmitReview} className="bg-amber-500/5 border border-amber-200/80 p-4 rounded-xl space-y-3">
        <h3 className="text-xs font-extrabold text-amber-900 flex items-center gap-1.5">
          <MessageSquare className="w-4 h-4 text-amber-600" />
          <span>Leave a Verified Seller Review</span>
        </h3>

        <div className="flex items-center gap-3">
          <span className="text-xs text-gray-600 font-medium">Your Rating:</span>
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                type="button"
                key={star}
                onMouseEnter={() => setHoverRating(star)}
                onMouseLeave={() => setHoverRating(0)}
                onClick={() => setNewRating(star)}
                className="p-1 cursor-pointer transition transform hover:scale-110"
              >
                <Star
                  className={`w-5 h-5 ${
                    star <= (hoverRating || newRating)
                      ? 'text-amber-400 fill-amber-400'
                      : 'text-gray-300'
                  }`}
                />
              </button>
            ))}
          </div>
          <span className="text-xs font-bold text-amber-800 font-mono">
            {newRating} / 5 Stars
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <input
            type="text"
            required
            placeholder="Your Name (e.g. Kwame Mensah)"
            value={buyerName}
            onChange={(e) => setBuyerName(e.target.value)}
            className="bg-white border border-gray-200 rounded-lg p-2 text-xs text-gray-800 font-medium focus:outline-none focus:ring-1 focus:ring-amber-500"
          />
          <button
            type="submit"
            disabled={submitting || !reviewText.trim()}
            className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs py-2 px-4 rounded-lg transition flex items-center justify-center gap-1.5 shadow-xs disabled:opacity-50"
          >
            {submitting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
            <span>Post Rating & Review</span>
          </button>
        </div>

        <textarea
          rows={2}
          required
          placeholder="Share your experience with this vendor (communication, delivery speed, product condition)..."
          value={reviewText}
          onChange={(e) => setReviewText(e.target.value)}
          className="w-full bg-white border border-gray-200 rounded-lg p-2.5 text-xs text-gray-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
        />

        {submitNotice && (
          <div className="p-2 bg-emerald-50 border border-emerald-200 rounded text-[11px] text-emerald-800 font-medium flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{submitNotice}</span>
          </div>
        )}
      </form>

      {/* Reviews List */}
      <div className="space-y-3 max-h-[320px] overflow-y-auto pr-1">
        <h3 className="text-xs font-extrabold text-gray-800 uppercase tracking-wider">
          Verified Buyer Reviews ({reviews.length})
        </h3>

        {loading ? (
          <div className="text-center py-8 text-gray-400 flex flex-col items-center gap-2">
            <Loader2 className="w-6 h-6 animate-spin text-amber-600" />
            <span className="text-xs font-medium">Fetching seller reviews from Supabase...</span>
          </div>
        ) : reviews.length === 0 ? (
          <div className="text-center py-8 text-gray-400 bg-gray-50 rounded-xl border border-gray-100">
            <Star className="w-8 h-8 text-gray-300 mx-auto mb-1" />
            <p className="text-xs font-semibold">No reviews posted yet for this seller.</p>
          </div>
        ) : (
          reviews.map((r) => (
            <div
              key={r.id}
              className="p-3.5 bg-gray-50/70 border border-gray-200/60 rounded-xl space-y-1.5 text-xs"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-gray-900">{r.buyerName}</span>
                  <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[9px] font-bold px-1.5 py-0.2 rounded flex items-center gap-0.5">
                    <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" /> Escrow Verified
                  </span>
                </div>
                <div className="flex items-center gap-0.5 text-amber-500 font-mono font-bold">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3 h-3 ${
                        i < r.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'
                      }`}
                    />
                  ))}
                  <span className="ml-1 text-[11px] text-gray-700">{r.rating}.0</span>
                </div>
              </div>

              <p className="text-gray-700 text-xs leading-relaxed italic">
                "{r.reviewText}"
              </p>

              <div className="flex items-center justify-between text-[10px] text-gray-400 font-medium pt-1 border-t border-gray-100">
                <span>Item: {r.listingTitle || 'Verified Purchase'}</span>
                <span>{new Date(r.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
