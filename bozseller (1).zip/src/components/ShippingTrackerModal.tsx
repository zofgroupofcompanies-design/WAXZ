import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Truck, Package, CheckCircle2, MapPin, Barcode, ShieldCheck, 
  ExternalLink, ArrowRight, Clock, AlertCircle
} from 'lucide-react';
import { Order } from '../types';

interface ShippingTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  onConfirmDelivery?: (orderId: string) => void;
  onDisputeOrder?: (orderId: string) => void;
}

export default function ShippingTrackerModal({
  isOpen,
  onClose,
  order,
  onConfirmDelivery,
  onDisputeOrder
}: ShippingTrackerModalProps) {
  if (!isOpen || !order) return null;

  const isDelivered = order.status === 'delivered' || order.status === 'completed';
  const isEscrowReleased = order.status === 'completed';

  const steps = [
    { label: 'Order Placed & Escrow Locked', completed: true, date: new Date(order.createdAt).toLocaleDateString() },
    { label: 'Carrier Pickup & Shipping Label Created', completed: true, date: 'In transit' },
    { label: 'Package In-Transit via Courier', completed: order.status !== 'escrow_held', date: order.courier },
    { label: 'Delivered & Inspected', completed: isDelivered, date: isDelivered ? 'Delivered' : 'Pending' }
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[999] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="bg-white rounded-2xl max-w-xl w-full shadow-2xl overflow-hidden border border-gray-100 flex flex-col my-auto max-h-[90vh]"
        >
          {/* Header */}
          <div className="bg-[#291f17] text-white p-5 flex items-center justify-between border-b border-amber-900/40 shrink-0">
            <div className="flex items-center gap-3">
              <div className="bg-amber-500 text-green-950 p-2 rounded-xl">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black tracking-tight flex items-center gap-2">
                  <span>Logistics & Courier Tracking</span>
                  <span className="text-[10px] bg-amber-400 text-green-950 font-black px-2 py-0.5 rounded-full uppercase">
                    {order.courier}
                  </span>
                </h3>
                <p className="text-[11px] text-amber-200/80 font-medium">
                  Order #{order.id} • Seller: {order.sellerName}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="text-white/80 hover:text-white p-1.5 hover:bg-white/10 rounded-full transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="p-6 overflow-y-auto space-y-6 flex-1">
            {/* Shipping Label Card */}
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-dashed border-amber-300 rounded-2xl p-5 space-y-3 font-mono">
              <div className="flex justify-between items-center border-b border-amber-200/80 pb-2.5">
                <span className="text-xs font-black text-amber-900 uppercase">OFFICIAL COURIER MANIFEST</span>
                <span className="text-[10px] bg-amber-900 text-amber-100 font-extrabold px-2 py-0.5 rounded uppercase">
                  {order.courier}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs text-amber-950">
                <div>
                  <span className="text-[9px] text-amber-800 font-bold uppercase block">Tracking Code</span>
                  <strong className="text-sm font-black text-amber-900">{order.courierTrackingCode}</strong>
                </div>
                <div>
                  <span className="text-[9px] text-amber-800 font-bold uppercase block">Recipient Address</span>
                  <strong className="text-xs truncate block">{order.shippingAddress}</strong>
                </div>
              </div>

              {/* Simulated Barcode */}
              <div className="pt-2 flex flex-col items-center justify-center bg-white/80 p-3 rounded-xl border border-amber-200">
                <Barcode className="w-full h-12 text-gray-800" />
                <span className="text-[10px] font-bold text-gray-500 tracking-widest mt-1">
                  *{order.courierTrackingCode}*
                </span>
              </div>
            </div>

            {/* Timeline Progress */}
            <div className="space-y-3">
              <h4 className="text-xs font-black text-gray-800 uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-700" />
                <span>Delivery Status Timeline</span>
              </h4>

              <div className="space-y-4 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-gray-200">
                {steps.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-4 relative z-10">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 border-2 ${
                      step.completed ? 'bg-amber-600 border-amber-500 text-white' : 'bg-white border-gray-300 text-gray-400'
                    }`}>
                      {step.completed ? <CheckCircle2 className="w-4 h-4" /> : <span className="text-[10px] font-bold">{idx + 1}</span>}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h5 className={`text-xs font-bold ${step.completed ? 'text-gray-900' : 'text-gray-400'}`}>
                        {step.label}
                      </h5>
                      <span className="text-[10px] text-gray-500 font-semibold">{step.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Escrow Release Controls */}
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl space-y-3">
              <div className="flex items-center gap-2 text-amber-900">
                <ShieldCheck className="w-5 h-5 text-amber-700 shrink-0" />
                <div>
                  <h5 className="text-xs font-black">Escrow Guarantee Status: {order.status.toUpperCase()}</h5>
                  <p className="text-[10px] text-amber-800 font-medium">
                    Funds ({order.currency} {order.totalAmount.toLocaleString()}) are securely locked until you confirm item receipt.
                  </p>
                </div>
              </div>

              {!isEscrowReleased ? (
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => {
                      if (onConfirmDelivery) onConfirmDelivery(order.id);
                    }}
                    className="flex-1 py-2.5 bg-green-600 hover:bg-green-700 text-white font-black text-xs uppercase tracking-wider rounded-xl transition shadow-xs cursor-pointer"
                  >
                    Confirm Delivery & Release Escrow
                  </button>
                  <button
                    onClick={() => {
                      if (onDisputeOrder) onDisputeOrder(order.id);
                    }}
                    className="px-4 py-2.5 bg-red-100 hover:bg-red-200 text-red-700 font-black text-xs rounded-xl transition cursor-pointer"
                  >
                    Dispute Order
                  </button>
                </div>
              ) : (
                <div className="bg-green-100 text-green-800 p-2.5 rounded-xl text-xs font-black text-center">
                  ✅ Escrow Released & Funds Dispatched to Seller
                </div>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
