import React, { useEffect, useRef, useState } from 'react';
import { Loader2, MapPin } from 'lucide-react';

interface MapComponentProps {
  country: string;
  region: string;
  neighborhood: string;
  gpsCoordinates?: { latitude: number; longitude: number };
  gpsAddress?: string;
}

export default function MapComponent({
  country,
  region,
  neighborhood,
  gpsCoordinates,
  gpsAddress
}: MapComponentProps) {
  const [leafletLoaded, setLeafletLoaded] = useState(false);
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMapInstance = useRef<any>(null);

  useEffect(() => {
    // Check if Leaflet is already loaded on window
    if ((window as any).L) {
      setLeafletLoaded(true);
      return;
    }

    // Load stylesheet
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
    link.integrity = 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=';
    link.crossOrigin = '';
    document.head.appendChild(link);

    // Load script
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    script.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
    script.crossOrigin = '';
    script.onload = () => {
      setLeafletLoaded(true);
    };
    document.head.appendChild(script);
  }, []);

  const getCoordinates = () => {
    if (gpsCoordinates && gpsCoordinates.latitude && gpsCoordinates.longitude) {
      return { lat: gpsCoordinates.latitude, lng: gpsCoordinates.longitude, isExact: true };
    }

    // Neighborhood mapping
    const neighborhoodCoords: Record<string, { lat: number; lng: number }> = {
      'East Legon': { lat: 5.6322, lng: -0.1554 },
      'Cantonments': { lat: 5.5786, lng: -0.1818 },
      'Circle': { lat: 5.5615, lng: -0.2104 },
      'Lekki': { lat: 6.4281, lng: 3.4219 },
      'Ikeja': { lat: 6.6018, lng: 3.3515 },
      'Wuse': { lat: 9.0620, lng: 7.4589 },
      'Nyékonakpoé': { lat: 6.1340, lng: 1.2052 },
      'Hedzranawoé': { lat: 6.1663, lng: 1.2389 },
    };

    const cleanNeighborhood = neighborhood ? neighborhood.trim() : '';
    if (neighborhoodCoords[cleanNeighborhood]) {
      return { ...neighborhoodCoords[cleanNeighborhood], isExact: false };
    }

    // Region mapping
    const regionCoords: Record<string, { lat: number; lng: number }> = {
      'Greater Accra': { lat: 5.6037, lng: -0.1870 },
      'Ashanti': { lat: 6.6885, lng: -1.6244 },
      'Northern': { lat: 9.4008, lng: -0.8393 },
      'Western': { lat: 4.9016, lng: -1.7831 },
      'Volta': { lat: 6.0319, lng: 0.4474 },
      'Eastern': { lat: 6.0945, lng: -0.2609 },
      'Central': { lat: 5.1315, lng: -1.2795 },
      'Lagos': { lat: 6.5244, lng: 3.3792 },
      'Abuja FCT': { lat: 9.0765, lng: 7.3986 },
      'Kano': { lat: 12.0022, lng: 8.5920 },
      'Rivers': { lat: 4.8156, lng: 7.0498 },
      'Maritime (Lomé)': { lat: 6.1375, lng: 1.2123 },
      'Plateaux': { lat: 7.5000, lng: 1.0000 },
    };

    const cleanRegion = region ? region.trim() : '';
    if (regionCoords[cleanRegion]) {
      return { ...regionCoords[cleanRegion], isExact: false };
    }

    // Country defaults
    const countryCoords: Record<string, { lat: number; lng: number }> = {
      'Ghana': { lat: 7.9465, lng: -1.0232 },
      'Nigeria': { lat: 9.0820, lng: 8.6753 },
      'Togo': { lat: 8.6195, lng: 0.8248 },
    };

    const cleanCountry = country ? country.trim() : '';
    if (countryCoords[cleanCountry]) {
      return { ...countryCoords[cleanCountry], isExact: false };
    }

    return { lat: 5.6037, lng: -0.1870, isExact: false };
  };

  useEffect(() => {
    if (!leafletLoaded || !mapRef.current) return;

    // Destroy previous map instance
    if (leafletMapInstance.current) {
      leafletMapInstance.current.remove();
      leafletMapInstance.current = null;
    }

    const { lat, lng, isExact } = getCoordinates();
    const L = (window as any).L;

    if (!L) return;

    // Create Leaflet map
    const map = L.map(mapRef.current, {
      center: [lat, lng],
      zoom: isExact ? 14 : 12,
      zoomControl: true,
      scrollWheelZoom: false,
    });

    leafletMapInstance.current = map;

    // Use a clean, stylish modern tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    // Add marker or circular range
    if (isExact) {
      const customPinIcon = L.divIcon({
        html: `
          <div class="relative flex items-center justify-center">
            <div class="absolute w-8 h-8 bg-[#3db83a]/30 rounded-full animate-ping"></div>
            <div class="relative w-5 h-5 bg-[#3db83a] border-2 border-white rounded-full flex items-center justify-center shadow-md">
              <div class="w-2.5 h-2.5 bg-white rounded-full"></div>
            </div>
          </div>
        `,
        className: 'custom-pin-icon',
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      });

      const marker = L.marker([lat, lng], { icon: customPinIcon }).addTo(map);
      const popupContent = `
        <div style="font-family: system-ui, sans-serif; font-size: 11px; font-weight: bold; padding: 4px; text-align: center;">
          <span style="color: #3db83a; text-transform: uppercase; letter-spacing: 0.5px;">📍 Verified Location</span><br/>
          <span style="color: #1f2937; font-weight: 800; font-size: 12px; display: block; margin-top: 4px;">${gpsAddress || 'Exact Address'}</span>
        </div>
      `;
      marker.bindPopup(popupContent).openPopup();
    } else {
      // Draw approximate shaded circle region
      L.circle([lat, lng], {
        color: '#3db83a',
        fillColor: '#3db83a',
        fillOpacity: 0.15,
        radius: 1200, // 1.2km radius
        weight: 1.5
      }).addTo(map);

      const popupContent = `
        <div style="font-family: system-ui, sans-serif; font-size: 11px; font-weight: bold; padding: 4px; text-align: center;">
          <span style="color: #7a5e45; text-transform: uppercase; letter-spacing: 0.5px;">📍 Approximate Location</span><br/>
          <span style="color: #1f2937; font-weight: 800; font-size: 12px; display: block; margin-top: 4px;">${neighborhood || region || country}</span>
          <div style="font-size: 9px; color: #6b7280; font-weight: 500; margin-top: 6px; line-height: 1.3;">Exact meetup location can be requested during private chat.</div>
        </div>
      `;
      
      const popup = L.popup({ closeButton: false })
        .setLatLng([lat, lng])
        .setContent(popupContent)
        .openOn(map);
    }

    // Invalidate size in next frame to fix layout rendering inside container
    setTimeout(() => {
      map.invalidateSize();
    }, 150);

    return () => {
      if (leafletMapInstance.current) {
        leafletMapInstance.current.remove();
        leafletMapInstance.current = null;
      }
    };
  }, [leafletLoaded, country, region, neighborhood, gpsCoordinates, gpsAddress]);

  return (
    <div className="w-full bg-gray-50 border border-gray-200 rounded-2xl overflow-hidden flex flex-col h-64 relative shadow-3xs group">
      {!leafletLoaded && (
        <div className="absolute inset-0 bg-gray-50/80 backdrop-blur-xs flex flex-col items-center justify-center gap-2 z-10">
          <Loader2 className="w-6 h-6 text-[#3db83a] animate-spin" />
          <span className="text-[10px] text-gray-500 font-extrabold uppercase tracking-wider">Loading Live Street Map...</span>
        </div>
      )}
      
      {/* Map container */}
      <div ref={mapRef} className="w-full h-full z-0" />
      
      {/* Map overlay badge */}
      <div className="absolute bottom-3 left-3 bg-white/95 backdrop-blur-xs px-3 py-1.5 rounded-xl shadow-xs border border-gray-100 flex items-center gap-1.5 z-10 transition group-hover:scale-105 pointer-events-none">
        <MapPin className="w-3.5 h-3.5 text-[#3db83a]" />
        <span className="text-[10px] text-gray-800 font-black uppercase tracking-wider">
          {neighborhood ? `${neighborhood}, ${region}` : region}
        </span>
      </div>
    </div>
  );
}
