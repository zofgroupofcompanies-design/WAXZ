import { useState, useEffect } from 'react';
import * as Icons from 'lucide-react';
import { Category } from '../types';

interface CategoriesListProps {
  activeCategoryId: string | null;
  onSelectCategory: (id: string | null) => void;
}

export default function CategoriesList({
  activeCategoryId,
  onSelectCategory
}: CategoriesListProps) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch dynamic categories from Express server to keep counts synchronized
  useEffect(() => {
    fetch('/api/categories')
      .then(res => res.json())
      .then(data => {
        setCategories(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load categories from API:', err);
        setLoading(false);
      });
  }, [activeCategoryId]); // Reload when category changes to fetch fresh count stats

  return (
    <div className="w-full bg-white border-b border-gray-100 py-6 sm:py-8 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-5">
          <h2 className="text-lg font-bold text-gray-800 tracking-tight flex items-center gap-1.5">
            <span>Explore Categories</span>
            <span className="text-xs font-normal text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">
              {categories.length} total
            </span>
          </h2>
          {activeCategoryId && (
            <button
              onClick={() => onSelectCategory(null)}
              className="text-xs font-semibold text-[#b08865] hover:text-[#937153] transition flex items-center gap-1 cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>

        {/* Categories Grid/Carousel */}
        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-9 gap-4 md:gap-3">
          {loading ? (
            Array.from({ length: 9 }).map((_, index) => (
              <div key={index} className="flex flex-col items-center animate-pulse">
                <div className="w-14 h-14 rounded-full bg-gray-100 mb-2"></div>
                <div className="w-16 h-3 bg-gray-100 rounded"></div>
              </div>
            ))
          ) : (
            categories.map(cat => {
              // Dynamically reference Lucide icon component
              const IconComp = (Icons as any)[cat.icon] || Icons.Grid;
              const isActive = activeCategoryId === cat.id;

              return (
                <button
                  key={cat.id}
                  onClick={() => onSelectCategory(isActive ? null : cat.id)}
                  className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-center transition group cursor-pointer ${
                    isActive
                      ? 'bg-green-50 border-[#b08865] text-[#3e3023]'
                      : 'bg-white border-gray-100 hover:border-gray-300 hover:bg-gray-50 text-gray-600'
                  }`}
                >
                  {/* Icon Circle */}
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 shadow-xs transition group-hover:scale-105 duration-200 ${
                      isActive
                        ? 'bg-[#b08865] text-white'
                        : 'bg-green-50 text-[#b08865] group-hover:bg-[#b08865] group-hover:text-white'
                    }`}
                  >
                    <IconComp className="w-5 h-5 stroke-[2.2]" />
                  </div>

                  {/* Title */}
                  <span className="text-[11px] sm:text-[12px] font-semibold leading-tight tracking-tight line-clamp-1">
                    {cat.name}
                  </span>

                  {/* Count Tag */}
                  <span className="text-[9px] text-gray-400 mt-0.5 font-medium">
                    {cat.adCount.toLocaleString()} ads
                  </span>
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
