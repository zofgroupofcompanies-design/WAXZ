import React, { useState, useEffect } from 'react';
import { 
  Trophy, Award, ShieldCheck, Star, Clock, ShoppingBag, 
  Search, ArrowUpRight, CheckCircle2, Zap, Globe, Sparkles, MessageSquare, ChevronRight
} from 'lucide-react';
import { TopSeller, Listing } from '../types';
import { CurrencyCode, formatConvertedPrice } from '../utils/currency';

interface TopSellersProps {
  selectedCurrency: CurrencyCode;
  onViewListing?: (listingId: string) => void;
  onInitiateChat?: (listing: Listing) => void;
  onBrowseSellerProducts?: (sellerId: string, sellerName: string) => void;
}

export default function TopSellers({
  selectedCurrency,
  onViewListing,
  onInitiateChat,
  onBrowseSellerProducts
}: TopSellersProps) {
  const [topSellers, setTopSellers] = useState<TopSeller[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCountry, setSelectedCountry] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'volume' | 'orders' | 'rating' | 'speed'>('volume');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeVendorDetail, setActiveVendorDetail] = useState<TopSeller | null>(null);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (selectedCountry !== 'All') params.append('country', selectedCountry);
    if (sortBy) params.append('sortBy', sortBy);
    if (searchQuery) params.append('search', searchQuery);

    fetch(`/api/sellers/top?${params.toString()}`)
      .then(res => res.json())
      .then((data: TopSeller[]) => {
        setTopSellers(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load top sellers:', err);
        setLoading(false);
      });
  }, [selectedCountry, sortBy, searchQuery]);

  const topThree = topSellers.slice(0, 3);
  const remainingSellers = topSellers.slice(3);

  const getTierColor = (tier: TopSeller['tier']) => {
    switch (tier) {
      case 'Platinum Power Vendor':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Gold Merchant':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Top Dispatcher':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    }
  };

  const getCountryFlag = (country: string) => {
    const c = country.toLowerCase();
    if (c.includes('ghana')) return '🇬🇭';
    if (c.includes('nigeria')) return '🇳🇬';
    if (c.includes('togo')) return '🇹🇬';
    if (c.includes('kenya')) return '🇰🇪';
    if (c.includes('united kingdom') || c.includes('uk')) return '🇬🇧';
    if (c.includes('united states') || c.includes('usa') || c.includes('us')) return '🇺🇸';
    return '🌍';
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col gap-8">
      {/* HEADER BANNER */}
      <div className="bg-gradient-to-r from-[#291f17] via-[#3e3023] to-[#4d3a2a] rounded-2xl p-6 sm:p-10 text-white shadow-xl relative overflow-hidden border border-amber-900/40">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl space-y-3">
            <div className="inline-flex items-center gap-2 bg-amber-500/20 text-yellow-300 border border-amber-400/30 text-xs font-black px-3 py-1 rounded-full uppercase tracking-widest">
              <Trophy className="w-4 h-4 text-yellow-400 animate-bounce" />
              Platform Community Leaderboard
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
              Top Marketplace Vendors & Power Sellers
            </h2>
            <p className="text-xs sm:text-sm text-amber-100/90 font-medium leading-relaxed">
              Verified sellers ranked by successful escrow-secured transaction volume, order completion speed, buyer ratings, and dispatch efficiency across West Africa and overseas exporters.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 shrink-0">
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10 text-center">
              <div className="text-lg font-black text-yellow-300 font-mono">100%</div>
              <div className="text-[10px] uppercase font-bold text-amber-100">Escrow Protected</div>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10 text-center">
              <div className="text-lg font-black text-yellow-300 font-mono">4.92 ★</div>
              <div className="text-[10px] uppercase font-bold text-amber-100">Avg Vendor Rating</div>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10 text-center col-span-2 sm:col-span-1">
              <div className="text-lg font-black text-yellow-300 font-mono">&lt; 20 min</div>
              <div className="text-[10px] uppercase font-bold text-amber-100">Response Speed</div>
            </div>
          </div>
        </div>

        {/* Decorative ambient blur */}
        <div className="absolute -right-12 -bottom-12 w-64 h-64 bg-amber-500/10 rounded-full filter blur-3xl pointer-events-none" />
      </div>

      {/* FILTER & METRIC CONTROLS */}
      <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Country Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
          <span className="text-xs font-bold text-gray-500 shrink-0 mr-1 flex items-center gap-1">
            <Globe className="w-3.5 h-3.5" />
            Country:
          </span>
          {['All', 'Ghana', 'Nigeria', 'Togo', 'Kenya', 'United Kingdom', 'United States'].map((c) => (
            <button
              key={c}
              onClick={() => setSelectedCountry(c)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                selectedCountry === c
                  ? 'bg-[#3e3023] text-yellow-300 shadow-sm'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <span>{getCountryFlag(c)}</span>
              <span>{c === 'United Kingdom' ? 'UK' : c === 'United States' ? 'USA' : c}</span>
            </button>
          ))}
        </div>

        {/* Right side: Search & Sort Metric */}
        <div className="flex items-center gap-3 w-full md:w-auto shrink-0">
          <div className="relative flex-1 md:w-48">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search vendor name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-8 pr-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-[#b08865] text-gray-800"
            />
          </div>

          <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-lg shrink-0">
            <button
              onClick={() => setSortBy('volume')}
              className={`px-2.5 py-1 rounded text-[11px] font-bold transition cursor-pointer ${
                sortBy === 'volume' ? 'bg-white text-[#3e3023] shadow-xs' : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Sort by Transaction Volume"
            >
              Volume ($)
            </button>
            <button
              onClick={() => setSortBy('orders')}
              className={`px-2.5 py-1 rounded text-[11px] font-bold transition cursor-pointer ${
                sortBy === 'orders' ? 'bg-white text-[#3e3023] shadow-xs' : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Sort by Completed Orders"
            >
              Orders (#)
            </button>
            <button
              onClick={() => setSortBy('rating')}
              className={`px-2.5 py-1 rounded text-[11px] font-bold transition cursor-pointer ${
                sortBy === 'rating' ? 'bg-white text-[#3e3023] shadow-xs' : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Sort by Rating"
            >
              Rating (★)
            </button>
          </div>
        </div>
      </div>

      {loading ? (
        /* SKELETON LOADER */
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="bg-white rounded-2xl border border-gray-200 p-6 animate-pulse flex flex-col gap-4">
              <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto" />
              <div className="h-5 bg-gray-200 rounded w-3/4 mx-auto" />
              <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto" />
              <div className="h-20 bg-gray-100 rounded-xl" />
            </div>
          ))}
        </div>
      ) : topSellers.length === 0 ? (
        /* EMPTY STATE */
        <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center flex flex-col items-center justify-center">
          <Trophy className="w-12 h-12 text-gray-300 mb-3" />
          <h4 className="font-bold text-gray-800 text-base mb-1">No Top Sellers Found</h4>
          <p className="text-xs text-gray-500 max-w-sm">
            No vendors matched your country filter or search term. Try resetting your search parameters.
          </p>
          <button
            onClick={() => { setSelectedCountry('All'); setSearchQuery(''); setSortBy('volume'); }}
            className="mt-4 bg-[#b08865] text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-[#937153] transition cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <>
          {/* TOP 3 PODIUM SPOTLIGHT */}
          {topThree.length > 0 && (
            <div className="flex flex-col md:flex-row items-stretch justify-center gap-6">
              {/* Order of Podium: #2 (Silver, left on desktop), #1 (Gold, center on desktop), #3 (Bronze, right on desktop) */}
              {(() => {
                const podiumOrder = [
                  topThree[1], // Rank #2
                  topThree[0], // Rank #1
                  topThree[2]  // Rank #3
                ].filter(Boolean);

                return podiumOrder.map((seller) => {
                  const actualRank = topSellers.findIndex(s => s.sellerId === seller.sellerId) + 1;
                  const isFirst = actualRank === 1;
                  const isSecond = actualRank === 2;
                  
                  return (
                    <div
                      key={seller.sellerId}
                      className={`flex-1 bg-white rounded-2xl border transition-all duration-300 relative flex flex-col justify-between p-6 hover:shadow-xl ${
                        isFirst
                          ? 'border-amber-400 shadow-lg ring-2 ring-amber-400/30 md:-translate-y-3 bg-gradient-to-b from-amber-50/40 via-white to-white'
                          : isSecond
                          ? 'border-gray-300 shadow-md'
                          : 'border-amber-700/30 shadow-sm'
                      }`}
                    >
                      {/* Rank Badge Header */}
                      <div className="absolute -top-4 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-black shadow-md border uppercase tracking-wider text-white select-none"
                        style={{
                          backgroundColor: isFirst ? '#d97706' : isSecond ? '#6b7280' : '#b45309',
                          borderColor: isFirst ? '#f59e0b' : isSecond ? '#9ca3af' : '#d97706'
                        }}
                      >
                        {isFirst ? '🥇 Rank #1' : isSecond ? '🥈 Rank #2' : '🥉 Rank #3'}
                      </div>

                      <div className="pt-2 flex flex-col items-center text-center gap-3">
                        {/* Avatar */}
                        <div className="relative">
                          <img
                            src={seller.avatarUrl}
                            alt={seller.sellerName}
                            className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-md"
                          />
                          {seller.verified && (
                            <span className="absolute bottom-0 right-0 bg-blue-600 text-white p-1 rounded-full border-2 border-white shadow-xs" title="Escrow Verified Seller">
                              <ShieldCheck className="w-4 h-4" />
                            </span>
                          )}
                        </div>

                        {/* Name & Country */}
                        <div>
                          <h3 className="font-extrabold text-gray-900 text-base leading-tight flex items-center justify-center gap-1.5">
                            <span>{seller.sellerName}</span>
                            <span>{getCountryFlag(seller.country)}</span>
                          </h3>
                          <p className="text-xs text-gray-500 font-medium mt-0.5">
                            {seller.region}
                          </p>
                        </div>

                        {/* Badge Tier */}
                        <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full border ${getTierColor(seller.tier)}`}>
                          {seller.tier}
                        </span>

                        {/* Transaction Metrics Box */}
                        <div className="w-full bg-gray-50 rounded-xl p-3.5 border border-gray-100 grid grid-cols-2 gap-2 text-left my-2">
                          <div>
                            <span className="text-[10px] text-gray-400 font-bold uppercase block">Sales Volume</span>
                            <span className="text-sm font-black text-[#291f17] font-mono tabular-nums">
                              {formatConvertedPrice(seller.totalSalesVolumeUSD * 16, 'Ghana', selectedCurrency)}
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] text-gray-400 font-bold uppercase block">Completed Orders</span>
                            <span className="text-sm font-black text-emerald-700 font-mono tabular-nums">
                              {seller.completedOrders} orders
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] text-gray-400 font-bold uppercase block">Customer Rating</span>
                            <span className="text-xs font-black text-amber-600 flex items-center gap-1">
                              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                              <span>{seller.rating}</span>
                              <span className="text-gray-400 font-normal">({seller.reviewCount})</span>
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] text-gray-400 font-bold uppercase block">Dispatch Speed</span>
                            <span className="text-xs font-black text-gray-700 flex items-center gap-1">
                              <Zap className="w-3.5 h-3.5 text-blue-500" />
                              <span>{seller.responseTimeMinutes} mins</span>
                            </span>
                          </div>
                        </div>

                        {/* Badges list */}
                        <div className="flex flex-wrap justify-center gap-1.5 my-1">
                          {seller.badges.map((b, idx) => (
                            <span key={idx} className="text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200/60 px-2 py-0.5 rounded">
                              ✓ {b}
                            </span>
                          ))}
                        </div>

                        {/* Featured Product Preview */}
                        {seller.featuredProducts && seller.featuredProducts.length > 0 && (
                          <div className="w-full text-left pt-2 border-t border-gray-100">
                            <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider block mb-1.5">
                              Hot Product Listing
                            </span>
                            <div
                              onClick={() => onViewListing && onViewListing(seller.featuredProducts![0].id)}
                              className="bg-gray-50 hover:bg-amber-50/50 rounded-lg p-2 flex items-center gap-2.5 border border-gray-200/70 cursor-pointer transition"
                            >
                              <img
                                src={seller.featuredProducts[0].image}
                                alt={seller.featuredProducts[0].title}
                                className="w-10 h-10 rounded-md object-cover border shrink-0"
                              />
                              <div className="flex-1 min-w-0">
                                <h5 className="text-xs font-bold text-gray-800 truncate">
                                  {seller.featuredProducts[0].title}
                                </h5>
                                <span className="text-xs font-black text-[#b08865] font-mono">
                                  {formatConvertedPrice(seller.featuredProducts[0].price, seller.country, selectedCurrency)}
                                </span>
                              </div>
                              <ArrowUpRight className="w-4 h-4 text-gray-400 shrink-0" />
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Action buttons */}
                      <div className="pt-4 border-t border-gray-100 flex gap-2">
                        <button
                          onClick={() => onBrowseSellerProducts && onBrowseSellerProducts(seller.sellerId, seller.sellerName)}
                          className="flex-1 bg-[#3e3023] hover:bg-[#291f17] text-yellow-300 font-bold text-xs py-2 px-3 rounded-lg transition cursor-pointer flex items-center justify-center gap-1 shadow-xs"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>View Listings</span>
                        </button>
                        <button
                          onClick={() => {
                            if (seller.featuredProducts && seller.featuredProducts.length > 0 && onInitiateChat) {
                              const mockListing: Listing = {
                                id: seller.featuredProducts[0].id,
                                title: seller.featuredProducts[0].title,
                                categoryId: 'cat-1',
                                categoryName: 'General',
                                subCategory: 'General',
                                description: 'Contact vendor directly',
                                price: seller.featuredProducts[0].price,
                                isNegotiable: true,
                                condition: 'New',
                                country: seller.country,
                                region: seller.region,
                                neighborhood: seller.region,
                                imageUrls: [seller.featuredProducts[0].image],
                                sellerName: seller.sellerName,
                                sellerPhone: '+233 24 000 0000',
                                sellerWhatsApp: '+233 24 000 0000',
                                createdAt: new Date().toISOString(),
                                views: 100,
                                isFeatured: true,
                                sellerId: seller.sellerId,
                                status: 'active'
                              };
                              onInitiateChat(mockListing);
                            }
                          }}
                          className="bg-amber-100 hover:bg-amber-200 text-amber-900 p-2 rounded-lg transition cursor-pointer"
                          title="Message Vendor"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          )}

          {/* LEADERBOARD TABLE FOR RANKS #4 AND BELOW */}
          {remainingSellers.length > 0 && (
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden mt-4">
              <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                <h3 className="font-extrabold text-gray-800 text-sm flex items-center gap-2">
                  <Award className="w-4 h-4 text-[#b08865]" />
                  <span>Full Vendor Leaderboard Ranking</span>
                </h3>
                <span className="text-xs text-gray-500 font-semibold">
                  Showing #{4} to #{topSellers.length} vendors
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-gray-100/70 text-gray-500 font-bold border-b border-gray-200 uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="py-3 px-4 text-center">Rank</th>
                      <th className="py-3 px-4">Vendor Details</th>
                      <th className="py-3 px-4">Location</th>
                      <th className="py-3 px-4 text-right">Volume</th>
                      <th className="py-3 px-4 text-center">Orders</th>
                      <th className="py-3 px-4 text-center">Rating</th>
                      <th className="py-3 px-4 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 font-medium text-gray-700">
                    {remainingSellers.map((seller, idx) => {
                      const rankNum = idx + 4;
                      return (
                        <tr key={seller.sellerId} className="hover:bg-amber-50/30 transition">
                          <td className="py-3.5 px-4 text-center font-black text-gray-400 font-mono text-sm">
                            #{rankNum}
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-3">
                              <img
                                src={seller.avatarUrl}
                                alt={seller.sellerName}
                                className="w-9 h-9 rounded-full object-cover border shrink-0"
                              />
                              <div>
                                <div className="font-bold text-gray-900 flex items-center gap-1.5">
                                  <span>{seller.sellerName}</span>
                                  {seller.verified && (
                                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 inline shrink-0" />
                                  )}
                                </div>
                                <div className="text-[10px] text-gray-400 font-semibold">
                                  {seller.tier}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="flex items-center gap-1 text-gray-600 font-medium">
                              <span>{getCountryFlag(seller.country)}</span>
                              <span>{seller.region}</span>
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-right font-black text-gray-900 font-mono tabular-nums">
                            {formatConvertedPrice(seller.totalSalesVolumeUSD * 16, 'Ghana', selectedCurrency)}
                          </td>
                          <td className="py-3.5 px-4 text-center font-bold text-emerald-700 font-mono">
                            {seller.completedOrders}
                          </td>
                          <td className="py-3.5 px-4 text-center font-bold text-amber-600">
                            ★ {seller.rating}
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <button
                              onClick={() => onBrowseSellerProducts && onBrowseSellerProducts(seller.sellerId, seller.sellerName)}
                              className="bg-gray-100 hover:bg-[#3e3023] hover:text-yellow-300 text-gray-700 font-bold px-3 py-1.5 rounded-lg transition cursor-pointer text-[11px] inline-flex items-center gap-1"
                            >
                              <span>Store</span>
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
