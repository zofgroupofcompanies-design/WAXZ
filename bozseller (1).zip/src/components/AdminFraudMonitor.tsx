import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, ShieldCheck, AlertTriangle, RefreshCw, CheckCircle2, X, Search, 
  Sparkles, Filter, Bell, UserX, Trash2, Shield, Eye, Play, ArrowRight
} from 'lucide-react';

interface FraudAlert {
  id: string;
  listingId: string;
  listingTitle: string;
  listingPrice: number;
  listingCountry: string;
  sellerId: string;
  sellerName: string;
  sellerPhone?: string;
  fraudScore: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  flags: string[];
  explanation: string;
  recommendation: 'approve' | 'flag_for_review' | 'auto_block';
  status: 'unresolved' | 'deactivated' | 'dismissed' | 'seller_banned';
  detectedAt: string;
  resolvedAt?: string;
}

interface AdminNotification {
  id: string;
  type: 'fraud_alert' | 'kyc_alert' | 'report_alert' | 'system';
  title: string;
  message: string;
  severity: 'info' | 'medium' | 'high' | 'critical';
  read: boolean;
  listingId?: string;
  sellerId?: string;
  createdAt: string;
}

export default function AdminFraudMonitor() {
  const [alerts, setAlerts] = useState<FraudAlert[]>([]);
  const [notifications, setNotifications] = useState<AdminNotification[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [scanning, setScanning] = useState<boolean>(false);
  const [scanMessage, setScanMessage] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<'all' | 'unresolved' | 'deactivated' | 'dismissed'>('unresolved');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Interactive Single-Ad AI Sandbox State
  const [testTitle, setTestTitle] = useState('Toyota Land Cruiser V8 2023');
  const [testPrice, setTestPrice] = useState('5000');
  const [testDescription, setTestDescription] = useState('Urgent sale! Moving abroad tomorrow. Send mobile money deposit to reserve before inspection.');
  const [testCountry, setTestCountry] = useState('Ghana');
  const [testResult, setTestResult] = useState<any | null>(null);
  const [testingAi, setTestingAi] = useState(false);

  const fetchFraudData = async () => {
    setLoading(true);
    try {
      const [alertsRes, notifRes] = await Promise.all([
        fetch('/api/admin/fraud-alerts'),
        fetch('/api/admin/notifications')
      ]);

      if (alertsRes.ok) {
        setAlerts(await alertsRes.json());
      }
      if (notifRes.ok) {
        setNotifications(await notifRes.json());
      }
    } catch (err) {
      console.error('Failed to fetch fraud monitor data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFraudData();
  }, []);

  const handleRunFullScan = async () => {
    setScanning(true);
    setScanMessage(null);
    try {
      const res = await fetch('/api/admin/fraud-scan-all', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setScanMessage(data.message || `Full scan completed across ${data.scannedCount} listings.`);
        fetchFraudData();
      }
    } catch (err) {
      console.error('Error running AI fraud scan:', err);
      setScanMessage('Failed to trigger full AI fraud scan.');
    } finally {
      setScanning(false);
    }
  };

  const handleResolveAlert = async (alertId: string, action: 'deactivate' | 'ban_seller' | 'dismiss') => {
    const confirmMsg = action === 'ban_seller' 
      ? 'Ban seller and deactivate all their listings?' 
      : action === 'deactivate'
      ? 'Deactivate this flagged listing from the platform?'
      : 'Dismiss this fraud alert?';

    if (!window.confirm(confirmMsg)) return;

    try {
      const res = await fetch(`/api/admin/fraud-alerts/${alertId}/resolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      });
      const data = await res.json();
      if (data.success) {
        fetchFraudData();
      }
    } catch (err) {
      console.error('Error resolving alert:', err);
    }
  };

  const handleMarkNotificationRead = async (id: string) => {
    try {
      await fetch(`/api/admin/notifications/${id}/read`, { method: 'POST' });
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    } catch (e) {}
  };

  const handleRunSingleTest = async (e: React.FormEvent) => {
    e.preventDefault();
    setTestingAi(true);
    setTestResult(null);

    try {
      const res = await fetch('/api/ai/fraud-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: testTitle,
          price: Number(testPrice),
          description: testDescription,
          country: testCountry,
          sellerName: 'Sandbox Test Vendor'
        })
      });
      const data = await res.json();
      setTestResult(data);
    } catch (err) {
      console.error('Test error:', err);
    } finally {
      setTestingAi(false);
    }
  };

  const filteredAlerts = alerts.filter(a => {
    const matchesStatus = statusFilter === 'all' || a.status === statusFilter;
    const matchesSearch = a.listingTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          a.sellerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          a.listingCountry.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="flex flex-col gap-6 text-left">
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-slate-800 to-red-950 p-6 rounded-2xl text-white shadow-lg border border-slate-800">
        <div className="flex items-center gap-4">
          <div className="bg-red-500/20 text-red-400 p-3.5 rounded-2xl border border-red-500/30 animate-pulse shrink-0">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black tracking-tight text-white">AI Fraud Detector & Threat Monitoring</h2>
              <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold text-[10px] px-2.5 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-400 fill-emerald-400" />
                Gemini 3.6 Flash Active
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 max-w-xl">
              Real-time threat monitoring scans listings for advance-fee scams, off-platform wire transfers, unrealistic prices, and suspicious vendor behavior.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={handleRunFullScan}
            disabled={scanning}
            className="bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-black text-xs px-4 py-3 rounded-xl transition cursor-pointer flex items-center gap-2 shadow-md"
          >
            <RefreshCw className={`w-4 h-4 ${scanning ? 'animate-spin' : ''}`} />
            <span>{scanning ? 'Scanning Database...' : 'Run Full AI Database Scan'}</span>
          </button>
        </div>
      </div>

      {scanMessage && (
        <div className="bg-blue-50 border border-blue-200 text-blue-900 p-4 rounded-xl text-xs font-bold flex items-center justify-between animate-in fade-in duration-150">
          <span>{scanMessage}</span>
          <button onClick={() => setScanMessage(null)} className="text-blue-500 hover:text-blue-700">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* METRIC CARDS GRID */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-xs flex flex-col gap-1">
          <span className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider">Unresolved Threat Alerts</span>
          <span className="text-2xl font-black text-red-600">
            {alerts.filter(a => a.status === 'unresolved').length}
          </span>
          <span className="text-[10px] text-red-500 font-bold mt-1">Requires Admin Action</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-xs flex flex-col gap-1">
          <span className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider">Critical Risk Scams</span>
          <span className="text-2xl font-black text-amber-600">
            {alerts.filter(a => a.riskLevel === 'critical' && a.status === 'unresolved').length}
          </span>
          <span className="text-[10px] text-amber-600 font-bold mt-1">Auto-Block Recommended</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-xs flex flex-col gap-1">
          <span className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider">Security Notifications</span>
          <span className="text-2xl font-black text-blue-600">{unreadCount}</span>
          <span className="text-[10px] text-blue-500 font-bold mt-1">{unreadCount > 0 ? 'Unread Dispatches' : 'All Read'}</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-xs flex flex-col gap-1">
          <span className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider">Deactivated Scam Ads</span>
          <span className="text-2xl font-black text-emerald-600">
            {alerts.filter(a => a.status === 'deactivated' || a.status === 'seller_banned').length}
          </span>
          <span className="text-[10px] text-emerald-600 font-bold mt-1">Protected Community</span>
        </div>
      </div>

      {/* REAL-TIME SECURITY NOTIFICATION DISPATCH PANEL */}
      {notifications.length > 0 && (
        <div className="bg-amber-500/10 border border-amber-300 rounded-2xl p-5 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-amber-600 animate-bounce" />
              <h3 className="font-black text-sm text-amber-950 uppercase tracking-wide">
                Real-Time Administrator Security Notifications ({unreadCount} Unread)
              </h3>
            </div>
            <span className="text-[10px] bg-amber-200 text-amber-900 font-black px-2.5 py-0.5 rounded-full">
              LIVE BROADCAST
            </span>
          </div>

          <div className="flex flex-col gap-2 max-h-48 overflow-y-auto pr-1">
            {notifications.map(n => (
              <div 
                key={n.id}
                className={`p-3 rounded-xl border flex items-start justify-between gap-3 text-xs transition ${
                  n.read 
                    ? 'bg-white/60 border-amber-200/60 opacity-70' 
                    : 'bg-white border-amber-400 shadow-xs'
                }`}
              >
                <div className="flex gap-2.5 items-start">
                  <span className="text-base shrink-0 mt-0.5">
                    {n.severity === 'critical' ? '🚨' : n.severity === 'high' ? '⚠️' : '📢'}
                  </span>
                  <div className="flex flex-col">
                    <span className="font-extrabold text-gray-900">{n.title}</span>
                    <span className="text-gray-700 leading-snug mt-0.5">{n.message}</span>
                    <span className="text-[10px] text-gray-400 mt-1 font-mono">{new Date(n.createdAt).toLocaleString()}</span>
                  </div>
                </div>

                {!n.read && (
                  <button
                    onClick={() => handleMarkNotificationRead(n.id)}
                    className="text-[10px] bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold px-2 py-1 rounded transition cursor-pointer shrink-0"
                  >
                    Mark Read
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MAIN FRAUD ALERTS SECTION */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs flex flex-col gap-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-gray-100">
          <div>
            <h3 className="font-extrabold text-base text-gray-900">Flagged Fraud & Scam Alert Queue</h3>
            <p className="text-xs text-gray-400 mt-0.5">Scanned listings requiring administrator review and enforcement action.</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search listing or seller..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-gray-50 border border-gray-200 rounded-lg pl-8 pr-3 py-1.5 text-xs font-semibold focus:outline-none focus:border-red-500 w-44"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 text-xs font-semibold focus:outline-none focus:border-red-500 cursor-pointer"
            >
              <option value="unresolved">Unresolved Only</option>
              <option value="deactivated">Deactivated Scams</option>
              <option value="dismissed">Dismissed Flags</option>
              <option value="all">All Threat Log States</option>
            </select>
          </div>
        </div>

        {/* ALERTS LIST */}
        {loading ? (
          <div className="p-12 text-center text-gray-400 flex flex-col items-center">
            <RefreshCw className="w-8 h-8 animate-spin text-red-500 mb-2" />
            <span className="text-xs font-bold">Checking Threat Intelligence Feed...</span>
          </div>
        ) : filteredAlerts.length === 0 ? (
          <div className="p-12 text-center bg-gray-50/50 rounded-2xl border border-dashed border-gray-200">
            <ShieldCheck className="w-12 h-12 text-emerald-500 mx-auto mb-2 opacity-80" />
            <h4 className="font-extrabold text-gray-800 text-sm">No Active Fraud Threats Detected</h4>
            <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto">
              All marketplace listings pass the AI Fraud Detector standard parameters.
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {filteredAlerts.map(alert => (
              <div 
                key={alert.id}
                className={`p-5 rounded-2xl border transition flex flex-col gap-4 shadow-xs ${
                  alert.status !== 'unresolved'
                    ? 'border-gray-200 bg-gray-50/50 opacity-75'
                    : alert.riskLevel === 'critical'
                    ? 'border-red-300 bg-red-50/20'
                    : 'border-amber-300 bg-amber-50/20'
                }`}
              >
                {/* Alert Top Title Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-gray-200/60">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-black text-sm text-gray-900">{alert.listingTitle}</span>
                    <span className="font-black text-xs text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                      GH₵ {alert.listingPrice.toLocaleString()} ({alert.listingCountry})
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase flex items-center gap-1 ${
                      alert.riskLevel === 'critical'
                        ? 'bg-red-600 text-white animate-pulse'
                        : alert.riskLevel === 'high'
                        ? 'bg-amber-500 text-white'
                        : 'bg-blue-600 text-white'
                    }`}>
                      <AlertTriangle className="w-3 h-3" />
                      {alert.riskLevel} RISK ({alert.fraudScore}%)
                    </span>

                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase border ${
                      alert.status === 'unresolved' 
                        ? 'bg-red-100 text-red-800 border-red-200' 
                        : alert.status === 'deactivated' || alert.status === 'seller_banned'
                        ? 'bg-gray-200 text-gray-700 border-gray-300'
                        : 'bg-emerald-100 text-emerald-800 border-emerald-200'
                    }`}>
                      {alert.status.replace('_', ' ')}
                    </span>
                  </div>
                </div>

                {/* Score Progress & Rationale Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  {/* Score & Risk bar */}
                  <div className="bg-white p-3.5 rounded-xl border border-gray-200 space-y-2">
                    <div className="flex justify-between items-center font-bold">
                      <span className="text-gray-500 uppercase text-[10px]">AI Threat Probability</span>
                      <span className="text-red-600 font-mono font-black">{alert.fraudScore}%</span>
                    </div>
                    <div className="w-full bg-gray-100 h-3 rounded-full overflow-hidden">
                      <div 
                        style={{ width: `${alert.fraudScore}%` }} 
                        className={`h-full rounded-full ${
                          alert.fraudScore >= 80 ? 'bg-red-600' : alert.fraudScore >= 50 ? 'bg-amber-500' : 'bg-blue-500'
                        }`}
                      />
                    </div>
                    <div className="text-[10px] text-gray-500">
                      Seller: <strong className="text-gray-800">{alert.sellerName}</strong> ({alert.sellerPhone || 'No Phone'})
                    </div>
                  </div>

                  {/* Detected Flags */}
                  <div className="bg-white p-3.5 rounded-xl border border-gray-200 space-y-1">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider block">
                      Detected Scam Indicators
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {alert.flags.map((flag, idx) => (
                        <span key={idx} className="bg-red-100 text-red-800 font-bold text-[10px] px-2 py-0.5 rounded border border-red-200">
                          • {flag}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Rationale Explanation */}
                  <div className="bg-white p-3.5 rounded-xl border border-gray-200 space-y-1">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider block">
                      AI Detector Rationale
                    </span>
                    <p className="text-[11px] text-gray-700 leading-relaxed font-medium italic">
                      "{alert.explanation}"
                    </p>
                  </div>
                </div>

                {/* Action Buttons */}
                {alert.status === 'unresolved' && (
                  <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-gray-200/60">
                    <button
                      onClick={() => handleResolveAlert(alert.id, 'dismiss')}
                      className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs px-3 py-2 rounded-xl transition cursor-pointer"
                    >
                      Dismiss Flag
                    </button>

                    <button
                      onClick={() => handleResolveAlert(alert.id, 'deactivate')}
                      className="bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-xs px-3.5 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-2xs"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Deactivate Listing</span>
                    </button>

                    <button
                      onClick={() => handleResolveAlert(alert.id, 'ban_seller')}
                      className="bg-red-600 hover:bg-red-700 text-white font-black text-xs px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-xs"
                    >
                      <UserX className="w-4 h-4" />
                      <span>Ban Fraudulent Seller</span>
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* INTERACTIVE SINGLE-AD AI THREAT SANDBOX */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs flex flex-col gap-4">
        <div className="flex items-center gap-2 pb-3 border-b border-gray-100">
          <div className="bg-slate-900 text-yellow-400 p-2 rounded-xl">
            <Sparkles className="w-5 h-5 fill-yellow-400" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm text-gray-900">Interactive Gemini AI Threat Sandbox</h3>
            <p className="text-xs text-gray-400 mt-0.5">Test any custom listing parameters against the Gemini AI Fraud Detector in real-time.</p>
          </div>
        </div>

        <form onSubmit={handleRunSingleTest} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-extrabold text-gray-500 uppercase">Test Title</label>
            <input
              type="text"
              value={testTitle}
              onChange={(e) => setTestTitle(e.target.value)}
              className="bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-red-500"
            />
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-extrabold text-gray-500 uppercase">Test Price (GHS)</label>
            <input
              type="number"
              value={testPrice}
              onChange={(e) => setTestPrice(e.target.value)}
              className="bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-red-500"
            />
          </div>

          <div className="flex flex-col gap-1 sm:col-span-2">
            <label className="text-[10px] font-extrabold text-gray-500 uppercase">Description / Contact Notes</label>
            <input
              type="text"
              value={testDescription}
              onChange={(e) => setTestDescription(e.target.value)}
              className="bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-red-500"
            />
          </div>

          <button
            type="submit"
            disabled={testingAi}
            className="sm:col-span-4 bg-slate-900 hover:bg-slate-800 text-yellow-300 font-black text-xs py-3 px-4 rounded-xl transition cursor-pointer flex items-center justify-center gap-2 shadow-xs disabled:opacity-50"
          >
            {testingAi ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-yellow-300" />
                <span>Evaluating Listing Intent with Gemini AI...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 text-emerald-400 fill-emerald-400" />
                <span>Test Listing with Gemini AI Fraud Engine</span>
              </>
            )}
          </button>
        </form>

        {testResult && (
          <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 flex flex-col gap-3 font-mono text-xs animate-in zoom-in-95">
            <div className="flex justify-between items-center pb-2 border-b border-slate-800">
              <span className="text-yellow-400 font-bold uppercase">Sandbox Test Output</span>
              <span className={`px-2.5 py-0.5 rounded font-black uppercase text-[10px] ${
                testResult.riskLevel === 'critical' ? 'bg-red-500 text-white' : 'bg-emerald-500 text-black'
              }`}>
                {testResult.riskLevel} RISK ({testResult.fraudScore}%)
              </span>
            </div>

            <p className="text-slate-300 font-sans text-xs italic">
              "{testResult.explanation}"
            </p>

            <div className="flex flex-wrap gap-1 mt-1">
              {(testResult.flags || []).map((f: string, i: number) => (
                <span key={i} className="bg-red-500/20 text-red-300 border border-red-500/30 px-2 py-0.5 rounded text-[10px]">
                  • {f}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
