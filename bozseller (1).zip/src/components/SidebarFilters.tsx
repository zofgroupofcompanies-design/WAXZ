import { SlidersHorizontal, ArrowUpDown, ShieldCheck, RefreshCw } from 'lucide-react';

interface SidebarFiltersProps {
  selectedCondition: string;
  setSelectedCondition: (condition: string) => void;
  minPrice: number | '';
  setMinPrice: (price: number | '') => void;
  maxPrice: number | '';
  setMaxPrice: (price: number | '') => void;
  sortBy: string;
  setSortBy: (sort: string) => void;
  onClearFilters: () => void;
  currencySymbol?: string;
}

export default function SidebarFilters({
  selectedCondition,
  setSelectedCondition,
  minPrice,
  setMinPrice,
  maxPrice,
  setMaxPrice,
  sortBy,
  setSortBy,
  onClearFilters,
  currencySymbol = 'GH₵'
}: SidebarFiltersProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-xs shrink-0 w-full lg:w-72 flex flex-col gap-6 h-fit">
      {/* Title */}
      <div className="flex items-center justify-between pb-3.5 border-b border-gray-100">
        <span className="font-extrabold text-gray-800 text-sm tracking-tight flex items-center gap-1.5">
          <SlidersHorizontal className="w-4 h-4 text-[#3db83a]" />
          <span>Filters</span>
        </span>
        <button
          onClick={onClearFilters}
          className="text-xs text-gray-400 hover:text-red-500 font-medium flex items-center gap-1 cursor-pointer transition"
        >
          <RefreshCw className="w-3 h-3" />
          <span>Reset</span>
        </button>
      </div>

      {/* Sort By */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1">
          <ArrowUpDown className="w-3.5 h-3.5" />
          <span>Sort Listings</span>
        </label>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-xs text-gray-700 font-semibold focus:outline-none focus:border-[#3db83a] focus:ring-1 focus:ring-[#3db83a] cursor-pointer"
        >
          <option value="newest">Newest First</option>
          <option value="popular">Most Popular</option>
          <option value="price-asc">Price: Low to High</option>
          <option value="price-desc">Price: High to Low</option>
        </select>
      </div>

      {/* Condition */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">
          Condition
        </label>
        <div className="flex flex-col gap-1.5">
          {['All', 'New', 'Refurbished', 'Used'].map((cond) => {
            const isActive = selectedCondition === cond;
            return (
              <button
                key={cond}
                onClick={() => setSelectedCondition(cond)}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-semibold border transition flex items-center justify-between cursor-pointer ${
                  isActive
                    ? 'bg-green-50 border-[#3db83a] text-green-950'
                    : 'bg-white border-gray-100 hover:bg-gray-50 text-gray-600'
                }`}
              >
                <span>{cond}</span>
                {isActive && <div className="w-1.5 h-1.5 rounded-full bg-[#3db83a]" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Price Range */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">
          Price Range ({currencySymbol})
        </label>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <span className="text-[9px] text-gray-400 font-bold block mb-1">MIN PRICE</span>
            <input
              type="number"
              placeholder="e.g. 500"
              value={minPrice}
              onChange={(e) => setMinPrice(e.target.value === '' ? '' : Number(e.target.value))}
              className="w-full bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-[#3db83a]"
            />
          </div>
          <div>
            <span className="text-[9px] text-gray-400 font-bold block mb-1">MAX PRICE</span>
            <input
              type="number"
              placeholder="e.g. 20000"
              value={maxPrice}
              onChange={(e) => setMaxPrice(e.target.value === '' ? '' : Number(e.target.value))}
              className="w-full bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-[#3db83a]"
            />
          </div>
        </div>
      </div>

      {/* Safety Message Panel */}
      <div className="bg-[#fff9e6] rounded-xl border border-yellow-100 p-4 flex flex-col gap-2 mt-2">
        <span className="flex items-center gap-1.5 text-[11px] font-extrabold text-[#946100]">
          <ShieldCheck className="w-4 h-4" />
          <span>Safety Trading Tips</span>
        </span>
        <ul className="list-disc pl-3.5 text-[10px] text-gray-600 font-medium leading-relaxed flex flex-col gap-1">
          <li>Never pay in advance, even for delivery.</li>
          <li>Always meet in a secure, public place (e.g. mall, bank).</li>
          <li>Thoroughly inspect the item before buying.</li>
          <li>Pay only after checking that everything works.</li>
        </ul>
      </div>
    </div>
  );
}
