import React, { useState } from 'react';
import { Product, Order, CurrencyCode, SellerKycData } from '../types';
import { formatPrice } from '../lib/currencies';
import { enhanceListingAi } from '../services/aiService';
import { encryptPayoutVaultData } from '../lib/encryption';
import { SellerKycForm } from './SellerKycForm';
import { Store, Plus, Sparkles, Package, Truck, Lock, DollarSign, CheckCircle2, Loader2, ShieldCheck, ShieldAlert, FileText, UserCheck } from 'lucide-react';

interface SellerDashboardProps {
  products: Product[];
  orders: Order[];
  onAddProduct: (p: Product) => void;
  activeCurrency: CurrencyCode;
  kycData: SellerKycData | null;
  onSubmitKyc: (kyc: SellerKycData) => void;
  userEmail: string | null;
}

export const SellerDashboard: React.FC<SellerDashboardProps> = ({
  products,
  orders,
  onAddProduct,
  activeCurrency,
  kycData,
  onSubmitKyc,
  userEmail,
}) => {
  const [activeTab, setActiveTab] = useState<'inventory' | 'kyc'>('inventory');

  // Modal State for Add Product
  const [isAdding, setIsAdding] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Electronics & Computing');
  const [description, setDescription] = useState('');
  const [priceUsd, setPriceUsd] = useState(250);
  const [stock, setStock] = useState(15);
  const [countryOfOrigin, setCountryOfOrigin] = useState('United States');
  const [shippingWeightKg, setShippingWeightKg] = useState(1.5);
  const [imageUrl, setImageUrl] = useState('/src/assets/images/product_quantum_laptop_1792878760441.jpg');

  // AI State
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResultNotice, setAiResultNotice] = useState<string | null>(null);

  // Vendor Payout Account Setup
  const [accountNumber, setAccountNumber] = useState('9928103921');
  const [bankCode, setBankCode] = useState('CHASE_US');
  const [encryptedPayoutVault, setEncryptedPayoutVault] = useState<string | null>(null);

  const isApprovedSeller = kycData?.kycStatus === 'approved';

  // Handle AI Listing Enhancement
  const handleEnhanceWithAi = async () => {
    if (!title.trim()) {
      alert('Please enter a product title first before running AI Enhancement.');
      return;
    }

    setAiLoading(true);
    setAiResultNotice(null);
    try {
      const res = await enhanceListingAi({
        title,
        category,
        description,
        priceUsd,
      });

      setTitle(res.enhancedTitle);
      setDescription(res.enhancedDescription);
      setAiResultNotice(`AI Optimization Complete: Added HS Code (${res.suggestedHsCode}) & Multi-lingual tags.`);
    } catch (e: any) {
      console.error(e);
      alert('AI Enhancement service unavailable.');
    } finally {
      setAiLoading(false);
    }
  };

  // Submit Product Creation
  const handleSubmitProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isApprovedSeller) {
      alert('Selling permissions locked. You must complete KYC Verification and obtain Admin Approval first.');
      return;
    }
    if (!title.trim()) return;

    const newProd: Product = {
      id: `prod-v-${Date.now()}`,
      title,
      description,
      priceUsd: Number(priceUsd),
      category,
      sellerId: 'seller-verified-01',
      sellerName: kycData?.sellerName || 'Global Vault Verified Merchant',
      sellerRating: 5.0,
      stock: Number(stock),
      imageUrl,
      encryptedProductSignature: `SIG_PROD_${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
      countryOfOrigin,
      shippingWeightKg: Number(shippingWeightKg),
      tags: ['VerifiedVendor', category, countryOfOrigin],
      createdAt: new Date().toISOString().split('T')[0],
      isVerifiedVendor: true,
    };

    onAddProduct(newProd);
    setIsAdding(false);
    setTitle('');
    setDescription('');
    setAiResultNotice(null);
  };

  // Encrypt Payout Key
  const handleEncryptVaultKey = async () => {
    const vault = await encryptPayoutVaultData(accountNumber, bankCode);
    setEncryptedPayoutVault(vault);
  };

  // Compute total vendor revenue
  const totalVendorRevenueUsd = orders.reduce((acc, o) => acc + o.totalAmountUsd, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 lg:px-8 py-8 space-y-8">
      {/* Seller Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center font-bold">
            <Store className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-white">Vendor Portal & Inventory Hub</h1>
              {isApprovedSeller ? (
                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" /> VERIFIED MERCHANT
                </span>
              ) : (
                <span className="bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                  <ShieldAlert className="w-3 h-3 text-amber-400" /> KYC REQUIRED
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Manage international inventory, dispatch shipments, and track encrypted payouts
            </p>
          </div>
        </div>

        {/* Tab Switcher & Action */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center p-1 bg-slate-800 rounded-xl border border-slate-700 text-xs">
            <button
              onClick={() => setActiveTab('inventory')}
              className={`px-3 py-1.5 font-bold rounded-lg transition-colors ${
                activeTab === 'inventory' ? 'bg-emerald-500 text-slate-950' : 'text-slate-300 hover:text-white'
              }`}
            >
              Inventory
            </button>
            <button
              onClick={() => setActiveTab('kyc')}
              className={`px-3 py-1.5 font-bold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeTab === 'kyc' ? 'bg-emerald-500 text-slate-950' : 'text-slate-300 hover:text-white'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              Seller KYC Form
            </button>
          </div>

          <button
            onClick={() => {
              if (!isApprovedSeller) {
                setActiveTab('kyc');
                alert('Please submit your Seller KYC Verification details to unlock product listing permissions.');
                return;
              }
              setIsAdding(true);
            }}
            className={`font-bold px-4 py-2.5 rounded-xl transition-all shadow-lg flex items-center gap-2 text-xs shrink-0 ${
              isApprovedSeller
                ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20'
                : 'bg-slate-800 text-slate-400 border border-slate-700 cursor-pointer'
            }`}
          >
            <Plus className="w-4 h-4" />
            {isApprovedSeller ? 'Add New Verified Product' : 'KYC Lock: Complete Verification'}
          </button>
        </div>
      </div>

      {/* Selling Lock Alert Banner if not approved */}
      {!isApprovedSeller && (
        <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-amber-200 text-xs">
          <div className="flex items-center gap-2.5">
            <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <strong className="text-white block font-bold">Selling Permissions Locked by Zero-Trust Governance</strong>
              <span>Government ID & Business KYC verification is required before listing products or accepting payouts.</span>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('kyc')}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs transition-colors shrink-0"
          >
            Open Seller KYC Form
          </button>
        </div>
      )}

      {/* Render Main Content depending on Tab */}
      {activeTab === 'kyc' ? (
        <SellerKycForm
          currentKycData={kycData}
          onSubmitKyc={onSubmitKyc}
          userEmail={userEmail}
        />
      ) : (
        <>
          {/* Vendor Stats Bar */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500 font-medium block">Total Verified Revenue</span>
                <span className="text-2xl font-black text-slate-900 font-mono">
                  {formatPrice(totalVendorRevenueUsd, activeCurrency)}
                </span>
              </div>
              <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500 font-medium block">Active Listings</span>
                <span className="text-2xl font-black text-slate-900 font-mono">{products.length} Items</span>
              </div>
              <div className="w-10 h-10 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center">
                <Package className="w-5 h-5" />
              </div>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500 font-medium block">Carrier Dispatches</span>
                <span className="text-2xl font-black text-slate-900 font-mono">{orders.length} Orders</span>
              </div>
              <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                <Truck className="w-5 h-5" />
              </div>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500 font-medium block">Encrypted Payout Vault</span>
                <span className="text-xs font-bold text-emerald-600 font-mono">
                  {isApprovedSeller ? 'LOCKED & VERIFIED' : 'PENDING KYC'}
                </span>
              </div>
              <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
            </div>
          </div>

          {/* Main Vendor Tables */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left 2 Cols: Product Inventory */}
            <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
              <h2 className="text-base font-bold text-slate-900 flex items-center justify-between">
                <span>Product Inventory ({products.length})</span>
                <span className="text-xs font-normal text-slate-500">256-Bit SHA-256 Signed Listings</span>
              </h2>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-3">Product</th>
                      <th className="py-3 px-3">Category</th>
                      <th className="py-3 px-3">Price ({activeCurrency})</th>
                      <th className="py-3 px-3">Stock</th>
                      <th className="py-3 px-3">HMAC Seal</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {products.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-3 flex items-center gap-2">
                          <img src={p.imageUrl} alt={p.title} className="w-9 h-9 object-cover rounded bg-slate-100" />
                          <div>
                            <span className="font-bold text-slate-900 block truncate max-w-[180px]">{p.title}</span>
                            <span className="text-[10px] text-slate-400">Origin: {p.countryOfOrigin}</span>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-slate-600">{p.category}</td>
                        <td className="py-3 px-3 font-mono font-bold text-slate-900">
                          {formatPrice(p.priceUsd, activeCurrency)}
                        </td>
                        <td className="py-3 px-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${p.stock > 10 ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                            {p.stock} units
                          </span>
                        </td>
                        <td className="py-3 px-3 font-mono text-[10px] text-slate-500 flex items-center gap-1">
                          <Lock className="w-3 h-3 text-emerald-600" />
                          {p.encryptedProductSignature.slice(0, 12)}...
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Right Col: Encrypted Payout Vault Key Setup */}
            <div className="bg-slate-900 text-white rounded-2xl border border-slate-800 p-6 space-y-4">
              <div className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-emerald-400" />
                <h2 className="text-base font-bold text-white">Vendor Payout Vault</h2>
              </div>
              <p className="text-xs text-slate-400">
                Payout account data is encrypted client-side using WebCrypto before storage.
              </p>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Bank Account / SWIFT Code</label>
                  <input
                    type="text"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-mono focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Bank Identifier Code</label>
                  <input
                    type="text"
                    value={bankCode}
                    onChange={(e) => setBankCode(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-mono focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <button
                  onClick={handleEncryptVaultKey}
                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2.5 rounded-lg transition-colors flex items-center justify-center gap-1.5"
                >
                  <ShieldCheck className="w-4 h-4" />
                  Generate Encrypted Vault Key
                </button>

                {encryptedPayoutVault && (
                  <div className="p-3 bg-slate-950 rounded-lg border border-emerald-500/40 text-[11px] font-mono text-emerald-400 break-all space-y-1">
                    <span className="text-[10px] text-slate-400 block uppercase font-bold">Encrypted Token</span>
                    {encryptedPayoutVault}
                  </div>
                )}
              </div>
            </div>
          </div>
        </>
      )}

      {/* Add Product Modal */}
      {isAdding && isApprovedSeller && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-2xl p-6 space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Package className="w-5 h-5 text-emerald-600" />
                List New Marketplace Product
              </h2>
              <button onClick={() => setIsAdding(false)} className="text-slate-400 hover:text-slate-900">
                Esc
              </button>
            </div>

            <form onSubmit={handleSubmitProduct} className="space-y-4 text-xs">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800">Product Title</label>
                  <button
                    type="button"
                    onClick={handleEnhanceWithAi}
                    disabled={aiLoading}
                    className="bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold px-2.5 py-1 rounded flex items-center gap-1 transition-colors"
                  >
                    {aiLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-amber-600" />}
                    AI Product Enhancer
                  </button>
                </div>
                <input
                  type="text"
                  required
                  placeholder="e.g. SolarisGrid M5 Portable Off-Grid Solar Generator 2400W"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2.5 text-slate-900 font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {aiResultNotice && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 text-xs font-medium flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  {aiResultNotice}
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Department / Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2.5 text-slate-900 font-medium focus:outline-none"
                  >
                    <option value="Electronics & Computing">Electronics & Computing</option>
                    <option value="Luxury & Jewelry">Luxury & Jewelry</option>
                    <option value="Solar & Renewable Energy">Solar & Renewable Energy</option>
                    <option value="Heavy Machinery & Tools">Heavy Machinery & Tools</option>
                    <option value="Fashion & Leathercraft">Fashion & Leathercraft</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">Target Price (USD)</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={priceUsd}
                    onChange={(e) => setPriceUsd(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2.5 text-slate-900 font-mono font-bold focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Stock Units</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={stock}
                    onChange={(e) => setStock(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2.5 text-slate-900 font-bold focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">Origin Country</label>
                  <input
                    type="text"
                    required
                    value={countryOfOrigin}
                    onChange={(e) => setCountryOfOrigin(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2.5 text-slate-900 font-medium focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">Weight (Kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={shippingWeightKg}
                    onChange={(e) => setShippingWeightKg(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2.5 text-slate-900 font-medium focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">Description & Specs</label>
                <textarea
                  rows={3}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Detailed product features, international certifications..."
                  className="w-full border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-none"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-6 py-2.5 rounded-lg transition-colors"
                >
                  Sign & Publish Listing
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
