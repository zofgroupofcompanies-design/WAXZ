import React, { useState } from 'react';
import { verifyOrderReceiptSignature } from '../lib/encryption';
import { ShieldCheck, Lock, CheckCircle2, XCircle, Search, Key, Sparkles } from 'lucide-react';

export const ReceiptVerifier: React.FC = () => {
  const [orderId, setOrderId] = useState('ORD-GV-883910');
  const [buyerId, setBuyerId] = useState('buyer_sample_user');
  const [amountUsd, setAmountUsd] = useState('2899.00');
  const [itemCount, setItemCount] = useState('1');
  const [providedSig, setProvidedSig] = useState('');

  const [verificationResult, setVerificationResult] = useState<{
    tested: boolean;
    valid: boolean;
    calculatedSig?: string;
  }>({ tested: false, valid: false });

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!providedSig.trim()) return;

    const isValid = await verifyOrderReceiptSignature(
      providedSig,
      orderId.trim(),
      buyerId.trim(),
      Number(amountUsd),
      Number(itemCount),
      '2026-10-24T12:00:00.000Z'
    );

    setVerificationResult({
      tested: true,
      valid: isValid,
    });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 space-y-8">
      <div className="text-center space-y-2">
        <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-600 border border-emerald-500/30 flex items-center justify-center mx-auto mb-3">
          <ShieldCheck className="w-7 h-7" />
        </div>
        <h1 className="text-2xl font-black text-slate-900">Zero-Knowledge Cryptographic Receipt Verifier</h1>
        <p className="text-sm text-slate-600 max-w-xl mx-auto">
          Verify tamper-proof proof-of-purchase receipts using WebCrypto HMAC SHA-256 signatures on the GlobalVault marketplace ledger.
        </p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl p-6 md:p-8 space-y-6">
        <form onSubmit={handleVerify} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="font-bold text-slate-800 block mb-1">Order Reference ID</label>
              <input
                type="text"
                required
                value={orderId}
                onChange={(e) => setOrderId(e.target.value)}
                className="w-full border border-slate-200 rounded-lg p-2.5 font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="font-bold text-slate-800 block mb-1">Buyer User Identifier</label>
              <input
                type="text"
                required
                value={buyerId}
                onChange={(e) => setBuyerId(e.target.value)}
                className="w-full border border-slate-200 rounded-lg p-2.5 font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="font-bold text-slate-800 block mb-1">Order Total Amount (USD)</label>
              <input
                type="number"
                step="0.01"
                required
                value={amountUsd}
                onChange={(e) => setAmountUsd(e.target.value)}
                className="w-full border border-slate-200 rounded-lg p-2.5 font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="font-bold text-slate-800 block mb-1">Total Quantity of Items</label>
              <input
                type="number"
                required
                value={itemCount}
                onChange={(e) => setItemCount(e.target.value)}
                className="w-full border border-slate-200 rounded-lg p-2.5 font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="font-bold text-slate-800 block mb-1">
              Provided HMAC SHA-256 Receipt Signature (From Certificate or Order History)
            </label>
            <input
              type="text"
              required
              placeholder="e.g. SIG_GV_58A92B104F98E110AACC..."
              value={providedSig}
              onChange={(e) => setProvidedSig(e.target.value)}
              className="w-full border border-slate-200 rounded-lg p-3 font-mono text-xs text-slate-900 bg-slate-50 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-slate-900 hover:bg-emerald-600 text-white font-bold py-3 rounded-xl transition-colors shadow-md flex items-center justify-center gap-2 text-sm"
          >
            <Lock className="w-4 h-4 text-emerald-400" />
            Verify Cryptographic Receipt Authenticity
          </button>
        </form>

        {/* Verification Outcome */}
        {verificationResult.tested && (
          <div
            className={`p-4 rounded-xl border flex items-start gap-3 transition-all ${
              verificationResult.valid
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-rose-50 border-rose-200 text-rose-900'
            }`}
          >
            {verificationResult.valid ? (
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <XCircle className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
            )}
            <div>
              <h3 className="font-bold text-sm">
                {verificationResult.valid
                  ? 'SIGNATURE VALID & AUTHENTICATED'
                  : 'SIGNATURE MISMATCH OR MODIFIED RECORD'}
              </h3>
              <p className="text-xs mt-1 leading-relaxed">
                {verificationResult.valid
                  ? 'This receipt has been cryptographically validated against the GlobalVault HMAC SHA-256 key vault. The transaction amount, order contents, and buyer metadata match.'
                  : 'Warning: The provided HMAC signature does not match the recalculated hash. The receipt parameters may have been altered or tampered with.'}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
