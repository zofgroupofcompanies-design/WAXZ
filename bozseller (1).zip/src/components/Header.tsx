import React, { useState } from 'react';
import { Search, MapPin, MessageSquare, User, Heart, PlusCircle, Sparkles, ChevronDown, Compass, AlertCircle, CheckCircle, Loader2, Shield, Coins, Trophy } from 'lucide-react';
import { COUNTRIES, COUNTRIES_CONFIG, CURRENT_USER } from '../data/mockData';
import { CurrencyCode, CURRENCIES } from '../utils/currency';

import { AuthUser } from '../types';

interface HeaderProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCountry: string;
  setSelectedCountry: (country: string) => void;
  selectedRegion: string;
  setSelectedRegion: (region: string) => void;
  selectedCurrency: CurrencyCode;
  setSelectedCurrency: (currency: CurrencyCode) => void;
  onPostAdClick: () => void;
  onDashboardClick: () => void;
  onSavedClick?: () => void;
  onTopSellersClick?: () => void;
  onChatsClick: () => void;
  onLogoClick: () => void;
  favoritesCount: number;
  unreadChatsCount: number;
  onAdminClick?: () => void;
  isAdminMode?: boolean;
  currentUser?: AuthUser | null;
  onAuthClick?: () => void;
}

export default function Header({
  searchQuery,
  setSearchQuery,
  selectedCountry,
  setSelectedCountry,
  selectedRegion,
  setSelectedRegion,
  selectedCurrency,
  setSelectedCurrency,
  onPostAdClick,
  onDashboardClick,
  onSavedClick,
  onTopSellersClick,
  onChatsClick,
  onLogoClick,
  favoritesCount,
  unreadChatsCount,
  onAdminClick,
  isAdminMode = false,
  currentUser = null,
  onAuthClick
}: HeaderProps) {
  const [showRegionDropdown, setShowRegionDropdown] = useState(false);
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);
  const [showCurrencyDropdown, setShowCurrencyDropdown] = useState(false);
  const [localSearch, setLocalSearch] = useState(searchQuery);

  // Geolocation State
  const [isDetecting, setIsDetecting] = useState(false);
  const [detectionError, setDetectionError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const simulateDetection = (country: string, region: string, city: string) => {
    setIsDetecting(true);
    setDetectionError(null);
    setSuccessMessage(null);
    setTimeout(() => {
      setSelectedCountry(country);
      setSelectedRegion(region);
      setSuccessMessage(`Simulated location detection: switched to ${city}, ${country}!`);
      setIsDetecting(false);
      setShowRegionDropdown(false);
      setTimeout(() => setSuccessMessage(null), 5000);
    }, 800);
  };

  const detectLocation = () => {
    if (!navigator.geolocation) {
      setDetectionError('Geolocation is not supported by your browser');
      return;
    }

    setIsDetecting(true);
    setDetectionError(null);
    setSuccessMessage(null);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const { latitude, longitude } = position.coords;
          const res = await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`);
          if (!res.ok) throw new Error('Failed to resolve geocoding');
          const data = await res.json();
          
          const countryName = data.countryName;
          const countryCode = data.countryCode;
          const subdivision = data.principalSubdivision || '';
          const city = data.city || data.locality || '';
          
          let matchedCountry = 'Ghana';
          if (countryName && COUNTRIES_CONFIG[countryName]) {
            matchedCountry = countryName;
          } else if (countryCode) {
            const codeMap: Record<string, string> = {
              'GH': 'Ghana',
              'NG': 'Nigeria',
              'TG': 'Togo'
            };
            if (codeMap[countryCode.toUpperCase()]) {
              matchedCountry = codeMap[countryCode.toUpperCase()];
            }
          }
          
          const regions = COUNTRIES_CONFIG[matchedCountry]?.regions || {};
          const regionKeys = Object.keys(regions);
          let matchedRegion = `All ${matchedCountry}`;
          
          const textToMatch = `${subdivision} ${city}`.toLowerCase();
          for (const reg of regionKeys) {
            if (textToMatch.includes(reg.toLowerCase()) || reg.toLowerCase().includes(city.toLowerCase())) {
              matchedRegion = reg;
              break;
            }
          }
          
          if (matchedRegion === `All ${matchedCountry}`) {
            for (const reg of regionKeys) {
              const neighborhoods = regions[reg] || [];
              if (neighborhoods.some(n => n.toLowerCase().includes(city.toLowerCase()) || city.toLowerCase().includes(n.toLowerCase()))) {
                matchedRegion = reg;
                break;
              }
            }
          }
          
          setSelectedCountry(matchedCountry);
          setSelectedRegion(matchedRegion);
          setSuccessMessage(`Location auto-detected: ${city || matchedRegion}, ${matchedCountry}!`);
          setIsDetecting(false);
          setShowRegionDropdown(false);
          setTimeout(() => setSuccessMessage(null), 5000);
        } catch (err) {
          console.error(err);
          setDetectionError('Iframe sandbox or API connection blocked. Select below to simulate:');
          setIsDetecting(false);
        }
      },
      (err) => {
        console.error(err);
        setDetectionError('Permission denied or Iframe sandbox constraint. Select below to simulate:');
        setIsDetecting(false);
      },
      { timeout: 6000 }
    );
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchQuery(localSearch);
  };

  const handleRegionSelect = (region: string) => {
    setSelectedRegion(region);
    setShowRegionDropdown(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#3e3023] text-white shadow-md">
      {/* Geolocation Success Message Alert/Toast */}
      {successMessage && (
        <div className="bg-[#b08865] text-white px-6 py-2 text-xs font-bold flex items-center justify-between shadow-md transition-all duration-300">
          <span className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-white shrink-0 animate-bounce" />
            <span>{successMessage}</span>
          </span>
          <button onClick={() => setSuccessMessage(null)} className="text-white/80 hover:text-white font-black text-sm p-1 ml-4 cursor-pointer">✕</button>
        </div>
      )}

      {/* Top Banner - Mini Safety Tip */}
      <div className="hidden md:flex justify-between items-center bg-[#291f17] px-6 py-1.5 text-xs text-green-200">
        <span className="flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-[#f5a623]" />
          Gemini AI Ad Assistant is active! Get instant pricing and sales copywriting when posting.
        </span>
        <div className="flex gap-4 items-center">
          <button
            type="button"
            onClick={onTopSellersClick}
            className="hover:underline cursor-pointer flex items-center gap-1 font-extrabold text-yellow-300 hover:text-yellow-200"
          >
            <Trophy className="w-3.5 h-3.5 text-yellow-400 animate-pulse" />
            <span>Top Sellers</span>
          </button>
          <span className="hover:underline cursor-pointer">Safety Tips</span>
          
          <button
            type="button"
            onClick={detectLocation}
            className={`flex items-center gap-1.5 hover:text-white transition cursor-pointer text-yellow-300 hover:text-yellow-200 font-bold ${isDetecting ? 'animate-pulse' : ''}`}
            disabled={isDetecting}
          >
            <Compass className={`w-3.5 h-3.5 ${isDetecting ? 'animate-spin text-yellow-300' : ''}`} />
            <span>{isDetecting ? 'Detecting city...' : 'Detect City'}</span>
          </button>

          <div className="flex gap-2 items-center border-l border-green-800 pl-4 relative">
            {/* Folded Country Selector Dropdown */}
            <button
              type="button"
              onClick={() => setShowCountryDropdown(!showCountryDropdown)}
              className="flex items-center gap-1.5 bg-[#483829] hover:bg-[#574432] text-yellow-300 font-bold px-2.5 py-1 rounded text-xs transition cursor-pointer border border-amber-500/30"
            >
              <span>{COUNTRIES_CONFIG[selectedCountry]?.flag || '🌍'}</span>
              <span>{selectedCountry}</span>
              <ChevronDown className="w-3 h-3 text-yellow-300/80" />
            </button>

            {showCountryDropdown && (
              <div className="absolute right-0 top-full mt-1.5 w-64 bg-white rounded-xl shadow-2xl border border-gray-200 py-2 z-50 text-gray-800 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3 py-1 text-[10px] font-extrabold uppercase text-gray-400 tracking-wider border-b border-gray-100 flex items-center justify-between">
                  <span>Folded Global Markets</span>
                  <span className="text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded font-black">14 Countries</span>
                </div>

                <div className="max-h-72 overflow-y-auto divide-y divide-gray-100">
                  {/* Stage 1 */}
                  <div className="p-2">
                    <span className="text-[10px] font-black text-emerald-800 uppercase tracking-wider block mb-1 px-1">
                      Stage 1 — West Africa
                    </span>
                    {['Ghana', 'Nigeria', 'Togo', "Côte d'Ivoire"].map(ctry => (
                      <button
                        key={ctry}
                        type="button"
                        onClick={() => {
                          setSelectedCountry(ctry);
                          setSelectedRegion(`All ${ctry}`);
                          setShowCountryDropdown(false);
                        }}
                        className={`w-full text-left px-2.5 py-1.5 text-xs rounded-lg flex items-center justify-between hover:bg-emerald-50 cursor-pointer font-semibold ${selectedCountry === ctry ? 'bg-emerald-100/70 text-emerald-950 font-extrabold' : 'text-gray-700'}`}
                      >
                        <span className="flex items-center gap-2">
                          <span>{COUNTRIES_CONFIG[ctry]?.flag || '🌍'}</span>
                          <span>{ctry}</span>
                        </span>
                        <span className="text-[9px] text-gray-400 font-mono">{COUNTRIES_CONFIG[ctry]?.currency}</span>
                      </button>
                    ))}
                  </div>

                  {/* Stage 2 */}
                  <div className="p-2">
                    <span className="text-[10px] font-black text-blue-800 uppercase tracking-wider block mb-1 px-1">
                      Stage 2 — Major International
                    </span>
                    {['United States', 'United Kingdom', 'Canada', 'Australia'].map(ctry => (
                      <button
                        key={ctry}
                        type="button"
                        onClick={() => {
                          setSelectedCountry(ctry);
                          setSelectedRegion(`All ${ctry}`);
                          setShowCountryDropdown(false);
                        }}
                        className={`w-full text-left px-2.5 py-1.5 text-xs rounded-lg flex items-center justify-between hover:bg-blue-50 cursor-pointer font-semibold ${selectedCountry === ctry ? 'bg-blue-100/70 text-blue-950 font-extrabold' : 'text-gray-700'}`}
                      >
                        <span className="flex items-center gap-2">
                          <span>{COUNTRIES_CONFIG[ctry]?.flag || '🌍'}</span>
                          <span>{ctry}</span>
                        </span>
                        <span className="text-[9px] text-gray-400 font-mono">{COUNTRIES_CONFIG[ctry]?.currency}</span>
                      </button>
                    ))}
                  </div>

                  {/* Stage 3 */}
                  <div className="p-2">
                    <span className="text-[10px] font-black text-purple-800 uppercase tracking-wider block mb-1 px-1">
                      Stage 3 — Asia & Europe
                    </span>
                    {['China', 'India', 'Japan', 'Germany', 'France', 'South Korea'].map(ctry => (
                      <button
                        key={ctry}
                        type="button"
                        onClick={() => {
                          setSelectedCountry(ctry);
                          setSelectedRegion(`All ${ctry}`);
                          setShowCountryDropdown(false);
                        }}
                        className={`w-full text-left px-2.5 py-1.5 text-xs rounded-lg flex items-center justify-between hover:bg-purple-50 cursor-pointer font-semibold ${selectedCountry === ctry ? 'bg-purple-100/70 text-purple-950 font-extrabold' : 'text-gray-700'}`}
                      >
                        <span className="flex items-center gap-2">
                          <span>{COUNTRIES_CONFIG[ctry]?.flag || '🌍'}</span>
                          <span>{ctry}</span>
                        </span>
                        <span className="text-[9px] text-gray-400 font-mono">{COUNTRIES_CONFIG[ctry]?.currency}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Currency Switcher in Top Bar */}
          <div className="relative border-l border-green-800 pl-4">
            <button
              type="button"
              onClick={() => setShowCurrencyDropdown(!showCurrencyDropdown)}
              className="flex items-center gap-1.5 bg-[#483829] hover:bg-[#574432] text-yellow-300 hover:text-yellow-200 px-2.5 py-1 rounded text-xs font-bold transition cursor-pointer border border-amber-500/30"
              title="Change Currency"
            >
              <Coins className="w-3.5 h-3.5 text-yellow-400" />
              <span>{CURRENCIES[selectedCurrency].flag} {CURRENCIES[selectedCurrency].symbol}</span>
              <ChevronDown className="w-3 h-3 text-yellow-300/80" />
            </button>

            {showCurrencyDropdown && (
              <div className="absolute right-0 top-full mt-1.5 w-48 bg-white rounded-lg shadow-xl border border-gray-200 py-1 z-50 text-gray-800 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3 py-1.5 border-b border-gray-100 text-[10px] font-extrabold uppercase text-gray-400 tracking-wider">
                  Select Display Currency
                </div>
                {(Object.keys(CURRENCIES) as CurrencyCode[]).map((currKey) => {
                  const curr = CURRENCIES[currKey];
                  const isSelected = selectedCurrency === currKey;
                  return (
                    <button
                      key={currKey}
                      type="button"
                      onClick={() => {
                        setSelectedCurrency(currKey);
                        setShowCurrencyDropdown(false);
                      }}
                      className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between hover:bg-amber-50 cursor-pointer font-bold transition ${
                        isSelected ? 'bg-amber-50/80 text-[#3e3023]' : 'text-gray-700'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span>{curr.flag}</span>
                        <span>{curr.name}</span>
                      </span>
                      <span className="text-[11px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded font-black">
                        {curr.symbol}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Header Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div 
          onClick={onLogoClick} 
          className="flex items-center gap-2 cursor-pointer select-none shrink-0"
        >
          <div className="bg-[#b08865] text-white px-3 py-1.5 rounded-lg font-black tracking-tight text-xl sm:text-2xl flex items-center shadow-inner">
            <span>Datazone</span>
          </div>
        </div>

        {/* Search Bar Form */}
        <form 
          onSubmit={handleSearchSubmit} 
          className="hidden md:flex flex-1 max-w-2xl bg-white rounded-lg overflow-hidden border border-green-700 shadow-sm"
        >
          {/* Country Selector inside Search Bar */}
          <div className="relative border-r border-gray-200 shrink-0">
            <button
              type="button"
              onClick={() => setShowCountryDropdown(!showCountryDropdown)}
              className="flex items-center gap-1.5 px-3 py-2 text-gray-700 hover:bg-gray-50 text-sm h-full font-bold transition cursor-pointer"
            >
              <span>{COUNTRIES_CONFIG[selectedCountry]?.flag}</span>
              <span className="max-w-[80px] truncate">{selectedCountry}</span>
              <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
            </button>

            {showCountryDropdown && (
              <div className="absolute top-full left-0 mt-1 w-44 bg-white rounded-md shadow-lg border border-gray-200 py-1 z-50 text-gray-800">
                {COUNTRIES.map(ctry => (
                  <button
                    key={ctry}
                    type="button"
                    onClick={() => {
                      setSelectedCountry(ctry);
                      setSelectedRegion(`All ${ctry}`);
                      setShowCountryDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2 text-sm hover:bg-gray-100 flex items-center gap-2 font-semibold text-gray-700 cursor-pointer"
                  >
                    <span>{COUNTRIES_CONFIG[ctry].flag}</span>
                    <span>{ctry}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Location Selector */}
          <div className="relative border-r border-gray-200 shrink-0">
            <button
              type="button"
              onClick={() => setShowRegionDropdown(!showRegionDropdown)}
              className="flex items-center gap-1.5 px-3 py-2 text-gray-700 hover:bg-gray-50 text-sm h-full font-medium transition cursor-pointer"
            >
              <MapPin className="w-4 h-4 text-[#b08865]" />
              <span className="max-w-[100px] truncate">{selectedRegion || `All ${selectedCountry}`}</span>
              <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
            </button>

            {showRegionDropdown && (
              <div className="absolute top-full left-0 mt-1 w-64 bg-white rounded-md shadow-lg border border-gray-200 py-1 z-50 text-gray-800 max-h-[450px] overflow-y-auto">
                {/* Auto Detect Button */}
                <button
                  type="button"
                  onClick={detectLocation}
                  className="w-full text-left px-4 py-2.5 text-xs hover:bg-amber-50 font-bold text-amber-700 bg-amber-50/30 flex items-center gap-2 border-b border-gray-100 transition duration-150 cursor-pointer"
                  disabled={isDetecting}
                >
                  {isDetecting ? (
                    <Loader2 className="w-4 h-4 text-amber-600 animate-spin shrink-0" />
                  ) : (
                    <Compass className="w-4 h-4 text-amber-500 shrink-0 animate-pulse" />
                  )}
                  <span>{isDetecting ? 'Detecting local area...' : '📍 Auto-detect My City'}</span>
                </button>

                {/* Geolocation Fallback/Simulation Section if permission blocked or error */}
                {detectionError && (
                  <div className="px-4 py-2 bg-red-50 border-b border-gray-100 text-[11px] text-red-600 font-medium">
                    <p className="font-bold flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0 animate-pulse" />
                      Unable to locate
                    </p>
                    <p className="text-gray-500 mt-0.5">Iframe constraints block standard GPS. Simulate with a city below:</p>
                    <div className="grid grid-cols-3 gap-1 mt-1.5">
                      <button
                        type="button"
                        onClick={() => simulateDetection('Ghana', 'Greater Accra', 'Accra')}
                        className="bg-white border border-gray-200 hover:border-[#b08865] rounded-md py-1 text-[10px] font-bold text-gray-700 hover:text-[#b08865] cursor-pointer text-center transition"
                      >
                        🇬🇭 Accra
                      </button>
                      <button
                        type="button"
                        onClick={() => simulateDetection('Nigeria', 'Lagos', 'Lagos')}
                        className="bg-white border border-gray-200 hover:border-[#b08865] rounded-md py-1 text-[10px] font-bold text-gray-700 hover:text-[#b08865] cursor-pointer text-center transition"
                      >
                        🇳🇬 Lagos
                      </button>
                      <button
                        type="button"
                        onClick={() => simulateDetection('Togo', 'Maritime (Lomé)', 'Lomé')}
                        className="bg-white border border-gray-200 hover:border-[#b08865] rounded-md py-1 text-[10px] font-bold text-gray-700 hover:text-[#b08865] cursor-pointer text-center transition"
                      >
                        🇹🇬 Lomé
                      </button>
                    </div>
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => handleRegionSelect(`All ${selectedCountry}`)}
                  className="w-full text-left px-4 py-2 text-sm hover:bg-gray-100 font-semibold text-[#b08865] cursor-pointer"
                >
                  All {selectedCountry}
                </button>
                {Object.keys(COUNTRIES_CONFIG[selectedCountry]?.regions || {}).map(reg => (
                  <button
                    key={reg}
                    type="button"
                    onClick={() => handleRegionSelect(reg)}
                    className="w-full text-left px-4 py-2 text-sm hover:bg-gray-100 cursor-pointer"
                  >
                    {reg}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Keyword Input */}
          <div className="flex-1 flex items-center px-3">
            <input
              type="text"
              placeholder="I am looking for..."
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              className="w-full bg-transparent border-none text-gray-800 focus:outline-none focus:ring-0 text-sm placeholder-gray-400"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="bg-[#b08865] hover:bg-[#937153] text-white px-5 py-2 text-sm font-semibold transition flex items-center justify-center cursor-pointer gap-1"
          >
            <Search className="w-4 h-4" />
            <span>Search</span>
          </button>
        </form>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-4 shrink-0">
          {/* Saved / Favorites (Heart) */}
          <button 
            onClick={onSavedClick || onDashboardClick}
            className="relative p-2 text-green-100 hover:text-white hover:bg-[#483829] rounded-full transition cursor-pointer"
            title="Saved Ads"
          >
            <Heart className="w-5 h-5" />
            {favoritesCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-yellow-400 text-[#3e3023] text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {favoritesCount}
              </span>
            )}
          </button>

          {/* Chats */}
          <button 
            onClick={onChatsClick}
            className="relative p-2 text-green-100 hover:text-white hover:bg-[#483829] rounded-full transition cursor-pointer"
            title="Messages"
          >
            <MessageSquare className="w-5 h-5" />
            {unreadChatsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                {unreadChatsCount}
              </span>
            )}
          </button>



          {/* User Profile / Security Auth Button */}
          <button 
            onClick={onAuthClick || onDashboardClick}
            className="flex items-center gap-1.5 p-1.5 px-2.5 bg-[#483829] hover:bg-[#574432] rounded-lg transition text-xs font-bold cursor-pointer text-amber-200 border border-amber-500/20"
            title="Account Security & Authentication"
          >
            <Shield className="w-4 h-4 text-yellow-400 shrink-0" />
            <span className="hidden sm:inline truncate max-w-[90px]">
              {currentUser ? ((currentUser.name || (currentUser as any).displayName || currentUser.email || 'User').split(' ')[0]) : 'Sign In'}
            </span>
            {currentUser && (
              <span className={`text-[9px] font-black px-1.5 py-0.5 rounded uppercase ${
                currentUser.role === 'admin' 
                  ? 'bg-purple-600 text-white' 
                  : currentUser.role === 'seller'
                  ? 'bg-amber-600 text-white'
                  : 'bg-blue-600 text-white'
              }`}>
                {currentUser.role}
              </span>
            )}
          </button>

          {/* "SELL" Ad Posting Button */}
          <button
            onClick={onPostAdClick}
            className="bg-[#e65c00] hover:bg-[#ff6d0c] text-white font-bold text-sm px-4 py-2 rounded-full shadow-md flex items-center gap-1.5 transition transform active:scale-95 cursor-pointer hover:shadow-lg"
          >
            <PlusCircle className="w-4.5 h-4.5" />
            <span>SELL</span>
          </button>
        </div>
      </div>

      {/* Mobile Country & Currency Selector Banner */}
      <div className="flex flex-col gap-1.5 md:hidden bg-[#2d2219] px-4 py-2 border-t border-green-800 text-xs">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-1.5">
            <span className="text-green-200 font-bold">Country:</span>
            <div className="flex gap-2">
              {COUNTRIES.map(ctry => (
                <button
                  key={ctry}
                  onClick={() => {
                    setSelectedCountry(ctry);
                    setSelectedRegion(`All ${ctry}`);
                  }}
                  className={`flex items-center gap-0.5 transition cursor-pointer ${selectedCountry === ctry ? 'font-black text-yellow-300' : 'text-green-300'}`}
                >
                  <span>{COUNTRIES_CONFIG[ctry].flag}</span>
                  <span>{ctry}</span>
                </button>
              ))}
            </div>
          </div>
          
          <button
            type="button"
            onClick={detectLocation}
            className={`flex items-center gap-1 text-yellow-300 hover:text-yellow-200 font-bold transition cursor-pointer text-[10px] bg-[#291f17] px-2 py-1 rounded border border-green-800 ${isDetecting ? 'animate-pulse' : ''}`}
            disabled={isDetecting}
          >
            {isDetecting ? (
              <Loader2 className="w-3 h-3 text-yellow-300 animate-spin" />
            ) : (
              <Compass className="w-3 h-3 text-yellow-300 animate-pulse" />
            )}
            <span>{isDetecting ? 'Detecting...' : 'Detect'}</span>
          </button>
        </div>

        {/* Mobile Currency Bar */}
        <div className="flex items-center justify-between pt-1 border-t border-green-900/60">
          <span className="text-amber-200/90 text-[10px] font-extrabold uppercase flex items-center gap-1">
            <Coins className="w-3 h-3 text-yellow-400" />
            Currency:
          </span>
          <div className="flex gap-1.5">
            {(Object.keys(CURRENCIES) as CurrencyCode[]).map((currKey) => {
              const curr = CURRENCIES[currKey];
              const isSelected = selectedCurrency === currKey;
              return (
                <button
                  key={currKey}
                  type="button"
                  onClick={() => setSelectedCurrency(currKey)}
                  className={`px-2 py-0.5 rounded text-[10px] font-black transition cursor-pointer flex items-center gap-1 ${
                    isSelected
                      ? 'bg-yellow-400 text-green-950 shadow-xs'
                      : 'bg-[#3e3023] text-gray-300 hover:text-white border border-green-800/60'
                  }`}
                >
                  <span>{curr.flag}</span>
                  <span>{curr.symbol}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Mobile Search Bar & Location */}
      <div className="block md:hidden bg-[#291f17] px-4 py-2 border-t border-green-800">
        <form onSubmit={handleSearchSubmit} className="flex gap-2 items-center">
          <div className="flex-1 bg-white rounded-md flex items-center overflow-hidden px-2 py-1 shadow-inner">
            <Search className="w-4 h-4 text-gray-400 mr-1.5" />
            <input
              type="text"
              placeholder="Search datazone4..."
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              className="w-full bg-transparent border-none text-gray-800 text-xs focus:outline-none"
            />
          </div>
          
          {/* Mini Mobile Location Button */}
          <button
            type="button"
            onClick={() => setShowRegionDropdown(!showRegionDropdown)}
            className="bg-[#4a3a2c] text-white rounded-md p-1.5 flex items-center justify-center text-xs gap-1 max-w-[100px] truncate cursor-pointer"
          >
            <MapPin className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
            <span>{selectedRegion === `All ${selectedCountry}` ? COUNTRIES_CONFIG[selectedCountry]?.flag : selectedRegion}</span>
          </button>
        </form>
        
        {showRegionDropdown && (
          <div className="absolute left-4 right-4 mt-2 bg-white rounded-md shadow-xl border border-gray-200 py-1 z-50 text-gray-800 max-h-64 overflow-y-auto">
            {/* Mobile Auto Detect Button */}
            <button
              type="button"
              onClick={detectLocation}
              className="w-full text-left px-4 py-2.5 text-xs hover:bg-amber-50 font-bold text-amber-700 bg-amber-50/30 flex items-center gap-2 border-b border-gray-100 transition duration-150 cursor-pointer"
              disabled={isDetecting}
            >
              {isDetecting ? (
                <Loader2 className="w-4 h-4 text-amber-600 animate-spin shrink-0" />
              ) : (
                <Compass className="w-4 h-4 text-amber-500 shrink-0 animate-pulse" />
              )}
              <span>{isDetecting ? 'Detecting local area...' : '📍 Auto-detect My City'}</span>
            </button>

            {/* Mobile Geolocation Fallback/Simulation Section if permission blocked or error */}
            {detectionError && (
              <div className="px-4 py-2 bg-red-50 border-b border-gray-100 text-[10px] text-red-600 font-medium">
                <p className="font-bold flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  Unable to locate
                </p>
                <p className="text-gray-500 mt-0.5">Iframe constraints block standard GPS. Simulate with a city below:</p>
                <div className="grid grid-cols-3 gap-1 mt-1.5">
                  <button
                    type="button"
                    onClick={() => simulateDetection('Ghana', 'Greater Accra', 'Accra')}
                    className="bg-white border border-gray-200 hover:border-[#b08865] rounded py-1 text-[9px] font-bold text-gray-700 hover:text-[#b08865] cursor-pointer text-center transition"
                  >
                    🇬🇭 Accra
                  </button>
                  <button
                    type="button"
                    onClick={() => simulateDetection('Nigeria', 'Lagos', 'Lagos')}
                    className="bg-white border border-gray-200 hover:border-[#b08865] rounded py-1 text-[9px] font-bold text-gray-700 hover:text-[#b08865] cursor-pointer text-center transition"
                  >
                    🇳🇬 Lagos
                  </button>
                  <button
                    type="button"
                    onClick={() => simulateDetection('Togo', 'Maritime (Lomé)', 'Lomé')}
                    className="bg-white border border-gray-200 hover:border-[#b08865] rounded py-1 text-[9px] font-bold text-gray-700 hover:text-[#b08865] cursor-pointer text-center transition"
                  >
                    🇹🇬 Lomé
                  </button>
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={() => handleRegionSelect(`All ${selectedCountry}`)}
              className="w-full text-left px-4 py-2 text-xs hover:bg-gray-100 font-semibold text-[#b08865] cursor-pointer"
            >
              All {selectedCountry}
            </button>
            {Object.keys(COUNTRIES_CONFIG[selectedCountry]?.regions || {}).map(reg => (
              <button
                key={reg}
                type="button"
                onClick={() => handleRegionSelect(reg)}
                className="w-full text-left px-4 py-2 text-xs hover:bg-gray-100 cursor-pointer"
              >
                {reg}
              </button>
            ))}
          </div>
        )}
      </div>
    </header>
  );
}
