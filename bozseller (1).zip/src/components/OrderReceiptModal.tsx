import React from 'react';
import { Order, CurrencyCode } from '../types';
import { formatPrice } from '../lib/currencies';
import { getTrackingTimeline } from '../lib/carriers';
import { X, Lock, CheckCircle2, QrCode, Download, ExternalLink, ShieldCheck, Truck } from 'lucide-react';

interface OrderReceiptModalProps {
  order: Order;
  activeCurrency: CurrencyCode;
  onClose: () => void;
}

export const OrderReceiptModal: React.FC<OrderReceiptModalProps> = ({
  order,
  activeCurrency,
  onClose,
}) => {
  const timeline = getTrackingTimeline((order.shippingCarrier || 'standard') as any, order.trackingNumber || '', order.orderStatus || 'processing');

  const handleDownloadProof = () => {
    const proofText = `=== GLOBALVAULT ENCRYPTED MARKETPLACE RECEIPT ===
Order ID: ${order.id}
Buyer Email: ${order.buyerEmail}
Timestamp: ${order.createdAt}
Payment Gateway: ${order.paymentMethod.toUpperCase()} (Status: ${order.paymentStatus})
Carrier: ${order.carrierName}
Tracking #: ${order.trackingNumber}
Total Paid: ${order.currency} $${order.totalAmountUsd.toFixed(2)}

=== CRYPTOGRAPHIC AUTHENTICITY SEAL ===
HMAC SHA-256 Signature: ${order.encryptedReceiptHash}
Security Vault Key: ${order.encryptedSecurityKey}
Status: VERIFIED UNTAMPERED PROOF OF PURCHASE
=================================================`;

    const blob = new Blob([proofText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `GlobalVault_Receipt_${order.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8 relative flex flex-col">
        {/* Receipt Header Banner */}
        <div className="p-6 bg-slate-900 text-white flex flex-col items-center justify-center text-center relative border-b border-slate-800">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-2 border border-emerald-500/40">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-bold text-white">Order Confirmed & Encrypted</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Cryptographic proof of purchase locked in global ledger
          </p>
        </div>

        {/* Receipt Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Order & Carrier Summary Box */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Order Reference</span>
              <span className="font-bold text-slate-900 font-mono text-sm">{order.id}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Carrier & Tracking</span>
              <span className="font-bold text-emerald-600 font-mono flex items-center gap-1">
                <Truck className="w-3.5 h-3.5" />
                {order.trackingNumber}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Payment Gateway</span>
              <span className="font-medium text-slate-800">{order.paymentMethod.toUpperCase()} ({order.paymentStatus})</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Amount Paid</span>
              <span className="font-black text-slate-900 font-mono text-sm">
                {formatPrice(order.totalAmountUsd, activeCurrency)}
              </span>
            </div>
          </div>

          {/* Purchased Items */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-800 block">Purchased Items ({order.items.length})</span>
            <div className="space-y-2">
              {order.items.map((it) => (
                <div key={it.product.id} className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <img src={it.product.imageUrl} alt={it.product.title} className="w-10 h-10 object-cover rounded bg-slate-200 shrink-0" />
                    <div>
                      <span className="font-bold text-slate-900 block truncate max-w-[220px]">{it.product.title}</span>
                      <span className="text-[10px] text-slate-400">Qty: {it.quantity} · Vendor: {it.product.sellerName}</span>
                    </div>
                  </div>
                  <span className="font-bold font-mono text-slate-900">
                    {formatPrice(it.product.priceUsd * it.quantity, activeCurrency)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Cryptographic Signature Vault Seal */}
          <div className="p-4 bg-slate-900 text-slate-300 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" /> Cryptographic HMAC Signature
              </span>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30">
                TAMPER-PROOF SEALED
              </span>
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 font-mono text-xs text-emerald-400 break-all leading-relaxed">
              {order.encryptedReceiptHash}
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <QrCode className="w-3.5 h-3.5 text-slate-300" /> Digital Verification Code
              </span>
              <span className="font-mono text-white">{order.encryptedSecurityKey}</span>
            </div>
          </div>

          {/* Live Carrier Timeline */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-800 block">Live Carrier Logistics Timeline</span>
            <div className="space-y-2 relative pl-4 border-l-2 border-slate-200 ml-2">
              {timeline.map((step) => (
                <div key={step.step} className="relative text-xs">
                  <div className={`absolute -left-[21px] top-0.5 w-3 h-3 rounded-full border-2 ${step.done ? 'bg-emerald-500 border-emerald-500' : 'bg-white border-slate-300'}`} />
                  <div className="font-bold text-slate-900">{step.title}</div>
                  <div className="text-[10px] text-slate-500">{step.location} · {step.time}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Receipt Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            onClick={handleDownloadProof}
            className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2.5 rounded-lg flex items-center gap-2 transition-colors"
          >
            <Download className="w-4 h-4" />
            Download Digital Proof Certificate
          </button>
          <button
            onClick={onClose}
            className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold px-5 py-2.5 rounded-lg transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
