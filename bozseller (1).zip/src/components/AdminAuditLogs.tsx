import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, Search, Filter, RefreshCw, FileText, Download, Plus, 
  Trash2, UserCheck, Settings, Lock, AlertTriangle, CheckCircle2, 
  Clock, Eye, Globe, ChevronDown, ChevronUp, Database, Sparkles, X, User
} from 'lucide-react';
import { supabase } from '../lib/supabaseClient';

export interface AuditLogEntry {
  id: string;
  created_at: string;
  admin_email: string;
  action_type: 'user_approval' | 'seller_kyc_approval' | 'seller_kyc_rejection' | 'listing_deletion' | 'setting_update' | 'security_event' | 'escrow_release' | 'manual_action';
  target_resource: string;
  target_id?: string;
  description: string;
  metadata?: Record<string, any>;
  ip_address?: string;
  status: 'SUCCESS' | 'WARNING' | 'FAILED';
}

const INITIAL_MOCK_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'log-1001',
    created_at: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
    admin_email: 'zofgroupofcompanies@gmail.com',
    action_type: 'seller_kyc_approval',
    target_resource: 'Seller Account: Kofi Ofori Motors & Tech',
    target_id: 'kyc-gh-9482',
    description: 'Approved vendor KYC identity verification after WebCrypto SHA-256 seal audit.',
    metadata: { score: 95, country: 'Ghana', docType: 'International Passport' },
    ip_address: '102.176.54.12',
    status: 'SUCCESS'
  },
  {
    id: 'log-1002',
    created_at: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
    admin_email: 'zofgroupofcompanies@gmail.com',
    action_type: 'listing_deletion',
    target_resource: 'Listing: Fraudulent Mobile Device Ad',
    target_id: 'item-83921',
    description: 'Permanently deleted ad following community report of price spoofing.',
    metadata: { reason: 'Policy Violation - Suspicious Pricing', reportCount: 4 },
    ip_address: '102.176.54.12',
    status: 'SUCCESS'
  },
  {
    id: 'log-1003',
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    admin_email: 'zofgroupofcompanies@gmail.com',
    action_type: 'setting_update',
    target_resource: 'Site Settings: 2FA Authentication Policy',
    target_id: 'cfg-security-2fa',
    description: 'Enforced mandatory 6-digit email OTP verification for all admin portal logins.',
    metadata: { otpExpirySeconds: 300, targetEmail: 'zofgroupofcompanies@gmail.com' },
    ip_address: '102.176.54.12',
    status: 'SUCCESS'
  },
  {
    id: 'log-1004',
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    admin_email: 'zofgroupofcompanies@gmail.com',
    action_type: 'security_event',
    target_resource: 'Admin Portal Login Session',
    target_id: 'sess-839210',
    description: 'Administrator two-step login verification successfully unlocked.',
    metadata: { method: 'EMAIL_OTP_VERIFIED', email: 'zofgroupofcompanies@gmail.com' },
    ip_address: '102.176.54.12',
    status: 'SUCCESS'
  },
  {
    id: 'log-1005',
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
    admin_email: 'zofgroupofcompanies@gmail.com',
    action_type: 'escrow_release',
    target_resource: 'Escrow Transaction #ORD-1001',
    target_id: 'ord-1001',
    description: 'Released escrow payout of GH₵ 135,000 to vendor Adebayo Global Hub upon delivery receipt.',
    metadata: { amountGHS: 135000, courier: 'DHL Express' },
    ip_address: '102.176.54.12',
    status: 'SUCCESS'
  }
];

export const AdminAuditLogs: React.FC = () => {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | 'KYC' | 'DELETIONS' | 'SETTINGS' | 'SECURITY' | 'ESCROW'>('ALL');
  const [selectedLog, setSelectedLog] = useState<AuditLogEntry | null>(null);

  // New Log Form State
  const [showAddModal, setShowAddModal] = useState(false);
  const [newActionType, setNewActionType] = useState<AuditLogEntry['action_type']>('setting_update');
  const [newTargetResource, setNewTargetResource] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newNotes, setNewNotes] = useState('');

  const fetchAuditLogs = async () => {
    setLoading(true);
    try {
      // 1. Try querying Supabase 'audit_logs' table
      const { data, error } = await supabase
        .from('audit_logs')
        .select('*')
        .order('created_at', { ascending: false });

      if (!error && data && data.length > 0) {
        setLogs(data as AuditLogEntry[]);
      } else {
        // Fallback to local storage or mock dataset
        const stored = localStorage.getItem('datazone_audit_logs');
        if (stored) {
          try {
            setLogs(JSON.parse(stored));
          } catch (e) {
            setLogs(INITIAL_MOCK_AUDIT_LOGS);
          }
        } else {
          setLogs(INITIAL_MOCK_AUDIT_LOGS);
          localStorage.setItem('datazone_audit_logs', JSON.stringify(INITIAL_MOCK_AUDIT_LOGS));
        }
      }
    } catch (err) {
      console.warn('Failed to fetch audit logs from Supabase, using local fallback:', err);
      const stored = localStorage.getItem('datazone_audit_logs');
      setLogs(stored ? JSON.parse(stored) : INITIAL_MOCK_AUDIT_LOGS);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAuditLogs();
  }, []);

  const handleCreateAuditLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTargetResource || !newDescription) return;

    const newLog: AuditLogEntry = {
      id: `log-${Date.now()}`,
      created_at: new Date().toISOString(),
      admin_email: 'zofgroupofcompanies@gmail.com',
      action_type: newActionType,
      target_resource: newTargetResource,
      description: newDescription,
      metadata: newNotes ? { customNotes: newNotes } : undefined,
      ip_address: '102.176.54.12',
      status: 'SUCCESS'
    };

    // Attempt insert into Supabase table
    try {
      await supabase.from('audit_logs').insert([newLog]);
    } catch (err) {
      console.warn('Supabase log insert fallback:', err);
    }

    const updated = [newLog, ...logs];
    setLogs(updated);
    localStorage.setItem('datazone_audit_logs', JSON.stringify(updated));

    setShowAddModal(false);
    setNewTargetResource('');
    setNewDescription('');
    setNewNotes('');
  };

  const handleExportLogs = () => {
    const jsonStr = JSON.stringify(filteredLogs, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `datazone-admin-audit-logs-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Filter logs
  const filteredLogs = logs.filter(log => {
    const query = searchQuery.toLowerCase();
    const matchesSearch = 
      log.admin_email.toLowerCase().includes(query) ||
      log.action_type.toLowerCase().includes(query) ||
      log.target_resource.toLowerCase().includes(query) ||
      log.description.toLowerCase().includes(query);

    if (!matchesSearch) return false;

    if (categoryFilter === 'KYC') return log.action_type.includes('kyc') || log.action_type.includes('user');
    if (categoryFilter === 'DELETIONS') return log.action_type === 'listing_deletion';
    if (categoryFilter === 'SETTINGS') return log.action_type === 'setting_update';
    if (categoryFilter === 'SECURITY') return log.action_type === 'security_event';
    if (categoryFilter === 'ESCROW') return log.action_type === 'escrow_release';

    return true;
  });

  const getActionBadge = (action: AuditLogEntry['action_type']) => {
    switch (action) {
      case 'seller_kyc_approval':
      case 'user_approval':
        return (
          <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 px-2.5 py-0.5 rounded-full font-bold text-[10px] flex items-center gap-1">
            <UserCheck className="w-3 h-3 text-emerald-600" /> USER / KYC APPROVED
          </span>
        );
      case 'seller_kyc_rejection':
        return (
          <span className="bg-rose-100 text-rose-800 border border-rose-300 px-2.5 py-0.5 rounded-full font-bold text-[10px] flex items-center gap-1">
            <X className="w-3 h-3 text-rose-600" /> KYC REJECTED
          </span>
        );
      case 'listing_deletion':
        return (
          <span className="bg-red-100 text-red-800 border border-red-300 px-2.5 py-0.5 rounded-full font-bold text-[10px] flex items-center gap-1">
            <Trash2 className="w-3 h-3 text-red-600" /> LISTING DELETED
          </span>
        );
      case 'setting_update':
        return (
          <span className="bg-blue-100 text-blue-800 border border-blue-300 px-2.5 py-0.5 rounded-full font-bold text-[10px] flex items-center gap-1">
            <Settings className="w-3 h-3 text-blue-600" /> SITE SETTINGS UPDATED
          </span>
        );
      case 'security_event':
        return (
          <span className="bg-purple-100 text-purple-800 border border-purple-300 px-2.5 py-0.5 rounded-full font-bold text-[10px] flex items-center gap-1">
            <Lock className="w-3 h-3 text-purple-600" /> SECURITY / 2FA EVENT
          </span>
        );
      case 'escrow_release':
        return (
          <span className="bg-amber-100 text-amber-800 border border-amber-300 px-2.5 py-0.5 rounded-full font-bold text-[10px] flex items-center gap-1">
            <Database className="w-3 h-3 text-amber-600" /> ESCROW RELEASE
          </span>
        );
      default:
        return (
          <span className="bg-gray-100 text-gray-800 border border-gray-300 px-2.5 py-0.5 rounded-full font-bold text-[10px]">
            {action.toUpperCase()}
          </span>
        );
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200/80 shadow-xs p-6 flex flex-col gap-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-900 text-yellow-300 flex items-center justify-center shadow-xs">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-gray-900 tracking-tight flex items-center gap-2">
              <span>Admin Audit Trail & Log History</span>
              <span className="bg-emerald-100 text-emerald-800 font-bold text-[9px] px-2 py-0.5 rounded-full border border-emerald-300">
                Supabase 'audit_logs'
              </span>
            </h2>
            <p className="text-xs text-gray-500 font-medium mt-0.5">
              Immutable telemetry for user approvals, listing removals, security authentications, and platform settings updates.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportLogs}
            className="flex items-center gap-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs px-3 py-2 rounded-xl transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export JSON</span>
          </button>
          <button
            onClick={fetchAuditLogs}
            disabled={loading}
            className="flex items-center gap-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs px-3 py-2 rounded-xl transition cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 bg-[#3e3023] hover:bg-[#2b2118] text-yellow-300 font-bold text-xs px-3.5 py-2 rounded-xl transition cursor-pointer shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Record Action</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-gray-50 p-3.5 rounded-xl border border-gray-200">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search audit trail by email, action, target, or keyword..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-gray-200 rounded-lg pl-9 pr-3 py-1.5 text-xs text-gray-800 font-medium focus:outline-none focus:ring-1 focus:ring-slate-900"
          />
        </div>

        <div className="flex gap-1 overflow-x-auto pb-1 sm:pb-0">
          {(['ALL', 'KYC', 'DELETIONS', 'SETTINGS', 'SECURITY', 'ESCROW'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition shrink-0 cursor-pointer ${
                categoryFilter === cat
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-100'
              }`}
            >
              {cat === 'ALL' ? 'All Logs' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Audit Logs Table / List */}
      <div className="overflow-x-auto border border-gray-200 rounded-xl">
        <table className="w-full text-left text-xs text-gray-700">
          <thead className="bg-gray-50 border-b border-gray-200 font-extrabold text-gray-500 uppercase tracking-wider">
            <tr>
              <th className="px-4 py-3">Timestamp</th>
              <th className="px-4 py-3">Administrator</th>
              <th className="px-4 py-3">Action Type</th>
              <th className="px-4 py-3">Target Resource</th>
              <th className="px-4 py-3">Audit Details</th>
              <th className="px-4 py-3 text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 bg-white">
            {loading ? (
              <tr>
                <td colSpan={6} className="text-center py-12 text-gray-400">
                  <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-slate-400" />
                  <span>Querying Supabase 'audit_logs' table...</span>
                </td>
              </tr>
            ) : filteredLogs.length === 0 ? (
              <tr>
                <td colSpan={6} className="text-center py-12 text-gray-400">
                  <FileText className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                  <p className="font-bold text-gray-600 text-sm">No Audit Trail Logs Found</p>
                  <p className="text-xs text-gray-400 mt-1">Try expanding search query or selecting 'All Logs'.</p>
                </td>
              </tr>
            ) : (
              filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-gray-50/70 transition cursor-pointer" onClick={() => setSelectedLog(log)}>
                  <td className="px-4 py-3 text-gray-500 font-mono text-[11px] whitespace-nowrap">
                    {new Date(log.created_at).toLocaleString()}
                  </td>
                  <td className="px-4 py-3 font-bold text-gray-900 font-mono text-[11px]">
                    {log.admin_email}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    {getActionBadge(log.action_type)}
                  </td>
                  <td className="px-4 py-3 font-bold text-gray-800">
                    {log.target_resource}
                  </td>
                  <td className="px-4 py-3 text-gray-600 max-w-xs truncate">
                    {log.description}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded text-[9px] font-black uppercase">
                      {log.status}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Selected Log Metadata Viewer Drawer/Modal */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl border border-gray-200 shadow-2xl w-full max-w-lg p-6 flex flex-col gap-4">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-slate-900" />
                <h3 className="font-extrabold text-base text-gray-900">Audit Log Record Metadata</h3>
              </div>
              <button onClick={() => setSelectedLog(null)} className="p-1 hover:bg-gray-100 rounded-full cursor-pointer">
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2 bg-gray-50 p-3 rounded-xl border border-gray-200 font-mono text-[11px]">
                <div>
                  <span className="text-gray-400 block font-sans text-[10px] font-bold">Log ID</span>
                  <span className="font-bold text-gray-800">{selectedLog.id}</span>
                </div>
                <div>
                  <span className="text-gray-400 block font-sans text-[10px] font-bold">Timestamp</span>
                  <span className="font-bold text-gray-800">{new Date(selectedLog.created_at).toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-gray-400 block font-sans text-[10px] font-bold">Administrator</span>
                  <span className="font-bold text-gray-800">{selectedLog.admin_email}</span>
                </div>
                <div>
                  <span className="text-gray-400 block font-sans text-[10px] font-bold">IP Address</span>
                  <span className="font-bold text-gray-800">{selectedLog.ip_address || '102.176.54.12'}</span>
                </div>
              </div>

              <div>
                <span className="text-gray-500 font-bold block mb-1">Target Resource</span>
                <p className="font-extrabold text-gray-900 bg-gray-100 p-2.5 rounded-lg border border-gray-200">
                  {selectedLog.target_resource}
                </p>
              </div>

              <div>
                <span className="text-gray-500 font-bold block mb-1">Action Description</span>
                <p className="text-gray-700 leading-relaxed bg-gray-50 p-2.5 rounded-lg border border-gray-200">
                  {selectedLog.description}
                </p>
              </div>

              {selectedLog.metadata && (
                <div>
                  <span className="text-gray-500 font-bold block mb-1">Extended Payload Metadata</span>
                  <pre className="bg-slate-900 text-emerald-400 p-3 rounded-xl font-mono text-[11px] overflow-x-auto border border-slate-800">
                    {JSON.stringify(selectedLog.metadata, null, 2)}
                  </pre>
                </div>
              )}
            </div>

            <button
              onClick={() => setSelectedLog(null)}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2.5 rounded-xl transition cursor-pointer mt-2"
            >
              Close Inspector
            </button>
          </div>
        </div>
      )}

      {/* Manual Audit Action Record Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl border border-gray-200 shadow-2xl w-full max-w-md p-6 flex flex-col gap-4">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <h3 className="font-extrabold text-base text-gray-900">Record Administrative Action</h3>
              <button onClick={() => setShowAddModal(false)} className="p-1 hover:bg-gray-100 rounded-full cursor-pointer">
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            <form onSubmit={handleCreateAuditLog} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-gray-700 block mb-1">Action Category</label>
                <select
                  value={newActionType}
                  onChange={(e) => setNewActionType(e.target.value as any)}
                  className="w-full border border-gray-200 rounded-lg p-2 text-gray-900 font-medium focus:outline-none focus:ring-1 focus:ring-slate-900"
                >
                  <option value="seller_kyc_approval">Seller KYC Approval</option>
                  <option value="seller_kyc_rejection">Seller KYC Rejection</option>
                  <option value="listing_deletion">Listing Removal / Deletion</option>
                  <option value="setting_update">Site Setting Update</option>
                  <option value="security_event">Security / 2FA Parameter Update</option>
                  <option value="escrow_release">Escrow Payout Release</option>
                  <option value="manual_action">General Manual Action</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-gray-700 block mb-1">Target Resource</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Seller Account #8491 or Category Rule"
                  value={newTargetResource}
                  onChange={(e) => setNewTargetResource(e.target.value)}
                  className="w-full border border-gray-200 rounded-lg p-2 text-gray-900 focus:outline-none focus:ring-1 focus:ring-slate-900 font-medium"
                />
              </div>

              <div>
                <label className="font-bold text-gray-700 block mb-1">Description / Rationale</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Provide rationale or administrative action description..."
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full border border-gray-200 rounded-lg p-2 text-gray-900 focus:outline-none focus:ring-1 focus:ring-slate-900 font-medium"
                />
              </div>

              <div>
                <label className="font-bold text-gray-700 block mb-1">Custom Notes / Metadata (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. Approved under section 4B compliance"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full border border-gray-200 rounded-lg p-2 text-gray-900 focus:outline-none focus:ring-1 focus:ring-slate-900 font-medium"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold py-2.5 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-2 bg-[#3e3023] hover:bg-[#2b2118] text-yellow-300 font-bold py-2.5 rounded-xl cursor-pointer shadow-xs"
                >
                  Save to Audit Trail
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminAuditLogs;
