import React, { useState, useEffect } from 'react';
import { 
  X, Sparkles, DollarSign, FileText, Info, HelpCircle, 
  Check, Loader2, RefreshCcw, ArrowRight, Tag, HelpCircle as HelpIcon, MapPin,
  Upload, Image, AlertCircle, WifiOff
} from 'lucide-react';
import { CATEGORIES, COUNTRIES_CONFIG, COUNTRIES } from '../data/mockData';

interface PostAdModalProps {
  onClose: () => void;
  onAdPosted: () => void;
  onOpenSubscription?: () => void;
}

export default function PostAdModal({
  onClose,
  onAdPosted,
  onOpenSubscription
}: PostAdModalProps) {
  const [limitReachedError, setLimitReachedError] = useState<string | null>(null);
  const [showUpgradePrompt, setShowUpgradePrompt] = useState(false);

  // Read draft from localStorage synchronously to prevent state override race conditions
  const getDraftField = (field: string, defaultValue: any) => {
    try {
      const saved = localStorage.getItem('dosboz_ad_draft');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed[field] !== undefined) return parsed[field];
      }
    } catch (e) {
      console.error(`Failed to read draft field ${field}:`, e);
    }
    return defaultValue;
  };

  // Form State
  const [title, setTitle] = useState(() => getDraftField('title', ''));
  const [country, setCountry] = useState(() => getDraftField('country', 'Ghana'));
  const [categoryId, setCategoryId] = useState(() => getDraftField('categoryId', ''));
  const [categoryName, setCategoryName] = useState(() => getDraftField('categoryName', ''));
  const [subCategory, setSubCategory] = useState(() => getDraftField('subCategory', ''));
  const [price, setPrice] = useState(() => getDraftField('price', ''));
  const [isNegotiable, setIsNegotiable] = useState(() => getDraftField('isNegotiable', true));
  const [condition, setCondition] = useState<'New' | 'Refurbished' | 'Used'>(() => getDraftField('condition', 'Used'));
  const [region, setRegion] = useState(() => getDraftField('region', 'Greater Accra'));
  const [neighborhood, setNeighborhood] = useState(() => getDraftField('neighborhood', ''));
  const [phone, setPhone] = useState(() => getDraftField('phone', '+233 24 412 3456')); // defaults to Kofi
  const [whatsApp, setWhatsApp] = useState(() => getDraftField('whatsApp', '+233 24 412 3456'));
  const [description, setDescription] = useState(() => getDraftField('description', ''));
  const [imageUrl, setImageUrl] = useState('');
  const [imageUrls, setImageUrls] = useState<string[]>(() => getDraftField('imageUrls', []));
  
  // GPS Address and Current Item Location States
  const [gpsAddress, setGpsAddress] = useState(() => getDraftField('gpsAddress', ''));
  const [latitude, setLatitude] = useState(() => getDraftField('latitude', ''));
  const [longitude, setLongitude] = useState(() => getDraftField('longitude', ''));
  const [isLocating, setIsLocating] = useState(false);
  const [locationCaptured, setLocationCaptured] = useState(() => getDraftField('locationCaptured', false));

  // Original Pictures Upload Metadata
  const [originalImages, setOriginalImages] = useState<{ name: string; size: string; type: string }[]>(() => getDraftField('originalImages', []));
  
  // Drag & Drop Image Upload States & Handlers
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Network offline/online status state
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Save draft on changes
  useEffect(() => {
    const draft = {
      title,
      country,
      categoryId,
      categoryName,
      subCategory,
      price,
      isNegotiable,
      condition,
      region,
      neighborhood,
      phone,
      whatsApp,
      description,
      imageUrls,
      gpsAddress,
      latitude,
      longitude,
      originalImages,
      locationCaptured
    };
    localStorage.setItem('dosboz_ad_draft', JSON.stringify(draft));
  }, [
    title, country, categoryId, categoryName, subCategory, price,
    isNegotiable, condition, region, neighborhood, phone, whatsApp,
    description, imageUrls, gpsAddress, latitude, longitude,
    originalImages, locationCaptured
  ]);

  const isFirstCountryRun = React.useRef(true);
  const isFirstRegionRun = React.useRef(true);
  const isAutoPopulating = React.useRef(false);

  const handleFiles = (files: FileList) => {
    setUploadError(null);
    const validImageFiles: File[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!file.type.startsWith('image/')) {
        setUploadError('Only image files (PNG, JPG, JPEG, etc.) are supported.');
        continue;
      }
      validImageFiles.push(file);
    }

    if (validImageFiles.length === 0) return;

    if (imageUrls.length + validImageFiles.length > 5) {
      setUploadError('You can only attach up to 5 photos in total.');
      return;
    }

    validImageFiles.forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setImageUrls(prev => {
            if (prev.length >= 5) return prev;
            return [...prev, reader.result as string];
          });
          setOriginalImages(prev => {
            if (prev.length >= 5) return prev;
            return [...prev, {
              name: file.name,
              size: (file.size / (1024 * 1024)).toFixed(2) + ' MB',
              type: file.type
            }];
          });
        }
      };
      reader.onerror = () => {
        setUploadError('Failed to read one of the image files.');
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(e.target.files);
    }
  };
  
  // AI Assistant Specific States
  const [keyFeatures, setKeyFeatures] = useState('');
  const [aiCategorizing, setAiCategorizing] = useState(false);
  const [aiSuggestingPrice, setAiSuggestingPrice] = useState(false);
  const [aiGeneratingDesc, setAiGeneratingDesc] = useState(false);
  const [aiGeneratingImage, setAiGeneratingImage] = useState(false);
  
  // Suggested results from Gemini
  const [priceSuggestion, setPriceSuggestion] = useState<{
    suggestedMin: number;
    suggestedMax: number;
    reasoning: string;
  } | null>(null);

  // Auto-categorize title on blur
  const handleTitleBlur = () => {
    if (!title || title.trim().length < 5) return;
    setAiCategorizing(true);

    fetch('/api/ai/categorize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title })
    })
      .then(res => res.json())
      .then(data => {
        if (data.categoryId) {
          setCategoryId(data.categoryId);
          setCategoryName(data.categoryName);
          setSubCategory(data.subCategory);
        }
        setAiCategorizing(false);
      })
      .catch(err => {
        console.error('Categorize error:', err);
        setAiCategorizing(false);
      });
  };

  const fetchAddressAndPopulate = (lat: number, lng: number) => {
    isAutoPopulating.current = true;
    fetch('/api/ai/reverse-geocode', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ latitude: lat, longitude: lng, country })
    })
      .then(res => {
        if (!res.ok) throw new Error('Geocoding response error');
        return res.json();
      })
      .then(data => {
        if (data.region && data.neighborhood) {
          setRegion(data.region);
          setNeighborhood(data.neighborhood);
          if (data.formattedAddress) {
            setGpsAddress(data.formattedAddress);
          }
        }
        setIsLocating(false);
        setLocationCaptured(true);
        setTimeout(() => {
          isAutoPopulating.current = false;
        }, 150);
      })
      .catch(err => {
        console.error('Error auto-populating geocoding:', err);
        setIsLocating(false);
        setLocationCaptured(true);
        isAutoPopulating.current = false;
      });
  };

  const handleCaptureGPS = () => {
    setIsLocating(true);
    if (!navigator.geolocation) {
      setTimeout(() => {
        const lat = country === 'Nigeria' ? 6.5244 : country === 'Togo' ? 6.1375 : 5.6037 + (Math.random() - 0.5) * 0.05;
        const lng = country === 'Nigeria' ? 3.3792 : country === 'Togo' ? 1.2123 : -0.1870 + (Math.random() - 0.5) * 0.05;
        setLatitude(lat.toFixed(6));
        setLongitude(lng.toFixed(6));
        fetchAddressAndPopulate(lat, lng);
      }, 1000);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        setLatitude(lat.toFixed(6));
        setLongitude(lng.toFixed(6));
        fetchAddressAndPopulate(lat, lng);
      },
      (error) => {
        console.error("Geolocation error:", error);
        const lat = country === 'Nigeria' ? 6.5244 : country === 'Togo' ? 6.1375 : 5.6037 + (Math.random() - 0.5) * 0.05;
        const lng = country === 'Nigeria' ? 3.3792 : country === 'Togo' ? 1.2123 : -0.1870 + (Math.random() - 0.5) * 0.05;
        setLatitude(lat.toFixed(6));
        setLongitude(lng.toFixed(6));
        fetchAddressAndPopulate(lat, lng);
      },
      { enableHighAccuracy: true, timeout: 5000 }
    );
  };

  // Sync Category Name when Category ID changes
  useEffect(() => {
    const matched = CATEGORIES.find(c => c.id === categoryId);
    if (matched) {
      setCategoryName(matched.name);
    }
  }, [categoryId]);

  // Handle country changes
  useEffect(() => {
    if (isAutoPopulating.current) return;
    if (isFirstCountryRun.current) {
      isFirstCountryRun.current = false;
      const saved = localStorage.getItem('dosboz_ad_draft');
      if (saved) return;
    }
    const config = COUNTRIES_CONFIG[country] || COUNTRIES_CONFIG['Ghana'];
    const availableRegions = Object.keys(config.regions);
    if (availableRegions.length > 0) {
      setRegion(availableRegions[0]);
      const availableNeighborhoods = config.regions[availableRegions[0]];
      if (availableNeighborhoods && availableNeighborhoods.length > 0) {
        setNeighborhood(availableNeighborhoods[0]);
      }
    }
    // Update phone prefix to match country dial code
    setPhone(`${config.phoneCode} `);
    setWhatsApp(`${config.phoneCode} `);
  }, [country]);

  // Handle region change to pre-fill neighborhood
  useEffect(() => {
    if (isAutoPopulating.current) return;
    if (isFirstRegionRun.current) {
      isFirstRegionRun.current = false;
      const saved = localStorage.getItem('dosboz_ad_draft');
      if (saved) return;
    }
    const config = COUNTRIES_CONFIG[country] || COUNTRIES_CONFIG['Ghana'];
    const list = config.regions[region];
    if (list && list.length > 0) {
      setNeighborhood(list[0]);
    }
  }, [region, country]);

  // AI Price Valuation Assistant Trigger
  const triggerPriceValuation = () => {
    if (!title) {
      alert('Please fill in the item Title before evaluating price.');
      return;
    }
    setAiSuggestingPrice(true);
    setPriceSuggestion(null);

    fetch('/api/ai/suggest-price', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        condition,
        categoryName: categoryName || 'General',
        country
      })
    })
      .then(res => res.json())
      .then(data => {
        setPriceSuggestion(data);
        setAiSuggestingPrice(false);
      })
      .catch(err => {
        console.error('Price suggest error:', err);
        setAiSuggestingPrice(false);
      });
  };

  // AI Description Maker Trigger
  const triggerDescriptionMaker = () => {
    if (!title) {
      alert('Please enter an Ad Title before generating a description.');
      return;
    }
    setAiGeneratingDesc(true);

    fetch('/api/ai/generate-description', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        categoryName: categoryName || 'General',
        subCategory: subCategory || 'General',
        condition,
        keyFeatures
      })
    })
      .then(res => res.json())
      .then(data => {
        if (data.description) {
          setDescription(data.description);
        }
        setAiGeneratingDesc(false);
      })
      .catch(err => {
        console.error('Desc gen error:', err);
        setAiGeneratingDesc(false);
      });
  };

  // Apply Mid Price suggestion
  const applySuggestedPrice = () => {
    if (priceSuggestion) {
      const avg = Math.round((priceSuggestion.suggestedMin + priceSuggestion.suggestedMax) / 2);
      setPrice(avg.toString());
    }
  };

  // Add random Unsplash sample photo based on Category for quick testing
  const addSamplePhoto = () => {
    const categoryImages: Record<string, string[]> = {
      'cat-1': [
        'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=600&q=80'
      ],
      'cat-2': [
        'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1556656793-08538906a9f8?auto=format&fit=crop&w=600&q=80'
      ],
      'cat-3': [
        'https://images.unsplash.com/photo-1496181130204-7552cc14ac1a?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=600&q=80'
      ],
      'cat-4': [
        'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=600&q=80'
      ],
      'cat-5': [
        'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=600&q=80'
      ]
    };

    const links = categoryImages[categoryId] || [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80'
    ];
    
    const picked = links[Math.floor(Math.random() * links.length)];
    setImageUrls([...imageUrls, picked]);
    setOriginalImages([...originalImages, {
      name: `SAMPLE_PHOTO_${Date.now() % 1000}.JPG`,
      size: `${(1.2 + Math.random() * 0.8).toFixed(2)} MB`,
      type: "image/jpeg"
    }]);
  };

  const aiGeneratePlaceholder = () => {
    if (!title || title.trim().length < 3) {
      alert('Please enter an Ad Title first so the AI knows what product image to generate!');
      return;
    }
    if (imageUrls.length >= 5) {
      setUploadError('You already have 5 photos attached.');
      return;
    }

    setAiGeneratingImage(true);
    setUploadError(null);

    fetch('/api/ai/generate-image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        categoryName: categoryName || 'Product',
        condition
      })
    })
      .then(res => {
        if (!res.ok) {
          throw new Error('Failed to generate image.');
        }
        return res.json();
      })
      .then(data => {
        if (data.imageUrl) {
          setImageUrls(prev => {
            if (prev.length >= 5) return prev;
            return [...prev, data.imageUrl];
          });
          setOriginalImages(prev => {
            if (prev.length >= 5) return prev;
            return [...prev, {
              name: `AI_GENERATED_PRODUCT_${Date.now() % 1000}.PNG`,
              size: "1.85 MB",
              type: "image/png"
            }];
          });
        } else if (data.error) {
          setUploadError(`Failed to generate image: ${data.error}`);
        }
        setAiGeneratingImage(false);
      })
      .catch(err => {
        console.error('Image generation error:', err);
        setUploadError('An error occurred while calling the AI image generation service.');
        setAiGeneratingImage(false);
      });
  };

  const handleAddImageUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (imageUrl.trim()) {
      setImageUrls([...imageUrls, imageUrl.trim()]);
      setOriginalImages([...originalImages, {
        name: `REMOTE_URL_IMAGE_${Date.now() % 1000}.JPG`,
        size: "1.45 MB",
        type: "image/jpeg"
      }]);
      setImageUrl('');
    }
  };

  // Submit classified ad
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (isOffline) {
      alert('You are currently offline. We have safely saved your draft locally! Please reconnect to the internet to submit your ad.');
      return;
    }

    if (!title || !categoryId || !price || !region || !neighborhood) {
      alert('Please fill out all required fields.');
      return;
    }

    const payload = {
      title,
      categoryId,
      categoryName,
      subCategory,
      description,
      price: Number(price),
      isNegotiable,
      condition,
      country,
      region,
      neighborhood,
      imageUrls: imageUrls.length > 0 ? imageUrls : ['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80'],
      sellerName: 'Kofi Mensah', // Logged in
      sellerPhone: phone,
      sellerWhatsApp: whatsApp,
      sellerId: 'usr-current',
      gpsAddress: gpsAddress || undefined,
      gpsCoordinates: latitude && longitude ? { latitude: Number(latitude), longitude: Number(longitude) } : undefined,
      originalImagesMetadata: originalImages.length > 0 ? originalImages : undefined
    };

    const token = localStorage.getItem('datazone4_jwt_token');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;

    fetch('/api/seller/products', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload)
    })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) {
          if (res.status === 403 && data.code === 'PRODUCT_LIMIT_REACHED') {
            setLimitReachedError(data.message || 'You have reached your 5 active product limit on the Free Seller plan.');
            setShowUpgradePrompt(true);
            return;
          }
          throw new Error(data.message || data.error || 'Posting failed');
        }
        alert('Ad posted successfully!');
        try {
          localStorage.removeItem('dosboz_ad_draft');
        } catch (err) {
          console.error('Failed to clear draft:', err);
        }
        onAdPosted();
      })
      .catch((err: any) => {
        console.error('Submit error:', err);
        alert(err.message || 'Failed to post ad. Please try again.');
      });
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 overflow-y-auto flex justify-center p-4 sm:p-6 backdrop-blur-xs">
      
      {/* Product Limit Upgrade Prompt Modal */}
      {showUpgradePrompt && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 text-white p-6 rounded-2xl max-w-md w-full shadow-2xl flex flex-col items-center text-center animate-in zoom-in-95">
            <div className="p-3 bg-amber-500/20 text-amber-400 rounded-full mb-3 border border-amber-500/30">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-black text-white">5 Products Limit Reached!</h3>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              {limitReachedError || 'Free Sellers can post up to 5 active product listings. Upgrade to Monthly Seller (100 products) to keep expanding your business!'}
            </p>
            <div className="mt-6 flex flex-col sm:flex-row gap-3 w-full">
              <button
                onClick={() => setShowUpgradePrompt(false)}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold text-xs transition cursor-pointer"
              >
                Back to Draft
              </button>
              <button
                onClick={() => {
                  setShowUpgradePrompt(false);
                  if (onOpenSubscription) onOpenSubscription();
                }}
                className="flex-1 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 rounded-xl font-black text-xs transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                View Plans & Upgrade
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white w-full max-w-4xl h-fit rounded-2xl overflow-hidden shadow-2xl relative flex flex-col my-auto border border-gray-100">

        
        {/* HEADER */}
        <div className="bg-[#3e3023] text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-yellow-300 fill-yellow-300" />
            <h2 className="text-base sm:text-lg font-extrabold tracking-tight">
              Post Your Classified Ad (Ghana)
            </h2>
          </div>
          <button 
            onClick={onClose}
            className="text-gray-200 hover:text-white p-1 rounded-full hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* CONTENT SPLIT */}
        <div className="flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-gray-100">
          
          {/* LEFT WING: Post Ad Form */}
          <form onSubmit={handleSubmit} className="flex-1 p-6 flex flex-col gap-5 max-h-[80vh] overflow-y-auto">
            {/* Draft Status & Reset Header */}
            <div className="flex items-center justify-between bg-[#fcf9f6] px-4 py-2.5 rounded-xl border border-amber-100/50 shrink-0">
              <span className="text-[10px] text-gray-500 font-extrabold uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse shrink-0"></span>
                <span>Ad Draft Autosaved Locally</span>
              </span>
              <button
                type="button"
                onClick={() => {
                  if (confirm('Are you sure you want to clear your current draft and start fresh? This will reset all form fields.')) {
                    setTitle('');
                    setCountry('Ghana');
                    setCategoryId('');
                    setCategoryName('');
                    setSubCategory('');
                    setPrice('');
                    setIsNegotiable(true);
                    setCondition('Used');
                    setRegion('Greater Accra');
                    setNeighborhood('');
                    setPhone('+233 24 412 3456');
                    setWhatsApp('+233 24 412 3456');
                    setDescription('');
                    setImageUrls([]);
                    setOriginalImages([]);
                    setGpsAddress('');
                    setLatitude('');
                    setLongitude('');
                    setLocationCaptured(false);
                    try {
                      localStorage.removeItem('dosboz_ad_draft');
                    } catch (err) {
                      console.error('Failed to clear draft:', err);
                    }
                  }
                }}
                className="text-[10px] text-red-500 hover:text-red-700 hover:underline font-black uppercase tracking-wider transition cursor-pointer select-none border-0 bg-transparent"
              >
                Clear Draft
              </button>
            </div>

            {/* Offline Detection Warn Banner */}
            {isOffline && (
              <div className="bg-red-50 border border-red-100 rounded-xl p-4 flex gap-3 items-start animate-pulse shrink-0">
                <div className="bg-red-100 text-red-600 p-2 rounded-lg shrink-0 mt-0.5">
                  <WifiOff className="w-4 h-4" />
                </div>
                <div className="flex-1 text-left">
                  <h4 className="text-xs font-black text-red-800 uppercase tracking-wider">Currently Offline</h4>
                  <p className="text-[11px] text-red-700 leading-relaxed font-bold mt-0.5">
                    Your ad details are autosaved as a local draft so your progress is 100% secure. You will be able to post once your connection is restored.
                  </p>
                </div>
              </div>
            )}

            {/* Country Selector with Folded Global Stages */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-bold text-gray-500 uppercase flex items-center justify-between">
                <span>Country Target <span className="text-red-500">*</span></span>
                <span className="text-[10px] text-[#b08865] font-black">Global Expansion Folded</span>
              </label>
              <select
                required
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#b08865] cursor-pointer"
              >
                <optgroup label="Stage 1 — West Africa">
                  {['Ghana', 'Nigeria', 'Togo', 'Côte d\'Ivoire'].map(ctry => COUNTRIES_CONFIG[ctry] && (
                    <option key={ctry} value={ctry}>
                      {COUNTRIES_CONFIG[ctry].flag} {ctry} ({COUNTRIES_CONFIG[ctry].currency})
                    </option>
                  ))}
                </optgroup>
                <optgroup label="Stage 2 — Major International Markets">
                  {['United States', 'United Kingdom', 'Canada', 'Australia'].map(ctry => COUNTRIES_CONFIG[ctry] && (
                    <option key={ctry} value={ctry}>
                      {COUNTRIES_CONFIG[ctry].flag} {ctry} ({COUNTRIES_CONFIG[ctry].currency})
                    </option>
                  ))}
                </optgroup>
                <optgroup label="Stage 3 — Asia & Europe">
                  {['China', 'India', 'Japan', 'Germany', 'France', 'South Korea'].map(ctry => COUNTRIES_CONFIG[ctry] && (
                    <option key={ctry} value={ctry}>
                      {COUNTRIES_CONFIG[ctry].flag} {ctry} ({COUNTRIES_CONFIG[ctry].currency})
                    </option>
                  ))}
                </optgroup>
              </select>
            </div>

            {/* Title */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-bold text-gray-500 uppercase">
                Ad Title <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="e.g. Toyota Corolla 2018 Clean Interior"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  onBlur={handleTitleBlur}
                  className="w-full bg-gray-50 border border-gray-200 focus:bg-white focus:border-[#b08865] focus:ring-1 focus:ring-[#b08865] rounded-xl px-4 py-2.5 text-sm font-semibold transition"
                />
                {aiCategorizing && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 text-xs text-[#b08865] font-bold">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>AI Classifying...</span>
                  </div>
                )}
              </div>
            </div>

            {/* Category / Sub-Category */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-gray-500 uppercase">
                  Category <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#b08865]"
                >
                  <option value="">Select Category</option>
                  {CATEGORIES.map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-gray-500 uppercase">
                  Sub-category / Type
                </label>
                <input
                  type="text"
                  placeholder="e.g. Cars, Mobile Phones"
                  value={subCategory}
                  onChange={(e) => setSubCategory(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#b08865]"
                />
              </div>
            </div>

            {/* Condition & Price */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-gray-500 uppercase">
                  Condition <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['New', 'Refurbished', 'Used'] as const).map(cond => {
                    const active = condition === cond;
                    return (
                      <button
                        key={cond}
                        type="button"
                        onClick={() => setCondition(cond)}
                        className={`py-2 rounded-lg text-xs font-bold border transition text-center cursor-pointer ${
                          active 
                            ? 'bg-green-50 border-[#b08865] text-green-950' 
                            : 'bg-white border-gray-100 text-gray-500'
                        }`}
                      >
                        {cond}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-gray-500 uppercase">
                  Price ({COUNTRIES_CONFIG[country]?.currency || 'GH₵'}) <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="number"
                      required
                      placeholder="e.g. 1500"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 focus:bg-white focus:border-[#b08865] rounded-xl pl-9 pr-3 py-2 text-xs font-semibold focus:outline-none"
                    />
                  </div>
                  <label className="flex items-center gap-1.5 shrink-0 select-none cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isNegotiable}
                      onChange={(e) => setIsNegotiable(e.target.checked)}
                      className="accent-[#b08865] rounded"
                    />
                    <span className="text-[11px] font-bold text-gray-500">Negotiable</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Region / Neighborhood */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-gray-500 uppercase">
                  Region <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#b08865] cursor-pointer"
                >
                  {Object.keys(COUNTRIES_CONFIG[country]?.regions || {}).map(reg => (
                    <option key={reg} value={reg}>{reg}</option>
                  ))}
                </select>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-gray-500 uppercase">
                  Neighborhood / Area <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={neighborhood}
                  onChange={(e) => setNeighborhood(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#b08865] cursor-pointer"
                >
                  <option value="">Select Neighborhood</option>
                  {(COUNTRIES_CONFIG[country]?.regions[region] || []).map(neigh => (
                    <option key={neigh} value={neigh}>{neigh}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* GPS & Item Location Capture */}
            <div className="bg-gray-50/50 border border-gray-100 rounded-2xl p-4 flex flex-col gap-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex flex-col">
                  <span className="text-xs font-black text-gray-800 tracking-tight">GPS Address & Current Location</span>
                  <span className="text-[10px] text-gray-400 font-semibold leading-normal">Load high-accuracy coordinates of the item.</span>
                </div>
                <button
                  type="button"
                  onClick={handleCaptureGPS}
                  disabled={isLocating}
                  className="bg-[#b08865] hover:bg-[#967151] disabled:bg-gray-200 text-white text-[11px] font-bold px-3 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer select-none"
                >
                  {isLocating ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Locating...</span>
                    </>
                  ) : (
                    <>
                      <MapPin className="w-3.5 h-3.5 animate-bounce" />
                      <span>Capture GPS Location</span>
                    </>
                  )}
                </button>
              </div>

              {locationCaptured && (
                <div className="bg-green-50/50 border border-green-100 rounded-xl p-2.5 flex items-center gap-2">
                  <div className="bg-green-500 text-white p-0.5 rounded-full flex items-center justify-center">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </div>
                  <span className="text-[10px] text-green-800 font-bold">GPS coordinates successfully captured via hardware sensors!</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-wider">GPS Digital Address</label>
                  <input
                    type="text"
                    placeholder="e.g. GA-184-1024"
                    value={gpsAddress}
                    onChange={(e) => setGpsAddress(e.target.value)}
                    className="w-full bg-white border border-gray-200 focus:border-[#b08865] rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-wider">Latitude</label>
                  <input
                    type="text"
                    placeholder="e.g. 5.603700"
                    value={latitude}
                    onChange={(e) => setLatitude(e.target.value)}
                    className="w-full bg-white border border-gray-200 focus:border-[#b08865] rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-wider">Longitude</label>
                  <input
                    type="text"
                    placeholder="e.g. -0.187000"
                    value={longitude}
                    onChange={(e) => setLongitude(e.target.value)}
                    className="w-full bg-white border border-gray-200 focus:border-[#b08865] rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Contact Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-gray-500 uppercase">
                  Phone Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="+233 24 000 0000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2 text-xs font-semibold focus:outline-none focus:border-[#b08865]"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-gray-500 uppercase">
                  WhatsApp Number
                </label>
                <input
                  type="text"
                  placeholder="+233 24 000 0000"
                  value={whatsApp}
                  onChange={(e) => setWhatsApp(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2 text-xs font-semibold focus:outline-none focus:border-[#b08865]"
                />
              </div>
            </div>

            {/* Images Addition & Drag-and-Drop */}
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center flex-wrap gap-2">
                <label className="text-xs font-bold text-gray-500 uppercase flex items-center gap-1">
                  <span>Product Photos</span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-black ${imageUrls.length >= 5 ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'}`}>
                    {imageUrls.length} / 5
                  </span>
                </label>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={aiGeneratePlaceholder}
                    disabled={aiGeneratingImage || imageUrls.length >= 5}
                    className="text-[10px] text-orange-600 hover:underline font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50 disabled:no-underline"
                  >
                    {aiGeneratingImage ? (
                      <Loader2 className="w-3 h-3 animate-spin text-orange-500" />
                    ) : (
                      <Sparkles className="w-3 h-3 text-orange-500 fill-orange-500" />
                    )}
                    <span>{aiGeneratingImage ? 'Generating image...' : 'AI Generate Placeholder'}</span>
                  </button>
                  {categoryId && (
                    <button
                      type="button"
                      onClick={addSamplePhoto}
                      className="text-[10px] text-[#b08865] hover:underline font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Sparkles className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                      <span>Auto-attach Sample Photo</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Drag and Drop Zone */}
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => {
                  if (imageUrls.length < 5) {
                    document.getElementById('file-upload-input')?.click();
                  }
                }}
                className={`border-2 border-dashed rounded-xl p-5 text-center flex flex-col items-center justify-center gap-2 cursor-pointer transition-all ${
                  isDragOver 
                    ? 'border-[#b08865] bg-green-50/50 scale-[1.01]' 
                    : imageUrls.length >= 5
                    ? 'border-gray-200 bg-gray-50/50 cursor-not-allowed opacity-75'
                    : 'border-gray-200 bg-gray-50/30 hover:border-[#b08865] hover:bg-gray-50/50'
                }`}
              >
                <input
                  id="file-upload-input"
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleFileSelect}
                  className="hidden"
                  disabled={imageUrls.length >= 5}
                />
                
                <div className={`p-2.5 rounded-full ${isDragOver ? 'bg-[#b08865]/10 text-[#b08865]' : 'bg-gray-100 text-gray-400'}`}>
                  <Upload className="w-5 h-5 shrink-0" />
                </div>
                
                <div className="flex flex-col gap-0.5">
                  <span className="text-xs font-bold text-gray-700">
                    {imageUrls.length >= 5 
                      ? 'Maximum photos attached' 
                      : isDragOver 
                      ? 'Drop them now!' 
                      : 'Drag & drop photos here, or click to browse'}
                  </span>
                  <span className="text-[10px] text-gray-400 font-medium">
                    Supports JPG, JPEG, PNG, WEBP (Up to 5 images)
                  </span>
                </div>
              </div>

              {/* AI Placeholder Generation Banner */}
              {imageUrls.length < 5 && (
                <div className="bg-orange-50/30 border border-orange-100 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 mt-1">
                  <div className="flex gap-2.5 items-start">
                    <div className="p-1.5 bg-orange-100 text-orange-600 rounded-lg shrink-0 mt-0.5">
                      <Sparkles className="w-4 h-4 fill-orange-600 text-orange-600 animate-pulse" />
                    </div>
                    <div className="flex flex-col gap-0.5 text-left">
                      <span className="text-[11px] font-bold text-gray-700">Don't have a photo?</span>
                      <span className="text-[10px] text-gray-500 font-medium leading-relaxed">
                        Create a high-quality product image placeholder with AI based on your ad details.
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={aiGeneratePlaceholder}
                    disabled={aiGeneratingImage}
                    className="shrink-0 bg-orange-600 hover:bg-orange-700 text-white font-bold px-3.5 py-1.5 rounded-lg text-[11px] transition cursor-pointer disabled:bg-gray-200 disabled:text-gray-400 disabled:cursor-not-allowed flex items-center gap-1.5 justify-center shadow-xs"
                  >
                    {aiGeneratingImage ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Generating...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Generate Placeholder</span>
                      </>
                    )}
                  </button>
                </div>
              )}

              {/* URL Fallback / Paste Area */}
              {imageUrls.length < 5 && (
                <div className="bg-gray-50/50 border border-gray-100 rounded-xl p-2.5 flex flex-col gap-1.5 mt-1">
                  <span className="text-[10px] font-bold text-gray-400 uppercase">Or paste an image URL instead:</span>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      placeholder="https://example.com/item-photo.jpg"
                      value={imageUrl}
                      onChange={(e) => setImageUrl(e.target.value)}
                      className="flex-1 bg-white border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-[#b08865]"
                    />
                    <button
                      type="button"
                      onClick={handleAddImageUrl}
                      className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold px-3 py-1.5 rounded-lg text-xs transition cursor-pointer"
                    >
                      Add URL
                    </button>
                  </div>
                </div>
              )}

              {/* Error messages */}
              {uploadError && (
                <div className="flex items-center gap-1.5 text-[11px] text-red-600 font-semibold bg-red-50 p-2 rounded-lg border border-red-100 mt-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0 animate-pulse" />
                  <span>{uploadError}</span>
                </div>
              )}

              {/* Previews & Uploaded list */}
              {imageUrls.length > 0 && (
                <div className="flex flex-col gap-1.5 mt-2">
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Attached Photos ({imageUrls.length})</span>
                  <div className="grid grid-cols-5 gap-2.5">
                    {imageUrls.map((url, idx) => (
                      <div 
                        key={idx} 
                        className="group relative aspect-square rounded-xl border border-gray-200 overflow-hidden shrink-0 bg-gray-50 hover:shadow-sm transition"
                      >
                        <img 
                          src={url} 
                          alt={`Product preview ${idx + 1}`} 
                          referrerPolicy="no-referrer" 
                          className="w-full h-full object-cover" 
                        />
                        
                        {/* Overlay Controls */}
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <button
                            type="button"
                            onClick={() => {
                              setImageUrls(imageUrls.filter((_, i) => i !== idx));
                              setOriginalImages(originalImages.filter((_, i) => i !== idx));
                            }}
                            className="bg-red-500 hover:bg-red-600 text-white p-1.5 rounded-full shadow-md hover:scale-105 active:scale-95 transition cursor-pointer"
                            title="Delete photo"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* First image gets "Cover" badge */}
                        {idx === 0 && (
                          <span className="absolute bottom-1 left-1 bg-[#3e3023] text-white text-[8px] font-black px-1.5 py-0.5 rounded-md shadow-xs uppercase tracking-wider scale-90 origin-bottom-left">
                            Cover
                          </span>
                        )}

                        {/* Number Indicator */}
                        <span className="absolute top-1 left-1 bg-black/60 text-white text-[8px] font-black px-1.5 py-0.5 rounded-full scale-75 origin-top-left">
                          #{idx + 1}
                        </span>
                      </div>
                    ))}
                  </div>

                  {originalImages.length > 0 && (
                    <div className="mt-2.5 bg-gray-50/80 rounded-xl p-3 border border-gray-100 flex flex-col gap-1.5">
                      <span className="text-[9px] font-black text-[#b08865] uppercase tracking-widest">Original Image Files (RAW Uploads)</span>
                      <div className="flex flex-col gap-1">
                        {originalImages.map((img, index) => (
                          <div key={index} className="flex justify-between items-center text-[10px] font-medium text-gray-500 hover:text-gray-700">
                            <span className="truncate max-w-[200px] font-semibold">📄 {img.name}</span>
                            <span className="shrink-0 bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded text-[8px] font-bold">{img.size} ({img.type.split('/')[1]?.toUpperCase() || 'JPEG'})</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Main Description */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-bold text-gray-500 uppercase">
                Ad Description <span className="text-red-500">*</span>
              </label>
              <textarea
                required
                rows={5}
                placeholder="Write a clear details about your item. Mention faults, specs, condition, features."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 focus:bg-white focus:border-[#b08865] rounded-xl px-4 py-2.5 text-xs font-medium focus:outline-none leading-relaxed"
              />
            </div>

            {/* ACTIONS */}
            <div className="flex gap-4 pt-4 border-t border-gray-50 mt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold py-2.5 rounded-xl text-sm transition cursor-pointer text-center"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 bg-[#e65c00] hover:bg-[#ff6d0c] text-white font-black py-2.5 rounded-xl text-sm transition cursor-pointer text-center shadow-md shadow-orange-100 active:scale-98"
              >
                POST AD NOW
              </button>
            </div>
          </form>

          {/* RIGHT WING: Gemini AI Ad Assistant Side Panel */}
          <div className="w-full md:w-80 bg-green-50/20 p-6 flex flex-col gap-6 max-h-[80vh] overflow-y-auto shrink-0">
            {/* Header branding */}
            <div className="flex flex-col gap-1 pb-4 border-b border-gray-100">
              <span className="bg-yellow-400 text-[#3e3023] text-[10px] font-black px-2 py-0.5 rounded-md w-fit flex items-center gap-1 shadow-sm">
                <Sparkles className="w-3 h-3 fill-[#3e3023]" />
                <span>AI ASSISTANT</span>
              </span>
              <h3 className="font-extrabold text-gray-800 text-sm">
                Gemini Ad Post Copilot
              </h3>
              <p className="text-[11px] text-gray-400 font-medium leading-relaxed">
                Enhance your classifieds posting with real-time Ghanaian market intelligence and sales writing.
              </p>
            </div>

            {/* 1. AI Price Assistant */}
            <div className="flex flex-col gap-3">
              <span className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-[#b08865]" />
                <span>Ghanaian Price Appraisal</span>
              </span>
              <p className="text-[10px] text-gray-400 leading-normal font-medium">
                Generate localized retail price range recommendations based on title and inflation factors.
              </p>
              
              <button
                type="button"
                disabled={aiSuggestingPrice}
                onClick={triggerPriceValuation}
                className="w-full bg-[#3e3023] hover:bg-[#291f17] text-white text-xs font-bold py-2 rounded-lg flex items-center justify-center gap-1.5 transition disabled:opacity-50 cursor-pointer"
              >
                {aiSuggestingPrice ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Analyzing Market...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                    <span>Appraise Selling Price</span>
                  </>
                )}
              </button>

              {/* Price Suggestion Result Display */}
              {priceSuggestion && (
                <div className="bg-white border border-green-100 rounded-xl p-3.5 shadow-sm mt-1 flex flex-col gap-2.5">
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] font-bold text-gray-400 uppercase">Valuation</span>
                    <span className="text-[10px] font-extrabold text-[#b08865]">GH₵ Cedis</span>
                  </div>
                  <div className="text-center bg-green-50/50 py-1.5 rounded-lg border border-green-50">
                    <span className="text-base font-extrabold text-[#3e3023]">
                      GH₵ {priceSuggestion.suggestedMin.toLocaleString()} - {priceSuggestion.suggestedMax.toLocaleString()}
                    </span>
                  </div>
                  <p className="text-[10px] text-gray-500 font-semibold leading-relaxed">
                    {priceSuggestion.reasoning}
                  </p>
                  <button
                    type="button"
                    onClick={applySuggestedPrice}
                    className="w-full border border-dashed border-[#b08865] hover:bg-green-50 text-green-800 text-[10px] font-bold py-1 rounded transition cursor-pointer"
                  >
                    Apply Mid-Price (GH₵ {Math.round((priceSuggestion.suggestedMin + priceSuggestion.suggestedMax) / 2).toLocaleString()})
                  </button>
                </div>
              )}
            </div>

            {/* 2. AI Description Copywriter */}
            <div className="flex flex-col gap-3 pt-4 border-t border-gray-100">
              <span className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-[#b08865]" />
                <span>Description Sales Copywriter</span>
              </span>
              <p className="text-[10px] text-gray-400 leading-normal font-medium">
                Draft a compelling specification and sales pitch including Ghanaian phrases.
              </p>

              <div className="flex flex-col gap-1">
                <span className="text-[9px] text-gray-400 font-bold uppercase">Brief Bullet Highlights</span>
                <input
                  type="text"
                  placeholder="e.g. keyless entry, standard cams, 95% battery"
                  value={keyFeatures}
                  onChange={(e) => setKeyFeatures(e.target.value)}
                  className="w-full bg-white border border-gray-200 rounded-lg px-2 py-1.5 text-[11px] font-medium focus:outline-none"
                />
              </div>

              <button
                type="button"
                disabled={aiGeneratingDesc}
                onClick={triggerDescriptionMaker}
                className="w-full bg-[#3e3023] hover:bg-[#291f17] text-white text-xs font-bold py-2 rounded-lg flex items-center justify-center gap-1.5 transition disabled:opacity-50 cursor-pointer"
              >
                {aiGeneratingDesc ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Writing Copy...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                    <span>Generate Ad Copy</span>
                  </>
                )}
              </button>

              {aiGeneratingDesc && (
                <div className="bg-white border border-gray-100 rounded-xl p-3 text-center text-[10px] text-gray-400 font-semibold flex flex-col gap-2 items-center">
                  <Loader2 className="w-5 h-5 animate-spin text-[#b08865]" />
                  <span>Gemini is tailoring localized ad copy...</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
