import React, { useState } from 'react';
import { Heart, MapPin, Eye, Calendar, Sparkles, Phone, MessageSquare, Clock, Star, ShieldCheck, CheckCircle2, Award, Share2, Copy, Check, Send, ExternalLink, X } from 'lucide-react';
import { Listing } from '../types';
import { COUNTRIES_CONFIG } from '../data/mockData';
import { CurrencyCode, formatConvertedPrice } from '../utils/currency';

interface ListingCardProps {
  listing: Listing;
  isFavorite: boolean;
  onToggleFavorite: (e: React.MouseEvent) => void;
  onViewDetails: () => void;
  onChatClick: (e: React.MouseEvent) => void;
  selectedCurrency?: CurrencyCode;
}

export default function ListingCard({
  listing,
  isFavorite,
  onToggleFavorite,
  onViewDetails,
  onChatClick,
  selectedCurrency = 'GHS'
}: ListingCardProps) {
  const countryConfig = COUNTRIES_CONFIG[listing.country || 'Ghana'] || COUNTRIES_CONFIG['Ghana'];
  const formattedPrice = formatConvertedPrice(listing.price, listing.country || 'Ghana', selectedCurrency);

  const [timeLeft, setTimeLeft] = useState<string>('');
  const [showShareModal, setShowShareModal] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  const isSellerVerified = React.useMemo(() => {
    if (listing.isVerifiedVendor) return true;

    const savedKyc = localStorage.getItem('datazone4_seller_kyc');
    if (savedKyc) {
      try {
        const kyc = JSON.parse(savedKyc);
        if (kyc.kycStatus === 'approved') return true;
      } catch {}
    }

    if (['usr-seller-1', 'usr-[#b08865]-ng', 'usr-seller-ng-1', 'usr-seller-tg', 'usr-seed-1', 'usr-current'].includes(listing.sellerId)) {
      return true;
    }

    const nameToHash = listing.sellerId || listing.sellerName || 'Seller';
    let hash = 0;
    for (let i = 0; i < nameToHash.length; i++) {
      hash = nameToHash.charCodeAt(i) + ((hash << 5) - hash);
    }
    return Math.abs(hash) % 4 !== 0;
  }, [listing.sellerId, listing.sellerName, listing.isVerifiedVendor]);

  const sellerRating = React.useMemo(() => {
    if (listing.sellerId === 'usr-current') {
      const savedProfile = localStorage.getItem('dosboz_user_profile');
      if (savedProfile) {
        try {
          const profile = JSON.parse(savedProfile);
          return profile.rating !== undefined ? profile.rating : 4.8;
        } catch {
          return 4.8;
        }
      }
      return 4.8;
    }
    const nameToHash = listing.sellerId || listing.sellerName || 'Seller';
    let hash = 0;
    for (let i = 0; i < nameToHash.length; i++) {
      hash = nameToHash.charCodeAt(i) + ((hash << 5) - hash);
    }
    const ratingValue = 4.4 + (Math.abs(hash) % 7) / 10;
    return parseFloat(ratingValue.toFixed(1));
  }, [listing.sellerId, listing.sellerName]);

  React.useEffect(() => {
    if (!listing.expiryDate) return;

    const updateCountdown = () => {
      const expiry = new Date(listing.expiryDate!).getTime();
      const now = Date.now();
      const diff = expiry - now;

      if (diff <= 0) {
        setTimeLeft('Ad Expired');
        return;
      }

      const seconds = Math.floor((diff / 1000) % 60);
      const minutes = Math.floor((diff / 1000 / 60) % 60);
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));

      if (days > 0) {
        setTimeLeft(`${days}d ${hours}h left`);
      } else if (hours > 0) {
        setTimeLeft(`${hours}h ${minutes}m left`);
      } else if (minutes > 0) {
        setTimeLeft(`${minutes}m ${seconds}s left`);
      } else {
        setTimeLeft(`${seconds}s left`);
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [listing.expiryDate]);

  const getRelativeTime = (isoString: string) => {
    try {
      const past = new Date(isoString);
      const diffMs = Date.now() - past.getTime();
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMs / 3600000);
      const diffDays = Math.floor(diffMs / 86400000);

      if (diffMins < 60) return `${diffMins || 1}m ago`;
      if (diffHours < 24) return `${diffHours}h ago`;
      return `${diffDays}d ago`;
    } catch {
      return 'Recent';
    }
  };

  const getListingUrl = () => {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'https://datazone.app';
    return `${origin}/?listing=${listing.id}`;
  };

  const getShareSummary = () => {
    return `Check out "${listing.title}" for ${formattedPrice} in ${listing.neighborhood}, ${listing.region} on Datazone! ${getListingUrl()}`;
  };

  const handleCopyLink = (e: React.MouseEvent) => {
    e.stopPropagation();
    const url = getListingUrl();
    navigator.clipboard.writeText(url).then(() => {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    });
  };

  const handleNativeShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.share) {
      try {
        await navigator.share({
          title: listing.title,
          text: `Check out "${listing.title}" for ${formattedPrice} on Datazone!`,
          url: getListingUrl()
        });
      } catch (err) {}
    } else {
      setShowShareModal(true);
    }
  };

  const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(getShareSummary())}`;
  const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(getListingUrl())}&text=${encodeURIComponent(`Check out "${listing.title}" for ${formattedPrice} in ${listing.neighborhood}, ${listing.region} on Datazone!`)}`;

  return (
    <div 
      onClick={onViewDetails}
      className="group bg-white rounded-xl border border-gray-100 hover:border-gray-200 shadow-xs hover:shadow-md transition-all duration-300 overflow-hidden flex flex-col h-full cursor-pointer relative"
    >
      {/* Listing Image Container */}
      <div className="relative w-full aspect-4/3 bg-gray-50 overflow-hidden">
        <img
          src={listing.imageUrls[0]}
          alt={listing.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500 ease-out"
          loading="lazy"
        />

        {/* Condition & Verified Seller Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-wrap items-center gap-1 z-10">
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs ${
            listing.condition === 'New' 
              ? 'bg-[#b08865] text-white' 
              : listing.condition === 'Refurbished'
              ? 'bg-blue-600 text-white'
              : 'bg-yellow-500 text-gray-900'
          }`}>
            {listing.condition}
          </span>

          {isSellerVerified && (
            <span className="bg-emerald-600/95 text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow-sm flex items-center gap-1 border border-emerald-400/50 backdrop-blur-xs" title="KYC Verified Seller - Government ID Approved">
              <CheckCircle2 className="w-3 h-3 text-emerald-200" />
              <span>Verified Seller</span>
            </span>
          )}
        </div>

        {/* Top Action Buttons (Favorite & Share) */}
        <div className="absolute top-2.5 right-2.5 flex items-center gap-1.5 z-10">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowShareModal(true);
            }}
            className="p-1.5 bg-white/90 hover:bg-white text-gray-700 hover:text-emerald-600 rounded-full shadow-md backdrop-blur-xs transition transform hover:scale-110 active:scale-95 cursor-pointer"
            title="Share listing on WhatsApp, Telegram or copy link"
          >
            <Share2 className="w-3.5 h-3.5" />
          </button>
          
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(e);
            }}
            className={`p-1.5 rounded-full shadow-md backdrop-blur-xs transition transform hover:scale-110 active:scale-95 cursor-pointer ${
              isFavorite 
                ? 'bg-red-50 text-red-500' 
                : 'bg-white/90 text-gray-400 hover:text-red-500 hover:bg-white'
            }`}
          >
            <Heart className="w-4 h-4 fill-current" />
          </button>
        </div>

        {/* Featured Flag */}
        {listing.isFeatured && (
          <div className="absolute bottom-2.5 left-2.5 bg-yellow-400 text-green-950 text-[10px] font-black px-2 py-1 rounded-md flex items-center gap-1 shadow-sm z-10">
            <Sparkles className="w-3 h-3 text-green-900 fill-green-900" />
            <span>FEATURED</span>
          </div>
        )}

        {/* Expiry Countdown Badge */}
        {listing.expiryDate && timeLeft && (
          <div className={`absolute bottom-2.5 right-2.5 text-white text-[10px] font-black px-2 py-1 rounded-md flex items-center gap-1 shadow-sm backdrop-blur-xs z-10 ${
            timeLeft === 'Ad Expired' 
              ? 'bg-gray-600/90' 
              : 'bg-red-600/90 animate-pulse'
          }`}>
            <Clock className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>{timeLeft.toUpperCase()}</span>
          </div>
        )}
      </div>

      {/* Card Details Body */}
      <div className="p-3.5 flex flex-col flex-1">
        {/* Sub-category & Trust Badges */}
        <div className="flex items-center justify-between gap-2 mb-1.5 flex-wrap">
          <span className="text-[10px] font-bold tracking-wider text-green-700 uppercase">
            {listing.subCategory}
          </span>
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-[9px] text-gray-500 font-extrabold flex items-center gap-0.5 bg-gray-50 border border-gray-200 px-1.5 py-0.5 rounded-sm">
              <Star className="w-2.5 h-2.5 text-amber-400 fill-amber-400 shrink-0" />
              <span>{sellerRating}</span>
            </span>
            {isSellerVerified && (
              <span className="text-[9px] bg-emerald-50 text-emerald-800 border border-emerald-200 font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-2xs" title="KYC Verified Seller - Government ID & Business KYC Approved">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 fill-emerald-100 shrink-0" />
                <span>VERIFIED SELLER</span>
              </span>
            )}
          </div>
        </div>

        {/* Title */}
        <h3 className="text-sm font-semibold text-gray-800 line-clamp-2 leading-snug group-hover:text-[#b08865] transition-colors mb-2 min-h-[40px]">
          {listing.title}
        </h3>

        {/* Price & Negotiability */}
        <div className="flex items-center gap-2 mb-2 flex-wrap">
          <span className="text-base font-extrabold text-gray-900 tracking-tight">
            {formattedPrice}
          </span>
          {listing.isNegotiable && (
            <span className="text-[9px] bg-green-50 text-green-700 font-bold px-1.5 py-0.5 rounded border border-green-100">
              Negotiable
            </span>
          )}
        </div>

        {/* Location & Time Stamp */}
        <div className="flex flex-col gap-1 text-[11px] text-gray-400 mt-auto pt-2.5 border-t border-gray-50">
          <span className="flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-gray-300 shrink-0" />
            <span className="truncate">{countryConfig?.flag} {listing.neighborhood}, {listing.region}</span>
          </span>
          
          <div className="flex items-center justify-between mt-1 text-[10px]">
            <span className="flex items-center gap-0.5">
              <Calendar className="w-3 h-3 text-gray-300" />
              {getRelativeTime(listing.createdAt)}
            </span>
            <span className="flex items-center gap-0.5">
              <Eye className="w-3 h-3 text-gray-300" />
              {listing.views} views
            </span>
          </div>
        </div>
      </div>

      {/* Quick Action Overlay */}
      <div className="px-3 pb-3 pt-1 flex gap-2 border-t border-gray-50 bg-gray-50/50">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onChatClick(e);
          }}
          className="flex-1 bg-[#4a3a2c] hover:bg-[#3d3024] text-white text-[11px] font-bold py-1.5 rounded-md flex items-center justify-center gap-1 transition cursor-pointer"
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Chat</span>
        </button>

        <a
          href={`tel:${listing.sellerPhone}`}
          onClick={(e) => e.stopPropagation()}
          className="flex-1 border border-gray-200 hover:border-[#b08865] hover:bg-green-50 text-gray-700 hover:text-green-800 text-[11px] font-bold py-1.5 rounded-md flex items-center justify-center gap-1 transition text-center"
        >
          <Phone className="w-3.5 h-3.5" />
          <span>Call</span>
        </a>

        <button
          onClick={(e) => {
            e.stopPropagation();
            setShowShareModal(true);
          }}
          className="border border-gray-200 hover:border-emerald-500 hover:bg-emerald-50 text-gray-700 hover:text-emerald-800 text-[11px] font-bold px-2.5 py-1.5 rounded-md flex items-center justify-center gap-1 transition cursor-pointer shrink-0"
          title="Share Listing"
        >
          <Share2 className="w-3.5 h-3.5 text-emerald-600" />
        </button>
      </div>

      {/* SHARE MODAL OVERLAY */}
      {showShareModal && (
        <div 
          onClick={(e) => {
            e.stopPropagation();
            setShowShareModal(false);
          }}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl border border-gray-200 shadow-2xl p-5 max-w-sm w-full flex flex-col gap-4 text-left animate-in zoom-in-95 duration-150"
          >
            <div className="flex justify-between items-center pb-3 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <div className="bg-emerald-100 text-emerald-800 p-2 rounded-xl">
                  <Share2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-gray-900">Share Product Listing</h4>
                  <p className="text-[11px] text-gray-500">Spread the word on mobile & social</p>
                </div>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowShareModal(false);
                }}
                className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Preview Card Summary */}
            <div className="bg-gray-50 p-3 rounded-xl border border-gray-200/80 flex gap-3 items-center">
              <img 
                src={listing.imageUrls[0]} 
                alt={listing.title} 
                className="w-12 h-12 object-cover rounded-lg shrink-0 border border-gray-200" 
              />
              <div className="flex flex-col min-w-0">
                <span className="font-bold text-xs text-gray-900 truncate">{listing.title}</span>
                <span className="font-black text-xs text-emerald-700">{formattedPrice}</span>
                <span className="text-[10px] text-gray-400 truncate">{listing.neighborhood}, {listing.region}</span>
              </div>
            </div>

            {/* Sharing Options */}
            <div className="flex flex-col gap-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="w-full bg-[#25D366] hover:bg-[#20bd5a] text-white font-extrabold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition cursor-pointer shadow-2xs"
              >
                <MessageSquare className="w-4 h-4 fill-white" />
                <span>Share on WhatsApp</span>
                <ExternalLink className="w-3.5 h-3.5 ml-auto opacity-80" />
              </a>

              <a
                href={telegramUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="w-full bg-[#229ED9] hover:bg-[#1f8ebd] text-white font-extrabold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition cursor-pointer shadow-2xs"
              >
                <Send className="w-4 h-4 fill-white" />
                <span>Share on Telegram</span>
                <ExternalLink className="w-3.5 h-3.5 ml-auto opacity-80" />
              </a>

              <button
                type="button"
                onClick={handleCopyLink}
                className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-extrabold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition cursor-pointer border border-gray-200"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span className="text-emerald-700">Listing URL Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-gray-600" />
                    <span>Copy Listing Link</span>
                  </>
                )}
              </button>

              {typeof navigator !== 'undefined' && 'share' in navigator && (
                <button
                  type="button"
                  onClick={handleNativeShare}
                  className="w-full bg-[#3e3023] hover:bg-[#291f17] text-yellow-300 font-extrabold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition cursor-pointer shadow-2xs mt-1"
                >
                  <Share2 className="w-4 h-4" />
                  <span>More Sharing Options...</span>
                </button>
              )}
            </div>

            <div className="pt-2 border-t border-gray-100 text-[10px] text-gray-400 font-mono text-center">
              Direct Link: {getListingUrl()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

