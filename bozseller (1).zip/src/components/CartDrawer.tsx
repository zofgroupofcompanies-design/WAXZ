import React, { useState } from 'react';
import { CartItem, CurrencyCode, CarrierCode, PaymentGateway, Order } from '../types';
import { formatPrice } from '../lib/currencies';
import { CARRIERS, calculateCarrierQuotes, generateTrackingNumber } from '../lib/carriers';
import { PAYMENT_GATEWAYS, processPaymentSimulation } from '../lib/payments';
import { createOrderReceiptSignature } from '../lib/encryption';
import { X, Trash2, Lock, Truck, CreditCard, ShieldCheck, ArrowRight, Loader2 } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  activeCurrency: CurrencyCode;
  deliverToCountry: string;
  userEmail: string | null;
  onCheckoutSuccess: (order: Order) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  activeCurrency,
  deliverToCountry,
  userEmail,
  onCheckoutSuccess,
}) => {
  const [selectedCarrier, setSelectedCarrier] = useState<CarrierCode>('dhl');
  const [selectedPayment, setSelectedPayment] = useState<PaymentGateway>('stripe');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  // Calculate totals
  const subtotalUsd = cart.reduce((acc, item) => acc + item.product.priceUsd * item.quantity, 0);
  const totalWeightKg = cart.reduce((acc, item) => acc + item.product.shippingWeightKg * item.quantity, 0);

  const quotes = calculateCarrierQuotes(totalWeightKg, deliverToCountry);
  const currentQuote = quotes.find(q => q.code === selectedCarrier) || quotes[0];
  const shippingFeeUsd = subtotalUsd > 0 ? currentQuote.rateUsd : 0;
  const totalUsd = subtotalUsd + shippingFeeUsd;

  // Handle Checkout Execution
  const handleExecuteCheckout = async () => {
    if (cart.length === 0) return;

    setIsProcessing(true);
    try {
      // 1. Process Payment Simulation
      const paymentResult = await processPaymentSimulation(selectedPayment, totalUsd, activeCurrency);

      if (!paymentResult.success) {
        alert('Payment processing failed. Please check gateway parameters.');
        setIsProcessing(false);
        return;
      }

      // 2. Generate Encrypted Receipt Signature
      const timestamp = new Date().toISOString();
      const orderId = `ORD-GV-${Math.floor(100000 + Math.random() * 900000)}`;
      const buyerId = userEmail ? userEmail.replace(/[^a-zA-Z0-9]/g, '_') : 'guest_buyer';
      const trackingNumber = generateTrackingNumber(selectedCarrier);

      const receiptSig = await createOrderReceiptSignature(
        orderId,
        buyerId,
        totalUsd,
        cart.length,
        timestamp
      );

      const newOrder: Order = {
        id: orderId,
        buyerId,
        buyerEmail: userEmail || 'guest@globalvault.com',
        buyerName: userEmail ? userEmail.split('@')[0] : 'Global Customer',
        items: [...cart],
        totalAmountUsd: totalUsd,
        currency: activeCurrency,
        convertedTotal: totalUsd,
        paymentMethod: selectedPayment,
        paymentStatus: selectedPayment === 'crypto_escrow' ? 'escrowed' : 'paid',
        shippingCarrier: selectedCarrier,
        carrierName: CARRIERS[selectedCarrier].name,
        shippingFeeUsd,
        trackingNumber,
        shippingAddress: `Verified Destination Hub (${deliverToCountry})`,
        destinationCountry: deliverToCountry,
        orderStatus: 'processing',
        encryptedReceiptHash: receiptSig,
        encryptedSecurityKey: `KEY_CRYPT_256_${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
        createdAt: timestamp,
        updatedAt: timestamp,
      };

      onCheckoutSuccess(newOrder);
      setIsProcessing(false);
      onClose();
    } catch (e) {
      console.error(e);
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex justify-end">
      <div className="bg-white w-full max-w-lg h-full border-l border-slate-200 shadow-2xl flex flex-col justify-between overflow-hidden relative animate-in slide-in-from-right duration-300">
        {/* Drawer Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="font-bold text-sm text-white flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-emerald-400" /> Express Checkout Cart
            </span>
            <span className="bg-slate-800 text-emerald-400 text-xs px-2 py-0.5 rounded font-mono">
              {cart.length} items
            </span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cart Item List */}
        <div className="p-4 overflow-y-auto flex-1 space-y-4 divide-y divide-slate-100">
          {cart.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <Lock className="w-6 h-6" />
              </div>
              <p className="text-sm font-semibold text-slate-700">Your shopping cart is empty</p>
              <p className="text-xs text-slate-400">Add products from the marketplace catalog to proceed.</p>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.product.id} className="pt-3 flex items-start gap-3">
                <img
                  src={item.product.imageUrl}
                  alt={item.product.title}
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 object-cover rounded-lg border border-slate-200 shrink-0 bg-slate-100"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold text-slate-900 truncate">{item.product.title}</h4>
                  <span className="text-[10px] text-slate-400 block">{item.product.category} · Vendor: {item.product.sellerName}</span>
                  <div className="text-xs font-bold text-slate-900 font-mono mt-1">
                    {formatPrice(item.product.priceUsd * item.quantity, activeCurrency)}
                  </div>

                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center border border-slate-200 rounded-md overflow-hidden bg-slate-50">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, -1)}
                        className="px-2 py-0.5 text-xs font-bold text-slate-600 hover:bg-slate-200"
                      >
                        -
                      </button>
                      <span className="px-2 text-xs font-mono text-slate-900 font-bold">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, 1)}
                        className="px-2 py-0.5 text-xs font-bold text-slate-600 hover:bg-slate-200"
                      >
                        +
                      </button>
                    </div>
                    <button
                      onClick={() => onRemoveItem(item.product.id)}
                      className="text-slate-400 hover:text-rose-500 p-1 text-xs transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}

          {cart.length > 0 && (
            <div className="pt-4 space-y-4">
              {/* Shipping Carrier Selector */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-emerald-600" /> Select Global Shipping Carrier ({deliverToCountry})
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {quotes.map((q) => (
                    <button
                      key={q.code}
                      onClick={() => setSelectedCarrier(q.code)}
                      className={`p-2.5 rounded-lg border text-left text-xs transition-all ${
                        selectedCarrier === q.code
                          ? 'border-emerald-500 bg-emerald-50/50 text-slate-900 font-bold shadow-sm'
                          : 'border-slate-200 hover:border-slate-300 text-slate-600'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span>{q.logo}</span>
                        <span className="font-mono text-emerald-600">{formatPrice(q.rateUsd, activeCurrency)}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-1">{q.estimatedDays} Business Days</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Payment Gateway Selector */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1">
                  <CreditCard className="w-3.5 h-3.5 text-emerald-600" /> Select Encrypted Payment Gateway
                </span>
                <div className="space-y-1.5">
                  {PAYMENT_GATEWAYS.map((gw) => (
                    <button
                      key={gw.id}
                      onClick={() => setSelectedPayment(gw.id)}
                      className={`w-full p-2.5 rounded-lg border text-left text-xs transition-all flex items-center justify-between ${
                        selectedPayment === gw.id
                          ? 'border-emerald-500 bg-emerald-50/50 text-slate-900 font-bold'
                          : 'border-slate-200 hover:border-slate-300 text-slate-600'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-base">{gw.icon}</span>
                        <div>
                          <div className="font-semibold text-slate-900">{gw.name}</div>
                          <div className="text-[10px] text-slate-500">{gw.badge}</div>
                        </div>
                      </div>
                      <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                        Verified
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Drawer Footer & Total Summary */}
        {cart.length > 0 && (
          <div className="p-4 bg-slate-900 text-white border-t border-slate-800 space-y-3">
            <div className="space-y-1 text-xs text-slate-300">
              <div className="flex justify-between">
                <span>Items Subtotal:</span>
                <span className="font-mono">{formatPrice(subtotalUsd, activeCurrency)}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping ({CARRIERS[selectedCarrier].name}):</span>
                <span className="font-mono">{formatPrice(shippingFeeUsd, activeCurrency)}</span>
              </div>
              <div className="flex justify-between text-emerald-400 font-bold pt-1 border-t border-slate-800 text-sm">
                <span>Total Payable ({activeCurrency}):</span>
                <span className="font-mono">{formatPrice(totalUsd, activeCurrency)}</span>
              </div>
            </div>

            <div className="flex items-center gap-1 text-[10px] text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Includes cryptographic SHA-256 HMAC receipt signature</span>
            </div>

            <button
              onClick={handleExecuteCheckout}
              disabled={isProcessing}
              className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-3 rounded-xl transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 text-sm"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Generating Encrypted Receipt...
                </>
              ) : (
                <>
                  Complete Order & Lock Receipt
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
