export * from './types/index';

export interface Category {
  id: string;
  name: string;
  icon: string; // lucide icon name
  slug: string;
  adCount: number;
}

export interface Listing {
  id: string;
  title: string;
  categoryId: string;
  categoryName: string;
  subCategory: string;
  description: string;
  price: number;
  isNegotiable: boolean;
  condition: 'New' | 'Refurbished' | 'Used';
  country: string; // 'Ghana' | 'Nigeria' | 'Togo'
  region: string;
  neighborhood: string;
  imageUrls: string[];
  sellerName: string;
  sellerPhone: string;
  sellerWhatsApp: string;
  createdAt: string;
  views: number;
  isFeatured: boolean;
  sellerId: string;
  status: 'active' | 'closed';
  gpsAddress?: string;
  gpsCoordinates?: { latitude: number; longitude: number };
  originalImagesMetadata?: { name: string; size: string; type: string }[];
  expiryDate?: string;
  isVerifiedVendor?: boolean;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
  isSystem?: boolean;
}

export interface ChatSession {
  chatId: string;
  listingId: string;
  listingTitle: string;
  listingPrice: number;
  listingImage: string;
  buyerId: string;
  buyerName: string;
  sellerId: string;
  sellerName: string;
  messages: ChatMessage[];
  lastUpdated: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  rating: number;
  reputationScore: number; // Percentage positive rating e.g. 98.5
  avatarUrl: string;
  joinedDate: string;
  verified: boolean;
}

export interface SellerReview {
  id: string;
  sellerId: string;
  sellerName: string;
  buyerId: string;
  buyerName: string;
  listingId: string;
  listingTitle?: string;
  rating: number; // 1 to 5 stars
  reviewText: string;
  transactionCompleted: boolean;
  createdAt: string;
}

export interface TopSeller {
  sellerId: string;
  sellerName: string;
  avatarUrl: string;
  country: string; // 'Ghana' | 'Nigeria' | 'Togo' | 'Kenya' | 'United Kingdom' | 'United States'
  region: string;
  verified: boolean;
  tier: 'Platinum Power Vendor' | 'Gold Merchant' | 'Verified Retailer' | 'Top Dispatcher' | 'Pro Seller';
  totalSalesVolumeUSD: number;
  totalSalesVolumeLocal: number;
  currency: string;
  completedOrders: number;
  activeListingsCount: number;
  rating: number; // e.g. 4.9
  reviewCount: number; // e.g. 142
  reputationScore: number; // e.g. 98.5
  responseTimeMinutes: number; // e.g. 15
  joinedDate: string;
  badges: string[];
  featuredProducts?: {
    id: string;
    title: string;
    price: number;
    currency: string;
    image: string;
  }[];
}

export interface Report {
  id: string;
  listingId: string;
  listingTitle: string;
  listingPrice: number;
  listingCountry: string;
  reporterName: string;
  reason: string;
  details: string;
  createdAt: string;
  status: 'pending' | 'resolved' | 'dismissed';
}

export type UserRole = 'admin' | 'buyer' | 'seller';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  createdAt?: string;
}

export interface AuthResponse {
  token: string;
  user: AuthUser;
  message?: string;
}

export type SellerPlanType = 'free' | 'monthly' | 'trial';

export interface CountryPriceConfig {
  countryCode: string;
  countryName: string;
  currency: string;
  currencySymbol: string;
  monthlyPrice: number;
}

export interface SellerSubscription {
  sellerId: string;
  plan: SellerPlanType;
  countryCode: string;
  currency: string;
  status: 'active' | 'expired' | 'cancelled';
  startDate: string;
  expiryDate: string | null;
  autoRenew: boolean;
  paymentProvider?: 'paystack' | 'stripe' | 'flutterwave' | 'manual';
}

export interface SubscriptionStatusResponse {
  subscription: SellerSubscription;
  activeProductsCount: number;
  productLimit: number;
  canPostMore: boolean;
  excessProducts: number;
  countryConfig: CountryPriceConfig;
  availableCountries: CountryPriceConfig[];
}

export type PaymentGatewayType = 'paystack' | 'flutterwave' | 'stripe' | 'momo';

export interface CourierQuote {
  id: string;
  name: string; // 'DHL Express', 'FedEx Global', 'UPS Worldwide', 'Local Dispatch Rider'
  estimatedDays: string;
  price: number;
  currency: string;
  badge?: string;
}

export interface ShippingLabel {
  trackingCode: string;
  carrier: string;
  originCountry: string;
  destinationCountry: string;
  weightKg: number;
  senderName: string;
  recipientName: string;
  recipientAddress: string;
  createdAt: string;
  estimatedDelivery: string;
  status: 'label_created' | 'picked_up' | 'in_transit' | 'delivered';
}

export interface Order {
  id: string;
  listingId?: string;
  listingTitle?: string;
  listingPrice?: number;
  listingImage?: string;
  buyerId: string;
  buyerName: string;
  buyerEmail?: string;
  buyerPhone?: string;
  sellerId?: string;
  sellerName?: string;
  quantity?: number;
  itemTotal?: number;
  shippingFee?: number;
  platformFee?: number; // 5% commission
  totalAmount?: number;
  totalAmountUsd?: number;
  currency?: string;
  courier?: string;
  courierTrackingCode?: string;
  paymentGateway?: PaymentGatewayType | string;
  paymentRef?: string;
  status?: 'escrow_held' | 'in_transit' | 'delivered' | 'completed' | 'disputed';
  shippingAddress?: string;
  destinationCountry?: string;
  createdAt?: string;
  updatedAt?: string;

  // Additional receipt & logistics fields
  items?: any[];
  convertedTotal?: number;
  paymentMethod?: string;
  paymentStatus?: 'paid' | 'pending' | 'escrowed' | 'refunded';
  shippingCarrier?: string;
  carrierName?: string;
  shippingFeeUsd?: number;
  trackingNumber?: string;
  orderStatus?: 'processing' | 'shipped' | 'in_transit' | 'delivered' | 'disputed' | 'cancelled';
  encryptedReceiptHash?: string;
  encryptedSecurityKey?: string;
}

export interface VendorWallet {
  sellerId: string;
  availableBalance: number;
  escrowBalance: number;
  totalSalesVolume: number;
  currency: string;
  history: {
    id: string;
    type: 'order_payout' | 'payout_withdrawal' | 'subscription_fee';
    amount: number;
    description: string;
    date: string;
    status: 'completed' | 'pending';
  }[];
}

export interface PayoutRequest {
  id: string;
  sellerId: string;
  sellerName: string;
  amount: number;
  currency: string;
  payoutMethod: 'momo' | 'bank';
  accountName: string;
  accountNumber: string;
  bankOrNetwork: string; // 'MTN', 'Telecel', 'AT', 'Ecobank Ghana', 'GCB Bank', 'GTBank', etc.
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export type GovernmentIdType = 'passport' | 'drivers_license' | 'national_id' | 'tax_id';
export type KycVerificationStatus = 'not_submitted' | 'pending_verification' | 'approved' | 'rejected';

export interface SellerKycData {
  id: string;
  sellerId: string;
  sellerName: string;
  email: string;
  phone: string;
  country: string;
  governmentIdType: GovernmentIdType;
  idNumber: string;
  documentEncryptedHash: string;
  kycStatus: KycVerificationStatus;
  aiKycScore?: number;
  aiKycNotes?: string;
  submittedAt: string;
  approvedAt?: string;
}

export interface AISellerKycReport {
  aiScore: number;
  isDocAuthentic: boolean;
  tamperDetected: boolean;
  verificationNotes: string;
  recommendedStatus: 'APPROVED' | 'FLAGGED_FOR_MANUAL_REVIEW' | 'REJECTED';
  flags: string[];
}

