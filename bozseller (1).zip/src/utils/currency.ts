export type CurrencyCode = 'GHS' | 'NGN' | 'XOF' | 'USD' | 'GBP' | 'CAD' | 'AUD' | 'CNY' | 'INR' | 'JPY' | 'EUR' | 'KRW';

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  name: string;
  label: string;
  flag: string;
}

export const CURRENCIES: Record<CurrencyCode, CurrencyConfig> = {
  GHS: { code: 'GHS', symbol: 'GH₵', name: 'Ghanaian Cedi', label: 'Ghana Cedis (GH₵)', flag: '🇬🇭' },
  NGN: { code: 'NGN', symbol: '₦', name: 'Nigerian Naira', label: 'Naira (₦)', flag: '🇳🇬' },
  XOF: { code: 'XOF', symbol: 'CFA', name: 'CFA Franc', label: 'CFA Franc (CFA)', flag: '🇹🇬' },
  USD: { code: 'USD', symbol: '$', name: 'US Dollar', label: 'US Dollar ($)', flag: '🇺🇸' },
  GBP: { code: 'GBP', symbol: '£', name: 'British Pound', label: 'Pound (£)', flag: '🇬🇧' },
  CAD: { code: 'CAD', symbol: 'CA$', name: 'Canadian Dollar', label: 'Canadian Dollar (CA$)', flag: '🇨🇦' },
  AUD: { code: 'AUD', symbol: 'A$', name: 'Australian Dollar', label: 'Australian Dollar (A$)', flag: '🇦🇺' },
  CNY: { code: 'CNY', symbol: '¥', name: 'Chinese Yuan', label: 'Chinese Yuan (¥)', flag: '🇨🇳' },
  INR: { code: 'INR', symbol: '₹', name: 'Indian Rupee', label: 'Indian Rupee (₹)', flag: '🇮🇳' },
  JPY: { code: 'JPY', symbol: '¥', name: 'Japanese Yen', label: 'Japanese Yen (¥)', flag: '🇯🇵' },
  EUR: { code: 'EUR', symbol: '€', name: 'Euro', label: 'Euro (€)', flag: '🇪🇺' },
  KRW: { code: 'KRW', symbol: '₩', name: 'South Korean Won', label: 'South Korean Won (₩)', flag: '🇰🇷' }
};

// Rates relative to 1 GHS (Ghanaian Cedi baseline)
export const RATES_RELATIVE_TO_GHS: Record<CurrencyCode, number> = {
  GHS: 1,
  NGN: 93.75,
  XOF: 37.5,
  USD: 0.0625, // $1 = 16 GHS
  GBP: 0.048,  // £1 = 20.8 GHS
  CAD: 0.088,  // CA$1 = 11.3 GHS
  AUD: 0.096,  // A$1 = 10.4 GHS
  CNY: 0.45,   // ¥1 = 2.2 GHS
  INR: 5.25,   // ₹1 = 0.19 GHS
  JPY: 9.8,    // ¥1 = 0.10 GHS
  EUR: 0.058,  // €1 = 17.2 GHS
  KRW: 86.5    // ₩1 = 0.011 GHS
};

/**
 * Maps country name to its default native currency code
 */
export function getNativeCurrencyForCountry(country?: string): CurrencyCode {
  if (!country) return 'GHS';
  const c = country.toLowerCase();
  if (c.includes('nigeria')) return 'NGN';
  if (c.includes('togo') || c.includes('ivoire') || c.includes('benin') || c.includes('cfa')) return 'XOF';
  if (c.includes('united kingdom') || c.includes('uk') || c.includes('pound')) return 'GBP';
  if (c.includes('canada')) return 'CAD';
  if (c.includes('australia')) return 'AUD';
  if (c.includes('china')) return 'CNY';
  if (c.includes('india')) return 'INR';
  if (c.includes('japan')) return 'JPY';
  if (c.includes('germany') || c.includes('france') || c.includes('euro')) return 'EUR';
  if (c.includes('korea')) return 'KRW';
  if (c.includes('usa') || c.includes('states') || c.includes('dollar')) return 'USD';
  return 'GHS';
}

/**
 * Converts a price from a listing's native currency/country into the target currency code
 */
export function convertPrice(
  amount: number,
  sourceCountryOrCode: string = 'Ghana',
  targetCurrencyCode: CurrencyCode = 'GHS'
): number {
  if (!amount || isNaN(amount)) return 0;
  
  // Determine source currency code
  let sourceCode: CurrencyCode = 'GHS';
  if (sourceCountryOrCode in CURRENCIES) {
    sourceCode = sourceCountryOrCode as CurrencyCode;
  } else {
    sourceCode = getNativeCurrencyForCountry(sourceCountryOrCode);
  }

  if (sourceCode === targetCurrencyCode) return amount;

  // Convert to GHS baseline first
  const sourceRate = RATES_RELATIVE_TO_GHS[sourceCode] || 1;
  const amountInGhs = amount / sourceRate;

  // Convert GHS baseline to target currency
  const targetRate = RATES_RELATIVE_TO_GHS[targetCurrencyCode] || 1;
  const converted = amountInGhs * targetRate;

  // Round nicely depending on currency scale
  if (targetCurrencyCode === 'USD') {
    return Math.round(converted);
  }
  return Math.round(converted);
}

/**
 * Returns formatted string representation of a price in target currency
 * e.g., "GH₵ 135,000", "₦ 12,656,250", "5,062,500 CFA", "$ 8,438"
 */
export function formatConvertedPrice(
  amount: number,
  sourceCountryOrCode: string = 'Ghana',
  targetCurrencyCode: CurrencyCode = 'GHS'
): string {
  const converted = convertPrice(amount, sourceCountryOrCode, targetCurrencyCode);
  const symbol = CURRENCIES[targetCurrencyCode]?.symbol || 'GH₵';
  const formattedNumber = converted.toLocaleString();

  if (targetCurrencyCode === 'XOF') {
    return `${formattedNumber} ${symbol}`;
  }
  return `${symbol} ${formattedNumber}`;
}
