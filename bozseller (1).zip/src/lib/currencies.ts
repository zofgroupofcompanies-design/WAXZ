import { Currency, CurrencyCode } from '../types';

export const SUPPORTED_CURRENCIES: Currency[] = [
  { code: 'USD', symbol: '$', name: 'US Dollar', rateToUsd: 1.0 },
  { code: 'EUR', symbol: '€', name: 'Euro', rateToUsd: 0.92 },
  { code: 'GBP', symbol: '£', name: 'British Pound', rateToUsd: 0.79 },
  { code: 'NGN', symbol: '₦', name: 'Nigerian Naira', rateToUsd: 1520.0 },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen', rateToUsd: 154.5 },
  { code: 'CAD', symbol: 'CA$', name: 'Canadian Dollar', rateToUsd: 1.38 },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar', rateToUsd: 1.52 },
];

export function getCurrency(code: CurrencyCode): Currency {
  return SUPPORTED_CURRENCIES.find(c => c.code === code) || SUPPORTED_CURRENCIES[0];
}

export function convertFromUsd(amountUsd: number, targetCode: CurrencyCode): number {
  const currency = getCurrency(targetCode);
  return amountUsd * currency.rateToUsd;
}

export function formatPrice(amountUsd: number, targetCode: CurrencyCode = 'USD'): string {
  const currency = getCurrency(targetCode);
  const converted = amountUsd * currency.rateToUsd;

  if (targetCode === 'JPY' || targetCode === 'NGN') {
    return `${currency.symbol}${Math.round(converted).toLocaleString()}`;
  }

  return `${currency.symbol}${converted.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}
