import { CarrierCode, CarrierQuote } from '../types';

export const CARRIERS: Record<CarrierCode, { name: string; logo: string; baseRateUsd: number; perKgRateUsd: number; daysMin: number; daysMax: number; carbonPerKg: number; trackingPrefix: string }> = {
  dhl: {
    name: 'DHL Express Worldwide',
    logo: '⚡ DHL',
    baseRateUsd: 28.50,
    perKgRateUsd: 8.50,
    daysMin: 2,
    daysMax: 4,
    carbonPerKg: 1.2,
    trackingPrefix: 'DHL-EXPRESS-'
  },
  fedex: {
    name: 'FedEx Priority International',
    logo: '📦 FedEx',
    baseRateUsd: 24.00,
    perKgRateUsd: 7.20,
    daysMin: 3,
    daysMax: 5,
    carbonPerKg: 1.4,
    trackingPrefix: 'FDX-GLOBAL-'
  },
  ups: {
    name: 'UPS Worldwide Saver',
    logo: '🛡️ UPS',
    baseRateUsd: 26.00,
    perKgRateUsd: 7.80,
    daysMin: 2,
    daysMax: 4,
    carbonPerKg: 1.3,
    trackingPrefix: 'UPS-SAVER-'
  },
  standard: {
    name: 'Global Postal Network (ePacket)',
    logo: '🌐 Standard',
    baseRateUsd: 9.99,
    perKgRateUsd: 3.50,
    daysMin: 7,
    daysMax: 14,
    carbonPerKg: 0.8,
    trackingPrefix: 'GPN-INTL-'
  }
};

export function calculateCarrierQuotes(totalWeightKg: number, destinationCountry: string): CarrierQuote[] {
  const weight = Math.max(0.5, totalWeightKg);

  // Apply international multiplier if country is outside US/EU
  const isIntercontinental = !['United States', 'Germany', 'United Kingdom', 'Canada'].includes(destinationCountry);
  const regionMultiplier = isIntercontinental ? 1.25 : 1.0;

  return Object.entries(CARRIERS).map(([code, config]) => {
    const calculatedRate = (config.baseRateUsd + (weight * config.perKgRateUsd)) * regionMultiplier;

    return {
      code: code as CarrierCode,
      name: config.name,
      logo: config.logo,
      estimatedDays: config.daysMin,
      rateUsd: Math.round(calculatedRate * 100) / 100,
      carbonFootprintKg: Math.round(weight * config.carbonPerKg * 10) / 10,
      trackingPrefix: config.trackingPrefix
    };
  });
}

export function generateTrackingNumber(carrierCode: CarrierCode): string {
  const carrier = CARRIERS[carrierCode] || CARRIERS.dhl;
  const randomDigits = Math.floor(100000000 + Math.random() * 900000000);
  return `${carrier.trackingPrefix}${randomDigits}`;
}

export function getTrackingTimeline(carrierCode: CarrierCode, trackingNumber: string, status: string) {
  const carrier = CARRIERS[carrierCode] || CARRIERS.dhl;

  return [
    { step: 1, title: 'Order Processed & Signed', location: 'Vendor Origin Facility', done: true, time: 'Oct 24, 10:15 AM' },
    { step: 2, title: `Package Handed to ${carrier.name}`, location: 'Origin Gateway Hub', done: ['shipped', 'in_transit', 'delivered'].includes(status), time: 'Oct 24, 02:30 PM' },
    { step: 3, title: 'Customs Clearance Completed', location: 'International Sorting Center', done: ['in_transit', 'delivered'].includes(status), time: 'Oct 25, 08:45 AM' },
    { step: 4, title: 'Out for Final Delivery', location: 'Destination Regional Depot', done: status === 'delivered', time: status === 'delivered' ? 'Oct 26, 09:10 AM' : 'Pending' }
  ];
}
