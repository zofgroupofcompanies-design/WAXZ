import { PaymentGateway } from '../types';

export interface PaymentOption {
  id: PaymentGateway;
  name: string;
  badge: string;
  description: string;
  regionsSupported: string[];
  icon: string;
}

export const PAYMENT_GATEWAYS: PaymentOption[] = [
  {
    id: 'stripe',
    name: 'Stripe International',
    badge: 'Global Credit / Apple Pay',
    description: 'Instant card processing in 135+ currencies with 3D Secure 2.0',
    regionsSupported: ['US', 'EU', 'UK', 'CA', 'AU', 'JP', 'Global'],
    icon: '💳'
  },
  {
    id: 'paystack',
    name: 'Paystack Merchant Direct',
    badge: 'Africa & Emerging Markets',
    description: 'Cards, Bank Transfer, USSD & QR code settlement in 24 hours',
    regionsSupported: ['NG', 'GH', 'KE', 'ZA', 'EG'],
    icon: '⚡'
  },
  {
    id: 'flutterwave',
    name: 'Flutterwave Global Gateway',
    badge: 'Mobile Money & SWIFT Wire',
    description: 'M-Pesa, MTN MoMo, Airtel Money, and cross-border bank wire',
    regionsSupported: ['Africa', 'UK', 'US', 'LATAM'],
    icon: '🌍'
  },
  {
    id: 'crypto_escrow',
    name: 'Encrypted Crypto Escrow',
    badge: 'Zero-Knowledge Trustless Vault',
    description: 'Smart contract escrow released only after carrier delivery confirmation',
    regionsSupported: ['Global Unlimited'],
    icon: '🔒'
  }
];

export async function processPaymentSimulation(
  gateway: PaymentGateway,
  amountUsd: number,
  currencyCode: string
): Promise<{ success: boolean; transactionReference: string; gatewayMessage: string }> {
  // Simulate network delay for payment verification
  await new Promise(resolve => setTimeout(resolve, 1200));

  const refPrefix = gateway.toUpperCase().slice(0, 4);
  const randomRef = Math.random().toString(36).substring(2, 10).toUpperCase();
  const txRef = `TX_${refPrefix}_${randomRef}`;

  return {
    success: true,
    transactionReference: txRef,
    gatewayMessage: `Verified payment of $${amountUsd.toFixed(2)} USD via ${gateway.toUpperCase()} Gateway.`
  };
}
