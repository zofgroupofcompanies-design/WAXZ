import { Category, Listing, UserProfile } from '../types';

export const COUNTRIES_CONFIG: Record<string, { currency: string; phoneCode: string; flag: string; regions: Record<string, string[]> }> = {
  'Ghana': {
    currency: 'GH₵',
    phoneCode: '+233',
    flag: '🇬🇭',
    regions: {
      'Greater Accra': ['East Legon', 'Osu', 'Cantonments', 'Circle', 'Spintex', 'Madina', 'Dansoman', 'Achimota', 'Legon', 'Tema'],
      'Ashanti': ['Adum', 'Bantama', 'KNUST', 'Nhyiaeso', 'Asokwa', 'Tafo', 'Patasi', 'Kumasi Central'],
      'Western': ['Takoradi', 'Sekondi', 'Effiakuma', 'Anaji'],
      'Central': ['Cape Coast', 'Kasoa', 'Winneba', 'Elmina'],
      'Eastern': ['Koforidua', 'Nkawkaw', 'Aburi'],
      'Volta': ['Ho', 'Aflao', 'Kpando'],
      'Northern': ['Tamale', 'Sagnarigu']
    }
  },
  'Nigeria': {
    currency: '₦',
    phoneCode: '+234',
    flag: '🇳🇬',
    regions: {
      'Lagos': ['Ikeja', 'Lekki', 'Victoria Island', 'Surulere', 'Yaba', 'Gbagada', 'Ikoyi', 'Festac'],
      'Abuja FCT': ['Wuse', 'Maitama', 'Gwarinpa', 'Asokoro', 'Garki', 'Apo'],
      'Rivers': ['GRA Phase 2', 'Rumuokoro', 'Trans Amadi', 'D-Line'],
      'Oyo': ['Bodija', 'Ring Road', 'Akobo', 'Iyaganku'],
      'Kano': ['Fagge', 'Nassarawa', 'Tarauni']
    }
  },
  'Togo': {
    currency: 'CFA',
    phoneCode: '+228',
    flag: '🇹🇬',
    regions: {
      'Maritime (Lomé)': ['Nyékonakpoé', 'Tokoin', 'Kodjoviakopé', 'Hedzranawoé', 'Bé', 'Baguida', 'Adidogomé'],
      'Plateaux': ['Kpalimé', 'Atakpamé', 'Notsé'],
      'Centrale': ['Sokodé', 'Tchamba'],
      'Kara': ['Kara', 'Bafilo'],
      'Savanes': ['Dapaong', 'Mango']
    }
  },
  'Côte d\'Ivoire': {
    currency: 'CFA',
    phoneCode: '+225',
    flag: '🇨🇮',
    regions: {
      'Abidjan': ['Cocody', 'Le Plateau', 'Marcory', 'Yopougon', 'Treichville', 'Abobo', 'Bietry'],
      'Yamoussoukro': ['N\'Gokro', 'Fondation', 'Quartier Residentiel'],
      'San-Pédro': ['Zone Industrielle', 'Bardot', 'Cité Portuaire'],
      'Bouaké': ['Air France', 'Koko', 'Nimbo']
    }
  },
  'United States': {
    currency: '$',
    phoneCode: '+1',
    flag: '🇺🇸',
    regions: {
      'New York': ['Manhattan', 'Brooklyn', 'Queens', 'Albany', 'Buffalo'],
      'California': ['Los Angeles', 'San Francisco', 'San Jose', 'San Diego', 'Sacramento'],
      'Texas': ['Houston', 'Dallas', 'Austin', 'San Antonio'],
      'Florida': ['Miami', 'Orlando', 'Tampa', 'Jacksonville'],
      'Illinois': ['Chicago', 'Naperville', 'Springfield']
    }
  },
  'United Kingdom': {
    currency: '£',
    phoneCode: '+44',
    flag: '🇬🇧',
    regions: {
      'Greater London': ['Greenwich', 'Camden', 'Kensington', 'Westminster', 'Croydon'],
      'West Midlands': ['Birmingham', 'Coventry', 'Wolverhampton'],
      'Greater Manchester': ['Manchester City Centre', 'Salford', 'Stockport'],
      'Scotland': ['Edinburgh', 'Glasgow', 'Aberdeen']
    }
  },
  'Canada': {
    currency: 'CA$',
    phoneCode: '+1',
    flag: '🇨🇦',
    regions: {
      'Ontario': ['Toronto', 'Ottawa', 'Mississauga', 'Brampton'],
      'Quebec': ['Montreal', 'Quebec City', 'Laval'],
      'British Columbia': ['Vancouver', 'Surrey', 'Victoria'],
      'Alberta': ['Calgary', 'Edmonton']
    }
  },
  'Australia': {
    currency: 'A$',
    phoneCode: '+61',
    flag: '🇦🇺',
    regions: {
      'New South Wales': ['Sydney CBD', 'Parramatta', 'Newcastle'],
      'Victoria': ['Melbourne CBD', 'Geelong', 'Ballarat'],
      'Queensland': ['Brisbane', 'Gold Coast', 'Cairns'],
      'Western Australia': ['Perth', 'Fremantle']
    }
  },
  'China': {
    currency: '¥',
    phoneCode: '+86',
    flag: '🇨🇳',
    regions: {
      'Guangdong': ['Guangzhou', 'Shenzhen', 'Foshan', 'Dongguan'],
      'Zhejiang': ['Hangzhou', 'Ningbo', 'Yiwu'],
      'Shanghai': ['Pudong', 'Huangpu', 'Jing\'an'],
      'Beijing': ['Chaoyang', 'Haidian', 'Dongcheng']
    }
  },
  'India': {
    currency: '₹',
    phoneCode: '+91',
    flag: '🇮🇳',
    regions: {
      'Maharashtra': ['Mumbai', 'Pune', 'Nagpur'],
      'Delhi NCR': ['New Delhi', 'Gurugram', 'Noida'],
      'Karnataka': ['Bengaluru', 'Mysuru'],
      'Tamil Nadu': ['Chennai', 'Coimbatore']
    }
  },
  'Japan': {
    currency: '¥',
    phoneCode: '+81',
    flag: '🇯🇵',
    regions: {
      'Tokyo': ['Shinjuku', 'Shibuya', 'Ginza', 'Akihabara', 'Minato'],
      'Osaka': ['Umeda', 'Namba', 'Shinsaibashi'],
      'Kanagawa': ['Yokohama', 'Kawasaki']
    }
  },
  'Germany': {
    currency: '€',
    phoneCode: '+49',
    flag: '🇩🇪',
    regions: {
      'Bavaria': ['Munich', 'Nuremberg', 'Augsburg'],
      'Berlin': ['Mitte', 'Kreuzberg', 'Charlottenburg'],
      'North Rhine-Westphalia': ['Cologne', 'Düsseldorf', 'Dortmund'],
      'Hesse': ['Frankfurt am Main', 'Wiesbaden']
    }
  },
  'France': {
    currency: '€',
    phoneCode: '+33',
    flag: '🇫🇷',
    regions: {
      'Île-de-France': ['Paris 8th', 'La Défense', 'Boulogne-Billancourt', 'Versailles'],
      'Provence-Alpes-Côte d\'Azur': ['Marseille', 'Nice', 'Cannes'],
      'Auvergne-Rhône-Alpes': ['Lyon', 'Grenoble']
    }
  },
  'South Korea': {
    currency: '₩',
    phoneCode: '+82',
    flag: '🇰🇷',
    regions: {
      'Seoul Capital Area': ['Gangnam', 'Hongdae', 'Myeongdong', 'Yeouido'],
      'Gyeonggi': ['Suwon', 'Seongnam', 'Goyang'],
      'Busan': ['Haeundae', 'Seomyen']
    }
  }
};

export const COUNTRIES = Object.keys(COUNTRIES_CONFIG);

export const CATEGORIES: Category[] = [
  { id: 'cat-1', name: 'Vehicles', icon: 'Car', slug: 'vehicles', adCount: 4230 },
  { id: 'cat-2', name: 'Phones & Tablets', icon: 'Smartphone', slug: 'phones-tablets', adCount: 5120 },
  { id: 'cat-3', name: 'Electronics', icon: 'Laptop', slug: 'electronics', adCount: 3890 },
  { id: 'cat-4', name: 'Real Estate', icon: 'Home', slug: 'real-estate', adCount: 1980 },
  { id: 'cat-5', name: 'Home, Furniture & Appliances', icon: 'Sofa', slug: 'home-furniture', adCount: 2450 },
  { id: 'cat-6', name: 'Fashion & Clothing', icon: 'Shirt', slug: 'fashion-clothing', adCount: 6240 },
  { id: 'cat-7', name: 'Health & Beauty', icon: 'Sparkles', slug: 'health-beauty', adCount: 1750 },
  { id: 'cat-8', name: 'Jobs & Services', icon: 'Briefcase', slug: 'jobs-services', adCount: 1120 },
  { id: 'cat-9', name: 'Animals & Pets', icon: 'Dog', slug: 'animals-pets', adCount: 820 }
];

export const CURRENT_USER: UserProfile = {
  id: 'usr-current',
  name: 'Kofi Ofori',
  email: 'kofi.ofori@example.com',
  phone: '0242866658',
  location: 'East Legon, Accra',
  rating: 4.8,
  reputationScore: 98.8,
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
  joinedDate: 'March 2024',
  verified: true
};

export const INITIAL_LISTINGS: Listing[] = [
  // GHANA LISTINGS
  {
    id: 'list-1',
    title: 'Toyota Corolla 2018 SE (Registered)',
    categoryId: 'cat-1',
    categoryName: 'Vehicles',
    subCategory: 'Cars',
    description: 'Very neat and fuel-efficient Toyota Corolla 2018 SE for sale. It features keyless entry, standard reverse camera, lane departure alert, pre-collision warning, and cool air conditioning system. Clean interior, automatic transmission. Engine and gearbox are in perfect condition. Accident-free, just buy and drive!',
    price: 135000,
    isNegotiable: true,
    condition: 'Used',
    country: 'Ghana',
    region: 'Greater Accra',
    neighborhood: 'East Legon',
    imageUrls: [
      'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1617531653332-bd46c24f2068?auto=format&fit=crop&w=600&q=80'
    ],
    sellerName: 'Emmanuel Boateng',
    sellerPhone: '+233 55 123 4567',
    sellerWhatsApp: '+233 55 123 4567',
    createdAt: '2026-07-27T10:30:00.000Z',
    views: 142,
    isFeatured: true,
    sellerId: 'usr-1',
    status: 'active',
    expiryDate: '2026-08-01T23:30:00.000Z'
  },
  {
    id: 'list-2',
    title: 'iPhone 15 Pro Max 256GB - Natural Titanium',
    categoryId: 'cat-2',
    categoryName: 'Phones & Tablets',
    subCategory: 'Mobile Phones',
    description: 'Selling my personal iPhone 15 Pro Max, Natural Titanium color, 256GB storage. Battery health is 96%. It has absolutely no scratches or marks, always used with a high-quality case and tempered glass screen protector. Face ID, TrueTone, and cameras work perfectly. Comes with box and original Apple USB-C cable.',
    price: 13900,
    isNegotiable: false,
    condition: 'Used',
    country: 'Ghana',
    region: 'Greater Accra',
    neighborhood: 'Circle',
    imageUrls: [
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=600&q=80'
    ],
    sellerName: 'Amma Owusu',
    sellerPhone: '+233 24 987 6543',
    sellerWhatsApp: '+233 24 987 6543',
    createdAt: '2026-07-28T01:15:00.000Z',
    views: 89,
    isFeatured: true,
    sellerId: 'usr-2',
    status: 'active',
    expiryDate: '2026-08-02T18:45:00.000Z'
  },
  {
    id: 'list-3',
    title: 'Luxury 2 Bedroom Furnished Apartment',
    categoryId: 'cat-4',
    categoryName: 'Real Estate',
    subCategory: 'Apartments for Rent',
    description: 'Stunning 2 bedroom, 2.5 bathroom apartment located in the serene neighborhoods of Cantonments. Features: fully fitted modern kitchen, spacious open-plan living room, rooftop swimming pool, fully equipped gymnasium, 24/7 security patrol, standby backup generator, water reservoir. Perfect for expats, professionals, or short stays.',
    price: 24000,
    isNegotiable: true,
    condition: 'New',
    country: 'Ghana',
    region: 'Greater Accra',
    neighborhood: 'Cantonments',
    imageUrls: [
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=600&q=80'
    ],
    sellerName: 'GoldKey Realty',
    sellerPhone: '+233 30 224 5566',
    sellerWhatsApp: '+233 20 888 9900',
    createdAt: '2026-07-25T14:20:00.000Z',
    views: 310,
    isFeatured: true,
    sellerId: 'usr-3',
    status: 'active'
  },

  // NIGERIA LISTINGS
  {
    id: 'list-ng-1',
    title: 'Lexus RX 350 2020 Model F-Sport (Foreign Used)',
    categoryId: 'cat-1',
    categoryName: 'Vehicles',
    subCategory: 'Cars',
    description: 'Extremely clean Tokunbo Lexus RX 350 2020 F-Sport. Silver on red leather interior. Panoramic roof, lane assist, blind-spot monitoring, 12.3-inch display screen, navigation, dual climate control, backup camera. Custom duties fully paid with Lagos port clearance documents intact. Perfect ride, no issues at all.',
    price: 36000000,
    isNegotiable: true,
    condition: 'Used',
    country: 'Nigeria',
    region: 'Lagos',
    neighborhood: 'Lekki',
    imageUrls: [
      'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=600&q=80'
    ],
    sellerName: 'Chidi Auto Ventures',
    sellerPhone: '+234 803 111 2222',
    sellerWhatsApp: '+234 803 111 2222',
    createdAt: '2026-07-27T18:30:00.000Z',
    views: 245,
    isFeatured: true,
    sellerId: 'usr-ng-1',
    status: 'active'
  },
  {
    id: 'list-ng-2',
    title: 'Samsung Galaxy S24 Ultra 512GB (Titanium Gray)',
    categoryId: 'cat-2',
    categoryName: 'Phones & Tablets',
    subCategory: 'Mobile Phones',
    description: 'Brand new factory sealed Samsung Galaxy S24 Ultra 512GB. Titanium Gray color. Includes international warranty card. Box comes with original charging cord and manual. S-Pen, 200MP camera, AI features fully supported. Legit receipt will be provided on purchase. Location is computer village Ikeja.',
    price: 1550000,
    isNegotiable: false,
    condition: 'New',
    country: 'Nigeria',
    region: 'Lagos',
    neighborhood: 'Ikeja',
    imageUrls: [
      'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?auto=format&fit=crop&w=600&q=80'
    ],
    sellerName: 'Alaba Electronics Plaza',
    sellerPhone: '+234 812 333 4444',
    sellerWhatsApp: '+234 812 333 4444',
    createdAt: '2026-07-28T02:00:00.000Z',
    views: 120,
    isFeatured: true,
    sellerId: 'usr-ng-2',
    status: 'active',
    expiryDate: '2026-07-31T22:15:00.000Z'
  },
  {
    id: 'list-ng-3',
    title: 'Fully Serviced 3 Bedroom Duplex with BQ',
    categoryId: 'cat-4',
    categoryName: 'Real Estate',
    subCategory: 'Houses for Rent',
    description: 'Exquisite 3 bedroom semi-detached duplex for rent in a gated estate in Wuse 2. Fully fitted kitchen, massive living room, luxury bathrooms, boy\'s quarters (BQ), reliable 24h water supply, dedicated compound parking spaces, tight 24/7 security. Contact for booking an inspection.',
    price: 8500000,
    isNegotiable: true,
    condition: 'New',
    country: 'Nigeria',
    region: 'Abuja FCT',
    neighborhood: 'Wuse',
    imageUrls: [
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=600&q=80'
    ],
    sellerName: 'Maitama Properties Ltd',
    sellerPhone: '+234 905 555 6666',
    sellerWhatsApp: '+234 905 555 6666',
    createdAt: '2026-07-26T09:15:00.000Z',
    views: 175,
    isFeatured: false,
    sellerId: 'usr-ng-3',
    status: 'active'
  },

  // TOGO LISTINGS
  {
    id: 'list-tg-1',
    title: 'Moto Yamaha SMAX 155cc (Presque neuve)',
    categoryId: 'cat-1',
    categoryName: 'Vehicles',
    subCategory: 'Motorcycles',
    description: 'Moto Yamaha SMAX 155cc à vendre à Lomé. Très faible kilométrage, parfait état mécanique, moteur puissant et robuste, vidange faite régulièrement. Idéal pour circuler rapidement en ville. Papier d\'immatriculation togolais disponible et en règle. Prix négociable devant la moto.',
    price: 1200000,
    isNegotiable: true,
    condition: 'Used',
    country: 'Togo',
    region: 'Maritime (Lomé)',
    neighborhood: 'Nyékonakpoé',
    imageUrls: [
      'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=600&q=80'
    ],
    sellerName: 'Koffi Moto Lomé',
    sellerPhone: '+228 90 12 34 56',
    sellerWhatsApp: '+228 90 12 34 56',
    createdAt: '2026-07-27T11:00:00.000Z',
    views: 64,
    isFeatured: true,
    sellerId: 'usr-tg-1',
    status: 'active'
  },
  {
    id: 'list-tg-2',
    title: 'MacBook Pro M2 8GB/256GB - Gris Sidéral',
    categoryId: 'cat-3',
    categoryName: 'Electronics',
    subCategory: 'Laptops & Computers',
    description: 'À vendre MacBook Pro puce M2, 8Go RAM, SSD 256Go. Couleur Gris Sidéral. Clavier AZERTY d\'origine. Santé de la batterie à 94%, tient très bien la charge. Aucun choc ni rayure sur l\'écran. Livré avec son chargeur d\'origine USB-C de 67W et sa boîte d\'origine. Disponible à Lomé Hedzranawoé.',
    price: 650000,
    isNegotiable: false,
    condition: 'Refurbished',
    country: 'Togo',
    region: 'Maritime (Lomé)',
    neighborhood: 'Hedzranawoé',
    imageUrls: [
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=600&q=80'
    ],
    sellerName: 'Lomé Tech Solutions',
    sellerPhone: '+228 99 88 77 66',
    sellerWhatsApp: '+228 99 88 77 66',
    createdAt: '2026-07-28T03:00:00.000Z',
    views: 48,
    isFeatured: false,
    sellerId: 'usr-tg-2',
    status: 'active'
  }
];
