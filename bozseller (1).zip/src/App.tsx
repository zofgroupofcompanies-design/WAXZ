import { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Sparkles, HelpCircle, ShieldCheck, Shield, Heart, Grid, Search, SlidersHorizontal, WifiOff, Wifi, X, Home, PlusCircle, MessageSquare, User, Trophy } from 'lucide-react';
import Header from './components/Header';
import CategoriesList from './components/CategoriesList';
import ListingCard from './components/ListingCard';
import SidebarFilters from './components/SidebarFilters';
import ListingDetail from './components/ListingDetail';
import PostAdModal from './components/PostAdModal';
import ChatDrawer from './components/ChatDrawer';
import Dashboard from './components/Dashboard';
import AdminDashboard from './components/AdminDashboard';
import SavedAds from './components/SavedAds';
import TopSellers from './components/TopSellers';
import AuthModal from './components/AuthModal';
import SubscriptionModal from './components/SubscriptionModal';
import { Listing, ChatSession, AuthUser } from './types';
import { COUNTRIES_CONFIG } from './data/mockData';
import { CurrencyCode, CURRENCIES } from './utils/currency';


export default function App() {
  // Navigation / Tabs
  const [activeTab, setActiveTab] = useState<'feed' | 'dashboard' | 'saved' | 'top-sellers'>('feed');
  const [isAdminMode, setIsAdminMode] = useState(false);
  
  // Header Filters & Currency
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('Ghana');
  const [selectedRegion, setSelectedRegion] = useState('All Ghana');
  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyCode>(() => {
    const saved = localStorage.getItem('dosboz_selected_currency');
    return (saved as CurrencyCode) || 'GHS';
  });

  useEffect(() => {
    localStorage.setItem('dosboz_selected_currency', selectedCurrency);
  }, [selectedCurrency]);

  // Authentication State
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(() => {
    const savedUser = localStorage.getItem('datazone4_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  useEffect(() => {
    const token = localStorage.getItem('datazone4_jwt_token');
    if (token) {
      fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` }
      })
        .then(res => res.ok ? res.json() : Promise.reject(res))
        .then(data => {
          if (data.user) {
            setCurrentUser(data.user);
            localStorage.setItem('datazone4_user', JSON.stringify(data.user));
          }
        })
        .catch(() => {
          // Token expired or invalid
          localStorage.removeItem('datazone4_jwt_token');
          localStorage.removeItem('datazone4_user');
          setCurrentUser(null);
        });
    }
  }, []);

  const handleAuthSuccess = (user: AuthUser, token: string) => {
    setCurrentUser(user);
    localStorage.setItem('datazone4_user', JSON.stringify(user));
    localStorage.setItem('datazone4_jwt_token', token);
    if (user.role === 'admin') {
      setIsAdminMode(true);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('datazone4_jwt_token');
    localStorage.removeItem('datazone4_user');
    setIsAdminMode(false);
    setAuthModalOpen(false);
  };


  
  // Sidebar Filters
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedCondition, setSelectedCondition] = useState('All');
  const [minPrice, setMinPrice] = useState<number | ''>('');
  const [maxPrice, setMaxPrice] = useState<number | ''>('');
  const [sortBy, setSortBy] = useState('newest');

  // Trigger state to refresh lists
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Core Listings state
  const [listings, setListings] = useState<Listing[]>([]);
  const [listingsLoading, setListingsLoading] = useState(true);

  // Favorites (Saved Ads) list
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('dosboz_gh_favorites');
    return saved ? JSON.parse(saved) : [];
  });

  // Active Chats notification count
  const [unreadChatsCount, setUnreadChatsCount] = useState(0);

  // Modal Triggers
  const [postAdOpen, setPostAdOpen] = useState(false);
  const [selectedListingId, setSelectedListingId] = useState<string | null>(null);
  const [chatDrawerOpen, setChatDrawerOpen] = useState(false);
  const [chatActiveListing, setChatActiveListing] = useState<Listing | null>(null);
  const [subscriptionModalOpen, setSubscriptionModalOpen] = useState(false);


  // Network connection states for global Toast
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [showToast, setShowToast] = useState(false);
  const [toastType, setToastType] = useState<'offline' | 'online'>('offline');

  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      setToastType('online');
      setShowToast(true);
      const timer = setTimeout(() => {
        setShowToast(false);
      }, 4000);
      return () => clearTimeout(timer);
    };

    const handleOffline = () => {
      setIsOffline(true);
      setToastType('offline');
      setShowToast(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // If already offline on mount, show the warning toast
    if (!navigator.onLine) {
      setIsOffline(true);
      setToastType('offline');
      setShowToast(true);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Save favorites to localStorage
  useEffect(() => {
    localStorage.setItem('dosboz_gh_favorites', JSON.stringify(favorites));
  }, [favorites]);

  // Sync selectedRegion when selectedCountry changes
  useEffect(() => {
    setSelectedRegion(`All ${selectedCountry}`);
  }, [selectedCountry]);

  // Fetch Listings dynamically with active filters
  useEffect(() => {
    setListingsLoading(true);
    const params = new URLSearchParams();
    
    // Country-aware filter
    params.append('country', selectedCountry);
    
    if (searchQuery) params.append('search', searchQuery);
    if (selectedCategory) params.append('categoryId', selectedCategory);
    if (selectedRegion && selectedRegion !== `All ${selectedCountry}`) params.append('region', selectedRegion);
    if (selectedCondition && selectedCondition !== 'All') params.append('condition', selectedCondition);
    if (minPrice !== '') params.append('minPrice', minPrice.toString());
    if (maxPrice !== '') params.append('maxPrice', maxPrice.toString());
    params.append('sortBy', sortBy);

    fetch(`/api/listings?${params.toString()}`)
      .then(res => res.json())
      .then((data: Listing[]) => {
        setListings(data);
        setListingsLoading(false);
      })
      .catch(err => {
        console.error('Error fetching listings:', err);
        setListingsLoading(false);
      });
  }, [selectedCountry, searchQuery, selectedCategory, selectedRegion, selectedCondition, minPrice, maxPrice, sortBy, refreshTrigger]);

  // Poll chat sessions for notification badges
  useEffect(() => {
    const fetchUnread = () => {
      fetch('/api/chats?userId=usr-current')
        .then(res => res.json())
        .then((data: ChatSession[]) => {
          // Unread is mock based on sessions with messages where the last sender is not Kofi (current user)
          const unread = data.filter(sess => {
            const lastMsg = sess.messages[sess.messages.length - 1];
            return lastMsg && lastMsg.senderId !== 'usr-current';
          }).length;
          setUnreadChatsCount(unread);
        })
        .catch(err => console.error('Failed to poll unread counts:', err));
    };

    fetchUnread();
    const interval = setInterval(fetchUnread, 3000);
    return () => clearInterval(interval);
  }, []);

  // Toggles Favorites
  const handleToggleFavorite = (id: string) => {
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(fId => fId !== id) : [...prev, id]
    );
  };

  // Triggers In-App negotiation chat session
  const handleInitiateChat = (listing: Listing) => {
    setChatActiveListing(listing);
    setChatDrawerOpen(true);
  };

  // Resets filters
  const handleClearFilters = () => {
    setSelectedCondition('All');
    setMinPrice('');
    setMaxPrice('');
    setSortBy('newest');
    setSelectedCategory(null);
    setSearchQuery('');
    setSelectedRegion(`All ${selectedCountry}`);
  };

  return (
    <div className="min-h-screen bg-[#f0faf3] flex flex-col font-sans antialiased text-gray-800 pb-20">
      
      {/* HEADER COMPONENT */}
      <Header
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        selectedCountry={selectedCountry}
        setSelectedCountry={setSelectedCountry}
        selectedRegion={selectedRegion}
        setSelectedRegion={setSelectedRegion}
        selectedCurrency={selectedCurrency}
        setSelectedCurrency={setSelectedCurrency}
        onPostAdClick={() => setPostAdOpen(true)}
        onDashboardClick={() => {
          setIsAdminMode(false);
          setActiveTab('dashboard');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onSavedClick={() => {
          setIsAdminMode(false);
          setActiveTab('saved');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onTopSellersClick={() => {
          setIsAdminMode(false);
          setActiveTab('top-sellers');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onChatsClick={() => setChatDrawerOpen(true)}
        onLogoClick={() => {
          setIsAdminMode(false);
          setActiveTab('feed');
          handleClearFilters();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        favoritesCount={favorites.length}
        unreadChatsCount={unreadChatsCount}
        onAdminClick={() => {
          setIsAdminMode(prev => !prev);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        isAdminMode={isAdminMode}
        currentUser={currentUser}
        onAuthClick={() => setAuthModalOpen(true)}
      />

      {isAdminMode ? (
        <AdminDashboard
          onViewDetails={(id) => setSelectedListingId(id)}
          refreshTrigger={refreshTrigger}
        />
      ) : activeTab === 'feed' ? (
        /* ==================== FEED TAB VIEW ==================== */
        <main className="flex-1 flex flex-col">
          {/* Hero Promo Banner (Dynamic Country style) */}
          <div className="w-full bg-linear-to-r from-[#3e3023] to-[#7a5e45] text-white py-8 sm:py-12 px-4 sm:px-6 lg:px-8 border-b border-green-900 relative overflow-hidden">
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
              <div className="flex flex-col gap-2.5 max-w-xl text-center md:text-left">
                <span className="bg-[#b08865] text-white font-black text-[10px] tracking-widest px-3 py-1 rounded-full w-fit mx-auto md:mx-0 uppercase font-bold">
                  {selectedCountry.toUpperCase()}'S FASTEST MARKETPLACE
                </span>
                <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
                  Buy & Sell Everything <br className="hidden sm:inline" />
                  Instantly in {selectedCountry} {COUNTRIES_CONFIG[selectedCountry]?.flag || '🇬🇭'}
                </h1>
                <p className="text-xs sm:text-sm text-green-100 font-semibold leading-relaxed">
                  Connect with verified buyers and sellers in {Object.keys(COUNTRIES_CONFIG[selectedCountry]?.regions || {}).slice(0, 4).join(', ')}. Use our AI Assistant to draft perfect descriptions and estimate prices!
                </p>
              </div>

              {/* Quick statistics badge */}
              <div className="flex gap-4 sm:gap-6 flex-wrap justify-center shrink-0">
                <div className="bg-white/10 backdrop-blur-md border border-white/10 rounded-2xl px-5 py-4 text-center">
                  <span className="text-xl sm:text-2xl font-black text-yellow-300 tracking-tight">15,000+</span>
                  <span className="text-[10px] text-green-100 font-bold uppercase tracking-wider mt-1 block">Live Listings</span>
                </div>
                <div className="bg-white/10 backdrop-blur-md border border-white/10 rounded-2xl px-5 py-4 text-center">
                  <span className="text-xl sm:text-2xl font-black text-yellow-300 tracking-tight">24h</span>
                  <span className="text-[10px] text-green-100 font-bold uppercase tracking-wider mt-1 block">AI Ad Assistant</span>
                </div>
              </div>
            </div>

            {/* Aesthetic accent backgrounds */}
            <div className="absolute -right-20 -bottom-20 w-80 h-80 rounded-full bg-[#b08865]/10 filter blur-2xl select-none" />
          </div>

          {/* CATEGORIES HORIZONTAL GRIDS */}
          <CategoriesList
            activeCategoryId={selectedCategory}
            onSelectCategory={(id) => {
              setSelectedCategory(id);
              window.scrollTo({ top: 380, behavior: 'smooth' });
            }}
          />

          {/* MAIN GRID LAYOUT WITH SIDEBAR */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col lg:flex-row gap-6 flex-1 w-full">
            {/* LEFT COLUMN: FILTER CONTROLS SIDEBAR */}
            <SidebarFilters
              selectedCondition={selectedCondition}
              setSelectedCondition={setSelectedCondition}
              minPrice={minPrice}
              setMinPrice={setMinPrice}
              maxPrice={maxPrice}
              setMaxPrice={setMaxPrice}
              sortBy={sortBy}
              setSortBy={setSortBy}
              onClearFilters={handleClearFilters}
              currencySymbol={CURRENCIES[selectedCurrency]?.symbol || 'GH₵'}
            />

            {/* RIGHT COLUMN: ADS GRID FEED */}
            <div className="flex-1 flex flex-col gap-6">
              {/* Filter Active State Display Header */}
              <div className="flex items-center justify-between pb-3.5 border-b border-gray-100">
                <div className="flex flex-col gap-1">
                  <h3 className="font-extrabold text-gray-800 text-sm flex items-center gap-2">
                    <Grid className="w-4.5 h-4.5 text-[#b08865]" />
                    <span>Trending Listings</span>
                  </h3>
                  {searchQuery && (
                    <span className="text-xs text-gray-400 font-semibold">
                      Results for "{searchQuery}" in {selectedRegion}
                    </span>
                  )}
                </div>

                <span className="text-xs font-semibold text-gray-400 bg-gray-100 px-2.5 py-1 rounded-full">
                  {listings.length} classifieds found
                </span>
              </div>

              {/* GRID FEED COMPONENT */}
              {listingsLoading ? (
                /* Skeleton Loading Loader */
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5 flex-1">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="bg-white rounded-xl border border-gray-100 p-3 flex flex-col gap-3 animate-pulse h-[340px]">
                      <div className="w-full aspect-4/3 bg-gray-100 rounded-lg shrink-0"></div>
                      <div className="w-2/3 h-4 bg-gray-100 rounded"></div>
                      <div className="w-1/2 h-5 bg-gray-100 rounded"></div>
                      <div className="w-full h-8 bg-gray-100 rounded mt-auto"></div>
                    </div>
                  ))}
                </div>
              ) : listings.length === 0 ? (
                /* No Results State */
                <div className="bg-white rounded-xl border border-gray-100 p-12 text-center flex flex-col items-center justify-center flex-1 min-h-[300px]">
                  <Search className="text-gray-300 w-12 h-12 mb-3" />
                  <h4 className="font-bold text-gray-700 text-base mb-1">No Ads Match Your Filters</h4>
                  <p className="text-xs text-gray-400 max-w-sm mb-4 leading-relaxed">
                    Try softening your keywords, adjusting your price limits, or broadening your region boundaries.
                  </p>
                  <button
                    onClick={handleClearFilters}
                    className="bg-[#b08865] hover:bg-[#937153] text-white font-bold text-xs px-4 py-2 rounded-lg cursor-pointer transition shadow-xs"
                  >
                    Reset Search & Filters
                  </button>
                </div>
              ) : (
                /* Main Ad Cards Grid */
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
                  {listings.map(ad => (
                    <div key={ad.id} className="h-full">
                      <ListingCard
                        listing={ad}
                        isFavorite={favorites.includes(ad.id)}
                        onToggleFavorite={(e) => {
                          e.stopPropagation();
                          handleToggleFavorite(ad.id);
                        }}
                        onViewDetails={() => setSelectedListingId(ad.id)}
                        onChatClick={(e) => {
                          e.stopPropagation();
                          handleInitiateChat(ad);
                        }}
                        selectedCurrency={selectedCurrency}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </main>
      ) : activeTab === 'top-sellers' ? (
        /* ==================== TOP SELLERS LEADERBOARD VIEW ==================== */
        <TopSellers
          selectedCurrency={selectedCurrency}
          onViewListing={(id) => setSelectedListingId(id)}
          onInitiateChat={handleInitiateChat}
          onBrowseSellerProducts={(sellerId, sellerName) => {
            setActiveTab('feed');
            setSearchQuery(sellerName);
            window.scrollTo({ top: 380, behavior: 'smooth' });
          }}
        />
      ) : activeTab === 'saved' ? (
        /* ==================== SAVED ADS TAB VIEW ==================== */
        <SavedAds
          favorites={favorites}
          onToggleFavorite={handleToggleFavorite}
          onViewDetails={(id) => setSelectedListingId(id)}
          onInitiateChat={handleInitiateChat}
          selectedCurrency={selectedCurrency}
          onBrowseClick={() => {
            setActiveTab('feed');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
      ) : (
        /* ==================== DASHBOARD TAB VIEW ==================== */
        <Dashboard
          onViewDetails={(id) => setSelectedListingId(id)}
          onOpenChats={() => setChatDrawerOpen(true)}
          onPostAdClick={() => setPostAdOpen(true)}
          refreshTrigger={refreshTrigger}
          selectedCurrency={selectedCurrency}
          onOpenSubscription={() => setSubscriptionModalOpen(true)}
        />
      )}

      {/* FOOTER BRANDS */}
      <footer className="bg-[#291f17] text-white py-12 border-t border-green-950 shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="flex flex-col gap-3">
            <div className="bg-[#b08865] text-white px-3 py-1.5 rounded-lg font-black tracking-tight text-xl w-fit flex items-center shadow-inner select-none">
              <span>datazone4</span>
            </div>
            <p className="text-[11px] text-green-200/70 font-medium leading-relaxed">
              datazone4 classifieds marketplace providing free posting, verified buyers, in-app messaging, and a robust Gemini AI Posting assistant across Ghana, Nigeria, and Togo.
            </p>
          </div>

          <div>
            <h4 className="text-xs font-black text-yellow-400 uppercase tracking-widest mb-4">Hot categories</h4>
            <ul className="text-xs text-green-200/80 font-medium flex flex-col gap-2.5">
              <li className="hover:underline cursor-pointer">Vehicles & Registered Cars</li>
              <li className="hover:underline cursor-pointer">Mobile Phones & Tablets</li>
              <li className="hover:underline cursor-pointer">Real Estate & Furnished Apartments</li>
              <li className="hover:underline cursor-pointer">Electronics & High-Spec Laptops</li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-black text-yellow-400 uppercase tracking-widest mb-4">Popular regions</h4>
            <ul className="text-xs text-green-200/80 font-medium flex flex-col gap-2.5">
              <li className="hover:underline cursor-pointer">Greater Accra Region (Accra, East Legon, Circle)</li>
              <li className="hover:underline cursor-pointer">Ashanti Region (Kumasi, Adum, Bantama)</li>
              <li className="hover:underline cursor-pointer">Western Region (Takoradi, Sekondi)</li>
              <li className="hover:underline cursor-pointer">Central Region (Cape Coast, Elmina)</li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-black text-yellow-400 uppercase tracking-widest mb-4">Safe trading links</h4>
            <ul className="text-xs text-green-200/80 font-medium flex flex-col gap-2.5">
              <li className="hover:underline cursor-pointer">Safety Policy Guidelines</li>
              <li className="hover:underline cursor-pointer">Terms & Conditions of Service</li>
              <li className="hover:underline cursor-pointer flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#b08865]" />
                <span>Verified Buyer Protection</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 mt-8 border-t border-green-900 text-center text-[10px] text-green-200/40 font-bold tracking-wider">
          © 2026 DATAZONE4 CLASSIFIEDS. DEVELOPED IN ACCRA, LAGOS & LOMÉ. ALL RIGHTS RESERVED.
        </div>
      </footer>

      {/* ==================== ACTIVE MODALS & OVERLAYS ==================== */}

      {/* 1. AD DETAIL VIEWER OVERLAY */}
      <AnimatePresence>
        {selectedListingId && (
          <ListingDetail
            listingId={selectedListingId}
            onClose={() => setSelectedListingId(null)}
            onInitiateChat={handleInitiateChat}
            onToggleFavorite={handleToggleFavorite}
            isFavorite={favorites.includes(selectedListingId)}
            selectedCountry={selectedCountry}
            selectedCurrency={selectedCurrency}
          />
        )}
      </AnimatePresence>

      {/* 2. POST CLASSIFIED AD WIZARD MODAL */}
      {postAdOpen && (
        <PostAdModal
          onClose={() => setPostAdOpen(false)}
          onAdPosted={() => {
            setPostAdOpen(false);
            setRefreshTrigger(prev => prev + 1); // Triggers Listings and dynamic Categories refresh
            setActiveTab('feed');
          }}
          onOpenSubscription={() => setSubscriptionModalOpen(true)}
        />
      )}

      {/* 3. IN-APP secure NEGOTIATOR Messenger Drawer */}
      <ChatDrawer
        isOpen={chatDrawerOpen}
        onClose={() => {
          setChatDrawerOpen(false);
          setChatActiveListing(null);
        }}
        activeListing={chatActiveListing}
        onCloseActiveListing={() => setChatActiveListing(null)}
      />

      {/* 4. SECURITY & AUTHENTICATION MODAL */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        currentUser={currentUser}
        onAuthSuccess={handleAuthSuccess}
        onLogout={handleLogout}
      />

      {/* 5. SELLER SUBSCRIPTION MODAL */}
      <SubscriptionModal
        isOpen={subscriptionModalOpen}
        onClose={() => setSubscriptionModalOpen(false)}
        sellerId={currentUser?.id}
        onSubscriptionUpdated={() => setRefreshTrigger(prev => prev + 1)}
      />



      {/* 4. NETWORK STATUS TOAST NOTIFICATION */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className={`fixed bottom-6 left-1/2 -translate-x-1/2 md:left-auto md:right-6 md:translate-x-0 z-[9999] p-4 rounded-xl shadow-xl flex items-center gap-3 border max-w-sm sm:max-w-md w-[90vw] ${
              toastType === 'offline'
                ? 'bg-red-500 border-red-400 text-white'
                : 'bg-green-600 border-green-500 text-white'
            }`}
          >
            <div className="p-1.5 bg-white/15 rounded-lg shrink-0">
              {toastType === 'offline' ? (
                <WifiOff className="w-5 h-5 text-white stroke-[2.5]" />
              ) : (
                <Wifi className="w-5 h-5 text-white stroke-[2.5]" />
              )}
            </div>

            <div className="flex-1 text-left">
              <h5 className="text-xs font-black uppercase tracking-wider">
                {toastType === 'offline' ? 'No Internet Connection' : 'Connection Restored'}
              </h5>
              <p className="text-[11px] text-white/90 font-bold leading-snug mt-0.5">
                {toastType === 'offline'
                  ? 'Your progress is autosaved locally, but listings posting is disabled.'
                  : 'You are back online! You can now post new ads and update listings.'}
              </p>
            </div>

            <button
              onClick={() => setShowToast(false)}
              className="text-white hover:text-white/80 p-1 bg-white/10 hover:bg-white/20 transition rounded-full cursor-pointer select-none border-0 shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 5. STICKY BOTTOM NAVIGATION BAR / DOWN BAR */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#291f17] text-white border-t border-amber-900/60 shadow-2xl px-3 py-2">
        <div className="max-w-md mx-auto flex items-center justify-between">
          {/* Home / Feed */}
          <button
            onClick={() => {
              setIsAdminMode(false);
              setActiveTab('feed');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`flex flex-col items-center gap-1 transition cursor-pointer px-2 py-1 rounded-lg ${
              !isAdminMode && activeTab === 'feed'
                ? 'text-yellow-400 font-bold'
                : 'text-amber-200/70 hover:text-white'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] font-bold">Home</span>
          </button>

          {/* Top Sellers Leaderboard */}
          <button
            onClick={() => {
              setIsAdminMode(false);
              setActiveTab('top-sellers');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`flex flex-col items-center gap-1 transition cursor-pointer px-2 py-1 rounded-lg ${
              !isAdminMode && activeTab === 'top-sellers'
                ? 'text-yellow-400 font-bold'
                : 'text-amber-200/70 hover:text-white'
            }`}
          >
            <Trophy className="w-5 h-5" />
            <span className="text-[10px] font-bold">Top Sellers</span>
          </button>

          {/* Favorites / Saved Ads */}
          <button
            onClick={() => {
              setIsAdminMode(false);
              setActiveTab('saved');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`relative flex flex-col items-center gap-1 transition cursor-pointer px-2 py-1 rounded-lg ${
              !isAdminMode && activeTab === 'saved'
                ? 'text-yellow-400 font-bold'
                : 'text-amber-200/70 hover:text-white'
            }`}
          >
            <Heart className="w-5 h-5" />
            {favorites.length > 0 && (
              <span className="absolute -top-1 right-1 bg-yellow-400 text-green-950 text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                {favorites.length}
              </span>
            )}
            <span className="text-[10px] font-bold">Saved</span>
          </button>

          {/* Sell Button (Center Action) */}
          <button
            onClick={() => setPostAdOpen(true)}
            className="flex flex-col items-center gap-0.5 transition cursor-pointer -mt-4"
          >
            <div className="bg-[#e65c00] hover:bg-[#ff6d0c] text-white p-2.5 rounded-full shadow-lg border-2 border-amber-400 font-black transition transform active:scale-95">
              <PlusCircle className="w-6 h-6" />
            </div>
            <span className="text-[10px] font-black text-amber-300 uppercase tracking-wide">Sell</span>
          </button>

          {/* Chats */}
          <button
            onClick={() => setChatDrawerOpen(true)}
            className="relative flex flex-col items-center gap-1 text-amber-200/70 hover:text-white transition cursor-pointer px-2 py-1 rounded-lg"
          >
            <MessageSquare className="w-5 h-5" />
            {unreadChatsCount > 0 && (
              <span className="absolute -top-1 right-1 bg-red-500 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                {unreadChatsCount}
              </span>
            )}
            <span className="text-[10px] font-bold">Chats</span>
          </button>

          {/* Admin Toggle Button */}
          <button
            onClick={() => {
              setIsAdminMode(prev => !prev);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            title="Toggle Admin Mode"
            className={`flex flex-col items-center gap-1 transition cursor-pointer px-2.5 py-1 rounded-lg ${
              isAdminMode
                ? 'text-yellow-400 font-black bg-amber-950/80 ring-1 ring-yellow-400/50 scale-105'
                : 'text-amber-200/70 hover:text-white'
            }`}
          >
            <div className="relative flex items-center justify-center">
              <Shield className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold">d</span>
          </button>
        </div>
      </nav>

    </div>
  );
}
