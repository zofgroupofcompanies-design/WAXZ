import { AIListingEnhancement, AICustomsAnalysis, AIDisputeArbitration } from '../types';

/**
 * Service to communicate with server-side Gemini API proxy routes
 */

export async function enhanceListingAi(params: {
  title: string;
  category?: string;
  description?: string;
  priceUsd?: number;
}): Promise<AIListingEnhancement> {
  const response = await fetch('/api/ai/enhance-listing', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`AI Enhancement failed: ${errorText}`);
  }

  return response.json();
}

export async function calculateCustomsDutiesAi(params: {
  productTitle: string;
  category?: string;
  originCountry: string;
  destinationCountry: string;
  declaredValueUsd: number;
}): Promise<AICustomsAnalysis> {
  const response = await fetch('/api/ai/customs-advisor', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Customs analysis failed: ${errorText}`);
  }

  return response.json();
}

export async function arbitrateDisputeAi(params: {
  orderId: string;
  buyerClaim: string;
  sellerResponse: string;
  trackingStatus: string;
  carrierName?: string;
  encryptedHashValid: boolean;
}): Promise<AIDisputeArbitration> {
  const response = await fetch('/api/ai/arbitrate-dispute', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Dispute arbitration failed: ${errorText}`);
  }

  return response.json();
}

export async function monitorComplianceAi(params: {
  orderId: string;
  buyerEmail?: string;
  totalAmountUsd: number;
  paymentMethod?: string;
  destinationCountry?: string;
  itemsCount?: number;
  itemTitles?: string[];
}): Promise<import('../types').AIComplianceReport> {
  const response = await fetch('/api/ai/monitor-compliance', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Compliance monitoring failed: ${errorText}`);
  }

  return response.json();
}

export async function verifyKycDocAi(params: {
  sellerName: string;
  email: string;
  country: string;
  governmentIdType: string;
  idNumber: string;
  documentDataHash?: string;
}): Promise<import('../types').AISellerKycReport> {
  const response = await fetch('/api/ai/verify-kyc-doc', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`KYC document verification failed: ${errorText}`);
  }

  return response.json();
}
