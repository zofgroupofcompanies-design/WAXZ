import React, { useState } from 'react';
import { Product, CurrencyCode } from '../types';
import { formatPrice } from '../lib/currencies';
import { Lock, Star, Truck, CheckCircle2, ShoppingBag } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  activeCurrency: CurrencyCode;
  onSelectProduct: (p: Product) => void;
  onAddToCart: (p: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  activeCurrency,
  onSelectProduct,
  onAddToCart,
}) => {
  const [imgError, setImgError] = useState(false);

  return (
    <div className="group bg-white rounded-xl border border-slate-200 hover:border-emerald-500/50 hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden relative">
      {/* Product Image Slot */}
      <div
        onClick={() => onSelectProduct(product)}
        className="relative aspect-[4/3] bg-slate-100 overflow-hidden cursor-pointer"
      >
        {!imgError && product.imageUrl ? (
          <img
            src={product.imageUrl}
            alt={product.title}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800 text-slate-300 p-4 text-center">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-2">
              <Lock className="w-5 h-5" />
            </div>
            <span className="text-xs font-semibold text-white">{product.title}</span>
            <span className="text-[10px] text-slate-400 mt-1">{product.category}</span>
          </div>
        )}

        {/* Floating Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
          {product.isVerifiedVendor && (
            <span className="bg-slate-950/90 backdrop-blur-sm text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-500/40 flex items-center gap-1 shadow-sm">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              Verified Vendor
            </span>
          )}
        </div>

        <div className="absolute bottom-2.5 right-2.5 z-10">
          <span className="bg-slate-900/80 backdrop-blur-sm text-slate-200 text-[10px] font-medium px-2 py-0.5 rounded flex items-center gap-1">
            <Truck className="w-3 h-3 text-amber-400" />
            DHL / FedEx
          </span>
        </div>
      </div>

      {/* Product Info Body */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Metadata Kicker (Zero Pill Discipline) */}
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1 font-medium">
            <span>{product.category}</span>
            <span aria-hidden="true">·</span>
            <span>Origin: {product.countryOfOrigin}</span>
          </div>

          {/* Title */}
          <h3
            onClick={() => onSelectProduct(product)}
            className="text-sm font-bold text-slate-900 group-hover:text-emerald-600 transition-colors line-clamp-2 cursor-pointer leading-snug mb-2"
          >
            {product.title}
          </h3>

          {/* Seller & Rating */}
          <div className="flex items-center justify-between text-xs text-slate-600 mb-3">
            <span className="truncate max-w-[150px] font-medium flex items-center gap-1">
              <span>{product.sellerName}</span>
              {product.isVerifiedVendor && (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 inline shrink-0" title="Verified Seller - Government ID Approved" />
              )}
            </span>
            <div className="flex items-center gap-1 text-amber-500 font-bold">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>{product.sellerRating.toFixed(1)}</span>
            </div>
          </div>
        </div>

        {/* Pricing, Cryptographic Signature, and Action */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
          <div>
            <div className="text-lg font-black text-slate-900 font-mono tracking-tight">
              {formatPrice(product.priceUsd, activeCurrency)}
            </div>
            <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1 mt-0.5">
              <Lock className="w-2.5 h-2.5 text-emerald-600" />
              <span className="truncate max-w-[110px]">{product.encryptedProductSignature}</span>
            </div>
          </div>

          <button
            onClick={() => onAddToCart(product)}
            className="bg-slate-900 hover:bg-emerald-600 text-white p-2.5 rounded-lg transition-colors shadow-sm flex items-center justify-center shrink-0 group/btn"
            title="Add to Cart"
          >
            <ShoppingBag className="w-4 h-4 group-hover/btn:scale-110 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
};
