import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, MapPin, Eye, Calendar, ShieldCheck, Phone, MessageSquare, 
  Share2, AlertTriangle, ChevronLeft, ChevronRight, UserCheck, Star,
  ZoomIn, ZoomOut, RotateCcw, Maximize2, ChevronDown, ChevronUp, Info, AlertCircle, Check, Image,
  Bell, BellRing, TrendingUp, Sparkles, ShoppingBag, Lock, Truck
} from 'lucide-react';
import { 
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { Listing, SellerReview } from '../types';
import { COUNTRIES_CONFIG } from '../data/mockData';
import { CurrencyCode, CURRENCIES, formatConvertedPrice, convertPrice } from '../utils/currency';
import MapComponent from './MapComponent';
import CheckoutModal from './CheckoutModal';


const SAFETY_TIPS: Record<string, {
  general: string[];
  regions: Record<string, {
    safeSpots: string[];
    warnings: string[];
  }>;
}> = {
  'Ghana': {
    general: [
      "Do NOT send Mobile Money (MoMo) deposits before inspecting the item.",
      "Insist on verifying the seller's active Ghana Card or physical ID for high-value items.",
      "Meet only during daylight hours in heavily trafficked zones."
    ],
    regions: {
      'Greater Accra': {
        safeSpots: [
          "Accra Mall (Tetteh Quarshie Interchange)",
          "West Hills Mall (Weija)",
          "A&C Mall (East Legon)",
          "Marina Mall (Airport Residential Area)",
          "Osu Oxford Street (near high-traffic restaurants/banks)"
        ],
        warnings: [
          "Avoid secluded alleyways in East Legon, Spintex, or industrial warehouses after sunset.",
          "Be cautious of buyers/sellers requesting to meet in remote corners of Circle or Madina."
        ]
      },
      'Ashanti': {
        safeSpots: [
          "Kumasi City Mall (Asokwa)",
          "KNUST Commercial Area (near police/bank hubs)",
          "Adum Post Office/Bank premises",
          "Nhyiaeso commercial plazas"
        ],
        warnings: [
          "Do not meet in deep parts of Kumasi Central Market after hours.",
          "Avoid unfamiliar streets in Tafo or Bantama."
        ]
      },
      'Western': {
        safeSpots: [
          "Takoradi Mall",
          "Sekondi Commercial Bank area",
          "Anaji Choice Mart parking lot"
        ],
        warnings: [
          "Avoid meeting near industrial harbor sites or unlit coastal beaches."
        ]
      },
      'Central': {
        safeSpots: [
          "Cape Coast Castle public square",
          "Kasoa Galilaya commercial hubs",
          "Winneba roundabout plaza"
        ],
        warnings: [
          "Stay alert in Kasoa market outskirts due to high pickpocketing risk."
        ]
      },
      'Eastern': {
        safeSpots: [
          "Koforidua Jackson Park",
          "Aburi Botanical Gardens main entrance gate",
          "Nkawkaw central bank zones"
        ],
        warnings: [
          "Avoid isolated forest paths or unpaved mountain roads."
        ]
      },
      'Volta': {
        safeSpots: [
          "Ho Civic Centre",
          "Aflao Border main security gate area",
          "Kpando central plaza"
        ],
        warnings: [
          "Avoid isolated border lanes or unmonitored shore paths."
        ]
      },
      'Northern': {
        safeSpots: [
          "Tamale Jubilee Park",
          "Sagnarigu municipal square",
          "Tamale Central Market banking area"
        ],
        warnings: [
          "Stay away from unlit outskirts or non-commercial remote farmlands."
        ]
      }
    }
  },
  'Nigeria': {
    general: [
      "Never pay upfront or make deposits via bank transfers to hold an item.",
      "Inspect high-end electronics for lock issues, fake serial numbers, and check iCloud accounts.",
      "Verify the identity of the person you are communicating with."
    ],
    regions: {
      'Lagos': {
        safeSpots: [
          "Ikeja City Mall (Alausa)",
          "The Palms Shopping Mall (Lekki)",
          "Maryland Mall (Ikorodu Road)",
          "Victoria Island bank parking lots",
          "Yaba commercial banks or fuel stations on Herbert Macaulay Way"
        ],
        warnings: [
          "Do not meet in secluded bridges, bus-stops after dark (like Ojuelegba or Mile 2).",
          "Refuse to meet in remote corners of Yaba or outer Lekki Phase 1."
        ]
      },
      'Abuja FCT': {
        safeSpots: [
          "Jabi Lake Mall",
          "Wuse II commercial banking plazas",
          "Maitama recreational public parks",
          "Gwarinpa fuel stations/supermarkets"
        ],
        warnings: [
          "Avoid unlit side streets or remote locations in Apo or outer satellite towns."
        ]
      },
      'Rivers': {
        safeSpots: [
          "GRA Phase 2 bank lobbies",
          "Rumuokoro commercial plazas",
          "Trans Amadi industrial public banks"
        ],
        warnings: [
          "Avoid desolate port facilities or outer bypass bypass roads."
        ]
      },
      'Oyo': {
        safeSpots: [
          "Heritage Mall (Irawo, Ibadan)",
          "Bodija commercial core",
          "Ring Road bank branches"
        ],
        warnings: [
          "Avoid remote agricultural outskirts of Ibadan."
        ]
      },
      'Kano': {
        safeSpots: [
          "Ado Bayero Mall",
          "Fagge commercial plaza",
          "Nassarawa central public spaces"
        ],
        warnings: [
          "Avoid unpopulated outer roads or warehouse areas."
        ]
      }
    }
  },
  'Togo': {
    general: [
      "N'envoyez jamais d'argent via T-Money ou Flooz avant d'avoir vu l'article.",
      "Exigez de voir la carte d'identité de l'acheteur ou du vendeur pour les objets de valeur.",
      "Privilégiez les rencontres en journée et en public."
    ],
    regions: {
      'Maritime (Lomé)': {
        safeSpots: [
          "Grand Marché de Lomé (devant une grande banque)",
          "Près de l'Université de Lomé (zones animées)",
          "Hôtel 2 Février parking public",
          "Baguida supermarchés",
          "Adidogomé stations-services animées"
        ],
        warnings: [
          "Évitez les zones sombres du Boulevard du Mono après la tombée de la nuit.",
          "Ne rencontrez personne dans les ruelles isolées près de la frontière d'Aflao."
        ]
      },
      'Plateaux': {
        safeSpots: [
          "Kpalimé centre-ville (près de la poste)",
          "Atakpamé marché central",
          "Notsé grand rond-point"
        ],
        warnings: [
          "Évitez les sentiers de randonnée isolés ou les cascades éloignées."
        ]
      },
      'Centrale': {
        safeSpots: [
          "Sokodé banques centrales",
          "Tchamba marché public"
        ],
        warnings: [
          "Évitez les pistes forestières ou les fermes isolées."
        ]
      },
      'Kara': {
        safeSpots: [
          "Kara centre-ville près du grand marché",
          "Bafilo places publiques animées"
        ],
        warnings: [
          "Ne rencontrez personne dans les zones de montagne isolées."
        ]
      },
      'Savanes': {
        safeSpots: [
          "Dapaong centre-ville (banques)",
          "Mango zones commerciales animées"
        ],
        warnings: [
          "Évitez les pistes frontalières non surveillées."
        ]
      }
    }
  }
};

interface ListingDetailProps {
  listingId: string;
  onClose: () => void;
  onInitiateChat: (listing: Listing) => void;
  onToggleFavorite: (id: string) => void;
  isFavorite: boolean;
  selectedCountry?: string;
  selectedCurrency?: CurrencyCode;
}

const generatePriceTrendData = (basePrice: number) => {
  const data = [];
  const now = new Date();
  for (let i = 30; i >= 0; i -= 5) {
    const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
    const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    
    // Create a fluctuation factor using a nice wavy formula
    const factor = 1 + (Math.sin(i * 0.4) * 0.08) - (i * 0.001); 
    const avgPrice = Math.round(basePrice * factor);
    
    data.push({
      name: dateStr,
      avgPrice,
      currentItemPrice: basePrice,
    });
  }
  return data;
};

const getSellerDetails = (sellerId: string, sellerName: string, isVerifiedVendor?: boolean) => {
  let isVerified = Boolean(isVerifiedVendor);

  if (sellerId === 'usr-current') {
    const savedProfile = localStorage.getItem('dosboz_user_profile');
    if (savedProfile) {
      try {
        const profile = JSON.parse(savedProfile);
        if (profile.verified) isVerified = true;
      } catch (e) {
        // Fallback to defaults
      }
    }
  }

  if (isVerifiedVendor === undefined && ['usr-seller-1', 'usr-[#b08865]-ng', 'usr-seller-ng-1', 'usr-seller-tg', 'usr-seed-1'].includes(sellerId)) {
    isVerified = true;
  }

  const nameToHash = sellerId || sellerName || 'Seller';
  let hash = 0;
  for (let i = 0; i < nameToHash.length; i++) {
    hash = nameToHash.charCodeAt(i) + ((hash << 5) - hash);
  }
  
  const ratingValue = 4.4 + (Math.abs(hash) % 7) / 10;
  const rating = parseFloat(ratingValue.toFixed(1));
  const reputationScore = parseFloat((94 + (Math.abs(hash) % 55) / 10).toFixed(1));
  
  const years = [2021, 2022, 2023, 2024, 2025];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  const year = years[Math.abs(hash) % years.length];
  const month = months[Math.abs(hash >> 2) % months.length];
  
  return {
    rating,
    reputationScore,
    memberSince: `${month} ${year}`,
    isVerified
  };
};

export default function ListingDetail({
  listingId,
  onClose,
  onInitiateChat,
  onToggleFavorite,
  isFavorite,
  selectedCountry,
  selectedCurrency = 'GHS'
}: ListingDetailProps) {
  const [listing, setListing] = useState<Listing | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [showPhone, setShowPhone] = useState(false);
  const [similarListings, setSimilarListings] = useState<Listing[]>([]);
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  // Seller Reviews & Star Rating States
  const [reviewsList, setReviewsList] = useState<SellerReview[]>([]);
  const [sellerRating, setSellerRating] = useState<number>(4.85);
  const [sellerReputationScore, setSellerReputationScore] = useState<number>(98.8);
  const [reviewsCount, setReviewsCount] = useState<number>(3);
  const [reviewsLoading, setReviewsLoading] = useState<boolean>(false);

  // Review Form States
  const [newRating, setNewRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [newReviewText, setNewReviewText] = useState<string>('');
  const [reviewerName, setReviewerName] = useState<string>('Kwame Mensah');
  const [reviewSubmitting, setReviewSubmitting] = useState<boolean>(false);
  const [reviewSuccessMsg, setReviewSuccessMsg] = useState<string | null>(null);

  // Fetch reviews whenever listing sellerId is loaded
  useEffect(() => {
    if (listing?.sellerId) {
      setReviewsLoading(true);
      fetch(`/api/sellers/${listing.sellerId}/reviews`)
        .then(res => res.json())
        .then(data => {
          if (data.reviews) setReviewsList(data.reviews);
          if (data.rating) setSellerRating(data.rating);
          if (data.reputationScore) setSellerReputationScore(data.reputationScore);
          if (data.reviewCount !== undefined) setReviewsCount(data.reviewCount);
          setReviewsLoading(false);
        })
        .catch(err => {
          console.error("Failed to load seller reviews:", err);
          setReviewsLoading(false);
        });
    }
  }, [listing?.sellerId]);

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!listing || !newReviewText.trim()) return;

    setReviewSubmitting(true);
    setReviewSuccessMsg(null);

    try {
      const res = await fetch(`/api/sellers/${listing.sellerId}/reviews`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rating: newRating,
          reviewText: newReviewText,
          buyerName: reviewerName || 'Verified Buyer',
          buyerId: 'usr-buyer-1',
          listingId: listing.id,
          listingTitle: listing.title
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.reviews) setReviewsList(data.reviews);
        if (data.updatedStats) {
          setSellerRating(data.updatedStats.rating);
          setSellerReputationScore(data.updatedStats.reputationScore);
          setReviewsCount(data.updatedStats.reviewCount);
        }
        setNewReviewText('');
        setReviewSuccessMsg('Your star rating & seller review have been posted successfully!');
        setTimeout(() => setReviewSuccessMsg(null), 5000);
      }
    } catch (err) {
      console.error('Failed to submit review:', err);
    } finally {
      setReviewSubmitting(false);
    }
  };


  // Price Drop Notification Toggle state for Favorited Items
  const [isPriceDropNotified, setIsPriceDropNotified] = useState(false);

  useEffect(() => {
    if (listingId) {
      const saved = localStorage.getItem('dosboz_price_drop_alerts');
      if (saved) {
        try {
          const alerts = JSON.parse(saved);
          setIsPriceDropNotified(!!alerts[listingId]?.enabled);
        } catch (e) {
          // ignore
        }
      }
    }
  }, [listingId]);

  const handleTogglePriceDropNotify = () => {
    if (!listing) return;
    const newStatus = !isPriceDropNotified;
    setIsPriceDropNotified(newStatus);

    const saved = localStorage.getItem('dosboz_price_drop_alerts');
    const alerts = saved ? JSON.parse(saved) : {};

    if (newStatus) {
      alerts[listing.id] = {
        enabled: true,
        listingId: listing.id,
        title: listing.title,
        price: listing.price,
        initialPrice: listing.price,
        country: listing.country || 'Ghana',
        imageUrl: listing.imageUrls?.[0] || '',
        updatedAt: new Date().toISOString()
      };
    } else {
      delete alerts[listing.id];
    }

    localStorage.setItem('dosboz_price_drop_alerts', JSON.stringify(alerts));
  };

  // Interactive Zoom / Lightbox states
  const [isZoomOpen, setIsZoomOpen] = useState(false);
  const [zoomScale, setZoomScale] = useState(1);
  const [zoomOffset, setZoomOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  // User Reporting States
  const [isReporting, setIsReporting] = useState(false);
  const [reportReason, setReportReason] = useState('Suspicious Pricing / Fraud');
  const [reportDetails, setReportDetails] = useState('');
  const [reportingSubmitting, setReportingSubmitting] = useState(false);
  const [reportSuccess, setReportSuccess] = useState(false);
  const [isSafetyExpanded, setIsSafetyExpanded] = useState(true);
  const [showShareToast, setShowShareToast] = useState(false);

  // Price Alert States
  const [showPriceAlertModal, setShowPriceAlertModal] = useState(false);
  const [targetPrice, setTargetPrice] = useState<string>('');
  const [priceAlertCreated, setPriceAlertCreated] = useState(false);

  useEffect(() => {
    if (listing) {
      // Prefill with 10% lower price than current listing price
      setTargetPrice(Math.round(listing.price * 0.9).toString());
    }
  }, [listing, showPriceAlertModal]);

  const handleCreatePriceAlert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!listing) return;
    
    const parsedPrice = parseFloat(targetPrice);
    if (isNaN(parsedPrice) || parsedPrice <= 0) {
      alert('Please enter a valid price threshold.');
      return;
    }
    
    // Save to localStorage
    const savedAlerts = localStorage.getItem('dosboz_price_alerts');
    const alerts = savedAlerts ? JSON.parse(savedAlerts) : [];
    
    // Check if an alert already exists for this listing
    const existsIndex = alerts.findIndex((a: any) => a.listingId === listing.id);
    const newAlert = {
      id: `alert-${Date.now()}`,
      listingId: listing.id,
      title: listing.title,
      categoryId: listing.categoryId,
      categoryName: listing.categoryName,
      subCategory: listing.subCategory,
      originalPrice: listing.price,
      targetPrice: parsedPrice,
      currency: currencySymbol,
      createdAt: new Date().toISOString(),
      active: true
    };
    
    if (existsIndex >= 0) {
      alerts[existsIndex] = newAlert;
    } else {
      alerts.push(newAlert);
    }
    
    localStorage.setItem('dosboz_price_alerts', JSON.stringify(alerts));
    
    setPriceAlertCreated(true);
    setTimeout(() => {
      setShowPriceAlertModal(false);
      setPriceAlertCreated(false);
    }, 2000);
  };

  // Seller profile overlay states
  const [showSellerOverlay, setShowSellerOverlay] = useState(false);
  const [sellerListings, setSellerListings] = useState<Listing[]>([]);
  const [sellerListingsLoading, setSellerListingsLoading] = useState(false);

  useEffect(() => {
    if (showShareToast) {
      const timer = setTimeout(() => {
        setShowShareToast(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [showShareToast]);

  useEffect(() => {
    if (showSellerOverlay && listing) {
      setSellerListingsLoading(true);
      fetch(`/api/listings?sellerId=${listing.sellerId}`)
        .then(res => res.json())
        .then((data: Listing[]) => {
          setSellerListings(data.filter(item => item.status === 'active'));
          setSellerListingsLoading(false);
        })
        .catch(err => {
          console.error("Failed to load seller listings", err);
          setSellerListingsLoading(false);
        });
    }
  }, [showSellerOverlay, listing]);

  const resetZoom = () => {
    setZoomScale(1);
    setZoomOffset({ x: 0, y: 0 });
    setIsDragging(false);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isZoomOpen || !listing) return;
      if (e.key === 'Escape') {
        setIsZoomOpen(false);
      } else if (e.key === 'ArrowLeft') {
        setActiveImageIndex(prev => (prev === 0 ? listing.imageUrls.length - 1 : prev - 1));
        resetZoom();
      } else if (e.key === 'ArrowRight') {
        setActiveImageIndex(prev => (prev === listing.imageUrls.length - 1 ? 0 : prev + 1));
        resetZoom();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isZoomOpen, listing]);

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (zoomScale <= 1) return;
    e.preventDefault();
    setIsDragging(true);
    setDragStart({ x: e.clientX - zoomOffset.x, y: e.clientY - zoomOffset.y });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    e.preventDefault();
    const newX = e.clientX - dragStart.x;
    const newY = e.clientY - dragStart.y;
    
    const limitX = (zoomScale - 1) * 350;
    const limitY = (zoomScale - 1) * 200;
    const boundedX = Math.max(-limitX, Math.min(limitX, newX));
    const boundedY = Math.max(-limitY, Math.min(limitY, newY));
    
    setZoomOffset({ x: boundedX, y: boundedY });
  };

  const handleMouseUpOrLeave = () => {
    setIsDragging(false);
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (zoomScale <= 1 || e.touches.length !== 1) return;
    setIsDragging(true);
    const touch = e.touches[0];
    setDragStart({ x: touch.clientX - zoomOffset.x, y: touch.clientY - zoomOffset.y });
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isDragging || e.touches.length !== 1) return;
    const touch = e.touches[0];
    const newX = touch.clientX - dragStart.x;
    const newY = touch.clientY - dragStart.y;
    
    const limitX = (zoomScale - 1) * 350;
    const limitY = (zoomScale - 1) * 200;
    const boundedX = Math.max(-limitX, Math.min(limitX, newX));
    const boundedY = Math.max(-limitY, Math.min(limitY, newY));
    
    setZoomOffset({ x: boundedX, y: boundedY });
  };

  const handleDoubleClick = () => {
    if (zoomScale > 1) {
      resetZoom();
    } else {
      setZoomScale(2.5);
    }
  };

  // Fetch listing details and trigger view counter increment
  useEffect(() => {
    setLoading(true);
    setShowPhone(false);
    setActiveImageIndex(0);

    // Fetch details
    fetch(`/api/listings/${listingId}`)
      .then(res => {
        if (!res.ok) throw new Error('Listing not found');
        return res.json();
      })
      .then((data: Listing) => {
        setListing(data);
        setLoading(false);

        // Fetch similar items in same category
        fetch(`/api/listings?categoryId=${data.categoryId}`)
          .then(res => res.json())
          .then((similar: Listing[]) => {
            // Exclude current item and limit to 4
            setSimilarListings(similar.filter(item => item.id !== data.id).slice(0, 4));
          })
          .catch(err => console.error('Failed to load similar listings:', err));

        // Increment views in database
        fetch(`/api/listings/${listingId}/increment-views`, { method: 'POST' })
          .catch(err => console.error('Failed to increment views:', err));
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, [listingId]);

  if (loading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ type: 'spring', damping: 25, stiffness: 350 }}
          className="bg-white rounded-2xl p-8 max-w-sm w-full text-center flex flex-col items-center animate-pulse"
        >
          <div className="w-12 h-12 rounded-full border-4 border-t-[#b08865] border-gray-100 animate-spin mb-4"></div>
          <p className="text-sm font-semibold text-gray-500">Retrieving item details...</p>
        </motion.div>
      </motion.div>
    );
  }

  if (!listing) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ type: 'spring', damping: 25, stiffness: 350 }}
          className="bg-white rounded-2xl p-6 max-w-sm w-full text-center"
        >
          <X className="w-12 h-12 text-red-500 mx-auto mb-3" />
          <h3 className="font-bold text-gray-800 text-lg mb-1">Item Not Found</h3>
          <p className="text-xs text-gray-500 mb-4">This listing may have been sold or removed by the seller.</p>
          <button onClick={onClose} className="bg-gray-100 text-gray-800 px-4 py-2 rounded-lg text-xs font-bold cursor-pointer">
            Close
          </button>
        </motion.div>
      </motion.div>
    );
  }

  // Format creation date
  const formattedDate = new Date(listing.createdAt).toLocaleDateString('en-GH', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });

  const countryConfig = COUNTRIES_CONFIG[listing.country || 'Ghana'] || COUNTRIES_CONFIG['Ghana'];
  const currencySymbol = CURRENCIES[selectedCurrency]?.symbol || countryConfig?.currency || 'GH₵';
  const formattedPrice = formatConvertedPrice(listing.price, listing.country || 'Ghana', selectedCurrency);

  // Pre-populate WhatsApp URL
  const whatsappMessage = encodeURIComponent(
    `Hello ${listing.sellerName}, I saw your listing "${listing.title}" on Bozseller ${listing.country || 'Ghana'} (${formattedPrice}). Is it still available for inspection?`
  );
  const whatsappUrl = `https://wa.me/${listing.sellerWhatsApp.replace(/\s+/g, '')}?text=${whatsappMessage}`;

  const sellerStats = getSellerDetails(listing.sellerId, listing.sellerName, listing.isVerifiedVendor);

  const activeCountry = selectedCountry || listing?.country || 'Ghana';
  const tips = SAFETY_TIPS[activeCountry] || SAFETY_TIPS['Ghana'];
  const listingCountry = listing?.country || 'Ghana';
  const listingRegion = listing?.region;
  const hasRegionTips = activeCountry === listingCountry && listingRegion && tips.regions[listingRegion];
  const activeRegionName = hasRegionTips 
    ? listingRegion 
    : Object.keys(tips.regions)[0];
  const regionData = tips.regions[activeRegionName];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="fixed inset-0 bg-black/70 z-50 overflow-y-auto flex justify-center p-0 md:p-6 backdrop-blur-xs"
    >
      {/* Dynamic Clipboard Copy Success Toast */}
      <AnimatePresence>
        {showShareToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, x: "-50%", scale: 0.95 }}
            animate={{ opacity: 1, y: 0, x: "-50%", scale: 1 }}
            exit={{ opacity: 0, y: -20, x: "-50%", scale: 0.95 }}
            className="fixed top-6 left-1/2 z-[100] bg-gray-950 text-white text-xs font-bold px-4.5 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 border border-gray-800"
          >
            <div className="bg-[#b08865] text-white p-1 rounded-full flex items-center justify-center shrink-0">
              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
            </div>
            <span className="tracking-tight">Listing link copied to clipboard!</span>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ type: 'spring', damping: 25, stiffness: 350 }}
        className="bg-gray-50 w-full max-w-5xl h-fit rounded-none md:rounded-2xl overflow-hidden shadow-2xl relative flex flex-col my-auto"
      >
        
        {/* CLOSE BUTTON */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 bg-black/50 hover:bg-black/75 text-white p-2 rounded-full transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Columns Wrapper */}
        <div className="flex flex-col md:flex-row w-full">

        {/* LEFT COLUMN: Visual Media & Description */}
        <div className="flex-1 bg-white p-4 sm:p-6 border-r border-gray-100">
          {/* Breadcrumb path */}
          <div className="text-xs text-gray-400 font-semibold mb-3.5 flex items-center gap-1.5 flex-wrap">
            <span>Home</span>
            <span>&rsaquo;</span>
            <span>{listing.categoryName}</span>
            <span>&rsaquo;</span>
            <span className="text-[#b08865] truncate max-w-[200px]">{listing.title}</span>
          </div>

          {/* Image Gallery */}
          <div className="group relative w-full aspect-16/10 bg-gray-950 rounded-2xl overflow-hidden mb-3 border border-gray-200 shadow-xs">
            <motion.div 
              className="flex h-full cursor-zoom-in"
              style={{ width: `${listing.imageUrls.length * 100}%` }}
              animate={{ x: `-${(activeImageIndex * 100) / listing.imageUrls.length}%` }}
              transition={{ type: "spring", stiffness: 260, damping: 28 }}
              drag={listing.imageUrls.length > 1 ? "x" : false}
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={0.15}
              onDragEnd={(e, info) => {
                const swipeThreshold = 50;
                if (info.offset.x < -swipeThreshold) {
                  // Swipe left -> Next image
                  setActiveImageIndex(prev => (prev === listing.imageUrls.length - 1 ? 0 : prev + 1));
                } else if (info.offset.x > swipeThreshold) {
                  // Swipe right -> Prev image
                  setActiveImageIndex(prev => (prev === 0 ? listing.imageUrls.length - 1 : prev - 1));
                }
              }}
              onClick={() => setIsZoomOpen(true)}
            >
              {listing.imageUrls.map((url, idx) => (
                <div 
                  key={idx} 
                  className="h-full flex items-center justify-center relative select-none"
                  style={{ width: `${100 / listing.imageUrls.length}%` }}
                >
                  <img
                    src={url}
                    alt={`${listing.title} - Photo ${idx + 1}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain select-none pointer-events-none"
                  />
                </div>
              ))}
            </motion.div>
            
            {/* Dark gradient vignette */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-60 pointer-events-none" />

            {/* Premium "Click to Zoom" Hover Indicator */}
            <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center flex-col gap-2 pointer-events-none">
              <div className="bg-white/90 backdrop-blur-md p-3 rounded-full text-[#3e3023] shadow-lg scale-90 group-hover:scale-100 transition-transform duration-300">
                <ZoomIn className="w-6 h-6 animate-pulse" />
              </div>
              <span className="text-white text-xs font-bold tracking-wide uppercase px-3 py-1 bg-black/50 rounded-full backdrop-blur-xs">
                Click to expand & zoom
              </span>
            </div>

            {/* Gallery Indicator Badge */}
            <span className="absolute top-3 left-3 bg-black/60 text-white text-[10px] font-black px-2.5 py-1 rounded-full backdrop-blur-md select-none tracking-wider z-10">
              {activeImageIndex + 1} / {listing.imageUrls.length} PHOTOS
            </span>

            {/* Gallery Arrows */}
            {listing.imageUrls.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveImageIndex(prev => (prev === 0 ? listing.imageUrls.length - 1 : prev - 1));
                  }}
                  className="absolute left-3 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-[#b08865] p-2 rounded-full text-white cursor-pointer transition shadow-md hover:scale-105 active:scale-95 z-10"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveImageIndex(prev => (prev === listing.imageUrls.length - 1 ? 0 : prev + 1));
                  }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-[#b08865] p-2 rounded-full text-white cursor-pointer transition shadow-md hover:scale-105 active:scale-95 z-10"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </>
            )}
          </div>

          {/* Premium Gallery Thumbnail Strip below main image */}
          {listing.imageUrls.length > 1 && (
            <div className="flex gap-2 items-center overflow-x-auto pb-2 mb-4 scrollbar-thin scrollbar-thumb-gray-200">
              {listing.imageUrls.map((url, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setActiveImageIndex(idx)}
                  className={`relative w-16 h-12 sm:w-20 sm:h-14 rounded-lg overflow-hidden border-2 shrink-0 transition-all ${
                    idx === activeImageIndex 
                      ? 'border-[#b08865] scale-95 shadow-sm ring-2 ring-[#b08865]/20' 
                      : 'border-transparent hover:border-gray-300 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img 
                    src={url} 
                    alt={`Thumbnail ${idx + 1}`} 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover select-none" 
                  />
                  {idx === activeImageIndex && (
                    <div className="absolute inset-0 bg-[#b08865]/10" />
                  )}
                </button>
              ))}
            </div>
          )}

          {/* Core Title, Price & Meta */}
          <div className="mb-6">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="bg-[#b08865]/10 text-[#3e3023] text-xs font-bold px-2.5 py-0.5 rounded-full">
                {listing.condition}
              </span>
              <span className="text-xs text-gray-400 font-semibold flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                Posted on {formattedDate}
              </span>
              
              {/* Trust Badges */}
              <div className="hidden sm:block h-4 w-px bg-gray-200 mx-1"></div>
              
              <span className="text-xs bg-amber-50 text-amber-700 font-bold px-2 py-0.5 rounded-md border border-amber-100 flex items-center gap-1 shadow-2xs">
                <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500 shrink-0" />
                <span>Rating: {sellerStats.rating} / 5.0</span>
              </span>
              
              <span className="text-xs bg-blue-50 text-blue-700 font-bold px-2 py-0.5 rounded-md border border-blue-100 flex items-center gap-1 shadow-2xs">
                <UserCheck className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                <span>Member Since: {sellerStats.memberSince}</span>
              </span>

              {sellerStats.isVerified && (
                <span className="text-xs bg-green-50 text-green-700 font-extrabold px-2 py-0.5 rounded-md border border-green-100 flex items-center gap-1 shadow-2xs">
                  <ShieldCheck className="w-3.5 h-3.5 text-green-600 shrink-0" />
                  <span>Verified Seller</span>
                </span>
              )}

              <span className="text-xs text-gray-400 font-semibold flex items-center gap-1 ml-auto">
                <Eye className="w-3.5 h-3.5" />
                {listing.views} views
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl font-bold text-gray-900 leading-tight mb-2">
              {listing.title}
            </h1>

            <div className="flex items-center gap-3 flex-wrap">
              <span className="text-2xl font-black text-gray-900 tracking-tight">
                {formattedPrice}
              </span>
              {listing.isNegotiable && (
                <span className="text-xs bg-green-50 text-green-700 font-bold px-2 py-0.5 rounded-full border border-green-100">
                  Negotiable
                </span>
              )}
              <button
                onClick={() => setShowPriceAlertModal(true)}
                className="ml-auto flex items-center gap-1.5 text-xs bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold px-3 py-2 rounded-xl border border-amber-100 shadow-2xs cursor-pointer transition"
              >
                <Bell className="w-4 h-4 text-[#b08865]" />
                <span>Create Price Alert</span>
              </button>
            </div>

            {/* "Notify me of price drops" toggle for favorited items */}
            {isFavorite && (
              <div className="mt-3 p-3.5 bg-gradient-to-r from-amber-50/90 via-amber-50/60 to-amber-100/30 border border-amber-200/80 rounded-xl flex items-center justify-between gap-3 shadow-3xs animate-in fade-in duration-200">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-amber-100/80 text-amber-800 rounded-lg shrink-0">
                    <BellRing className="w-4 h-4 text-amber-700 animate-bounce" />
                  </div>
                  <div className="text-left">
                    <h5 className="text-xs font-black text-gray-800 flex items-center gap-1.5">
                      <span>Notify me of price drops</span>
                      {isPriceDropNotified && (
                        <span className="text-[9px] bg-green-100 text-green-800 font-extrabold px-1.5 py-0.5 rounded-md uppercase">
                          Tracking Active
                        </span>
                      )}
                    </h5>
                    <p className="text-[10px] text-gray-500 font-medium leading-tight">
                      Show a notification badge on my dashboard when seller lowers the price.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleTogglePriceDropNotify}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    isPriceDropNotified ? 'bg-[#3db83a]' : 'bg-gray-300'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      isPriceDropNotified ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            )}
          </div>

          {/* Description Block */}
          <div className="mb-6">
            <h3 className="text-sm font-extrabold text-[#3e3023] uppercase tracking-wider mb-2.5 pb-2 border-b border-gray-100">
              Description
            </h3>
            <div className="text-sm text-gray-600 leading-relaxed whitespace-pre-line font-medium">
              {listing.description}
            </div>
          </div>

          {/* Seller Star Rating & Customer Reviews Section */}
          <div className="mb-6 p-5 bg-white border border-gray-200 rounded-2xl flex flex-col gap-5 shadow-3xs text-left">
            {/* Header with Reputation Score Badge */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-gray-100">
              <div className="flex items-center gap-2.5">
                <div className="bg-amber-100 text-amber-800 p-2.5 rounded-xl shrink-0">
                  <Star className="w-5 h-5 fill-amber-500 text-amber-500" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-gray-800 uppercase tracking-wider">
                    Seller Reputation & Reviews
                  </h4>
                  <p className="text-xs text-gray-500 font-medium">
                    Verified feedback from buyers trading with {listing.sellerName}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 bg-amber-50/80 border border-amber-200/70 p-2.5 rounded-xl shrink-0">
                <div className="text-center">
                  <span className="text-[10px] text-gray-500 font-bold uppercase block">Rating</span>
                  <span className="text-sm font-black text-amber-700 font-mono">
                    ★ {sellerRating} / 5.0
                  </span>
                </div>
                <div className="h-6 w-px bg-amber-200"></div>
                <div className="text-center">
                  <span className="text-[10px] text-gray-500 font-bold uppercase block">Reputation Score</span>
                  <span className="text-sm font-black text-emerald-700 font-mono">
                    {sellerReputationScore}% Positive
                  </span>
                </div>
              </div>
            </div>

            {/* Review Submission Form */}
            <form onSubmit={handleSubmitReview} className="bg-gray-50 p-4 rounded-xl border border-gray-200/80 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <h5 className="text-xs font-black text-gray-800 uppercase tracking-wider">
                  Rate {listing.sellerName}
                </h5>
                <span className="text-[10px] text-gray-400 font-bold uppercase">
                  Verified Purchase Feedback
                </span>
              </div>

              {/* Interactive Star Picker */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold text-gray-600">Your Rating:</span>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      onClick={() => setNewRating(star)}
                      className="p-1 text-gray-300 hover:text-amber-400 transition cursor-pointer"
                      title={`${star} Star${star > 1 ? 's' : ''}`}
                    >
                      <Star
                        className={`w-5 h-5 ${
                          (hoverRating || newRating) >= star
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-gray-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
                <span className="text-xs font-black text-amber-700 font-mono ml-2">
                  {newRating} / 5 Stars
                </span>
              </div>

              <textarea
                placeholder="Share your experience regarding item condition, communication speed, and escrow delivery..."
                value={newReviewText}
                onChange={(e) => setNewReviewText(e.target.value)}
                rows={2}
                required
                className="w-full bg-white border border-gray-200 rounded-lg p-2.5 text-xs text-gray-800 focus:outline-none focus:ring-1 focus:ring-[#b08865] font-medium"
              />

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
                {reviewSuccessMsg ? (
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-lg border border-emerald-200">
                    ✓ {reviewSuccessMsg}
                  </span>
                ) : (
                  <span className="text-[10px] text-gray-400 font-bold">
                    Reviews build community trust in our marketplace.
                  </span>
                )}

                <button
                  type="submit"
                  disabled={reviewSubmitting || !newReviewText.trim()}
                  className="bg-[#3e3023] hover:bg-[#291f17] disabled:opacity-50 text-yellow-300 font-bold text-xs py-2 px-4 rounded-lg transition cursor-pointer shadow-xs shrink-0"
                >
                  {reviewSubmitting ? 'Posting...' : 'Post Rating & Review'}
                </button>
              </div>
            </form>

            {/* List of Recent Seller Reviews */}
            <div className="flex flex-col gap-3">
              <h5 className="text-xs font-black text-gray-400 uppercase tracking-wider">
                Recent Buyer Reviews ({reviewsList.length})
              </h5>

              {reviewsLoading ? (
                <div className="text-center py-4 text-xs text-gray-400 font-bold animate-pulse">
                  Loading buyer feedback...
                </div>
              ) : reviewsList.length === 0 ? (
                <div className="text-center py-4 text-xs text-gray-400 font-medium bg-gray-50 rounded-xl">
                  No seller reviews posted yet. Be the first to rate {listing.sellerName}!
                </div>
              ) : (
                <div className="flex flex-col gap-2.5">
                  {reviewsList.map((rev) => (
                    <div key={rev.id} className="p-3.5 bg-gray-50/70 rounded-xl border border-gray-100 flex flex-col gap-1.5 text-left">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-gray-800">{rev.buyerName}</span>
                          {rev.transactionCompleted && (
                            <span className="text-[9px] bg-green-100 text-green-800 font-black px-1.5 py-0.5 rounded uppercase">
                              ✓ Verified Purchase
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-gray-400 font-semibold">
                          {new Date(rev.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3.5 h-3.5 ${
                              i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>

                      <p className="text-xs text-gray-700 font-medium leading-relaxed">
                        {rev.reviewText}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Category Pricing Trends Chart */}
          <div className="mb-6 p-5 bg-white border border-gray-200 rounded-2xl flex flex-col gap-4 shadow-3xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-gray-100">
              <div className="flex items-center gap-2 text-left">
                <div className="bg-[#3db83a]/10 text-[#3db83a] p-2.5 rounded-xl">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-gray-800 uppercase tracking-wider">Market Price Trend (30 Days)</h4>
                  <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">
                    Category: {listing.categoryName} • {listing.subCategory}
                  </p>
                </div>
              </div>
              <div className="text-left sm:text-right shrink-0">
                <span className="text-[9px] text-gray-400 font-bold block uppercase tracking-wider">Avg Market Price</span>
                <span className="text-sm font-black text-[#3db83a]">
                  {currencySymbol} {Math.round(listing.price * 0.95).toLocaleString()}
                </span>
              </div>
            </div>

            <p className="text-xs text-gray-500 font-medium leading-relaxed text-left">
              This interactive trend shows daily average historical pricing for <strong className="text-gray-700">{listing.subCategory}</strong> inside the <strong className="text-gray-700">{listing.country || 'Ghana'}</strong> marketplace. Compare this with your item's current pricing to target high-speed conversions.
            </p>

            <div className="w-full h-56 mt-2 relative select-none">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={generatePriceTrendData(listing.price)}
                  margin={{ top: 10, right: 10, left: 10, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f1f1" vertical={false} />
                  <XAxis 
                    dataKey="name" 
                    stroke="#a3a3a3" 
                    fontSize={10}
                    fontWeight="bold"
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis 
                    stroke="#a3a3a3" 
                    fontSize={10}
                    fontWeight="bold"
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(val) => `${currencySymbol}${val}`}
                    domain={['auto', 'auto']}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#fff', 
                      borderColor: '#f1f1f1',
                      borderRadius: '12px',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
                      fontSize: '11px',
                      fontWeight: 'bold'
                    }}
                    formatter={(value: any, name: string) => {
                      const label = name === 'avgPrice' ? 'Market Average' : "This Ad's Price";
                      return [`${currencySymbol} ${Number(value).toLocaleString()}`, label];
                    }}
                  />
                  <Legend 
                    verticalAlign="top" 
                    height={36} 
                    iconType="circle"
                    iconSize={8}
                    wrapperStyle={{ fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '0.5px' }}
                  />
                  <Line 
                    name="avgPrice"
                    type="monotone" 
                    dataKey="avgPrice" 
                    stroke="#3db83a" 
                    strokeWidth={3}
                    dot={{ r: 4, strokeWidth: 1 }}
                    activeDot={{ r: 6 }}
                  />
                  <Line 
                    name="currentItemPrice"
                    type="step" 
                    dataKey="currentItemPrice" 
                    stroke="#ff7c00" 
                    strokeDasharray="4 4"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-amber-50/50 border border-amber-100 rounded-xl p-3 flex items-start gap-2.5 text-left text-xs">
              <Info className="w-4.5 h-4.5 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-amber-800 font-semibold leading-relaxed">
                {listing.price < Math.round(listing.price * 0.95) ? (
                  <span>🔥 <strong>Great Bargain:</strong> Your item is priced <strong>below</strong> the current 30-day market average! This makes it highly competitive and likely to sell within 48 hours.</span>
                ) : (
                  <span>💡 <strong>Pricing Recommendation:</strong> To speed up your sale, consider dropping your price to <strong>{currencySymbol} {Math.round(listing.price * 0.95).toLocaleString()}</strong> to align closer with recent category transaction data.</span>
                )}
              </div>
            </div>
          </div>

          {/* GPS Location & Digital Address */}
          <div className="mb-6 p-4 bg-gray-50/50 border border-gray-100 rounded-2xl flex flex-col gap-3">
            <div className="flex justify-between items-center pb-2 border-b border-gray-100">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-[#b08865]" />
                <h4 className="text-xs font-black text-gray-800 uppercase tracking-wider">Verified GPS & Location</h4>
              </div>
              {listing.gpsAddress && (
                <span className="text-[10px] font-black tracking-wider text-white uppercase bg-[#b08865] px-2 py-0.5 rounded-md">
                  {listing.gpsAddress}
                </span>
              )}
            </div>

            {/* Live Interactive Map Component */}
            <MapComponent 
              country={listing.country}
              region={listing.region}
              neighborhood={listing.neighborhood}
              gpsCoordinates={listing.gpsCoordinates}
              gpsAddress={listing.gpsAddress}
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-1">
              <div className="flex flex-col gap-1 text-xs">
                <span className="text-gray-400 font-bold uppercase text-[9px] tracking-wider">GPS Digital Address</span>
                <span className="font-extrabold text-gray-800 text-sm">{listing.gpsAddress || "Not Provided"}</span>
              </div>
              <div className="flex flex-col gap-1 text-xs">
                <span className="text-gray-400 font-bold uppercase text-[9px] tracking-wider">Coordinates (Latitude, Longitude)</span>
                <span className="font-extrabold text-gray-700 text-xs">
                  {listing.gpsCoordinates 
                    ? `${listing.gpsCoordinates.latitude.toFixed(6)}, ${listing.gpsCoordinates.longitude.toFixed(6)}` 
                    : "Not Provided"}
                </span>
              </div>
            </div>

            {listing.gpsCoordinates && (
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${listing.gpsCoordinates.latitude},${listing.gpsCoordinates.longitude}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white hover:bg-gray-50 border border-gray-200 hover:border-[#b08865] text-[#3e3023] font-bold py-2.5 px-4 rounded-xl text-xs transition text-center flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
              >
                <MapPin className="w-3.5 h-3.5 text-red-500 animate-bounce" />
                <span>Open in Google Maps / Navigate</span>
              </a>
            )}
          </div>

          {/* Access Original Pictures Upload Details */}
          {listing.originalImagesMetadata && listing.originalImagesMetadata.length > 0 && (
            <div className="mb-6 p-4 bg-gray-50/50 border border-gray-100 rounded-2xl flex flex-col gap-3">
              <div className="flex items-center gap-1.5 pb-2 border-b border-gray-100">
                <Image className="w-4 h-4 text-[#b08865]" />
                <h4 className="text-xs font-black text-gray-800 uppercase tracking-wider">Original Photos & RAW Metadata</h4>
              </div>

              <div className="flex flex-col gap-2">
                {listing.originalImagesMetadata.map((img, idx) => (
                  <div key={idx} className="flex justify-between items-center text-xs bg-white p-2.5 rounded-xl border border-gray-100/80 shadow-3xs hover:border-[#b08865]/30 transition">
                    <div className="flex items-center gap-2.5 overflow-hidden">
                      <span className="text-base">📄</span>
                      <div className="flex flex-col overflow-hidden">
                        <span className="font-bold text-gray-800 truncate text-xs">{img.name}</span>
                        <span className="text-[10px] text-gray-400 font-semibold uppercase">{img.size} • {img.type.split('/')[1]?.toUpperCase()}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        setActiveImageIndex(idx);
                        setIsZoomOpen(true);
                      }}
                      className="shrink-0 bg-gray-100 hover:bg-[#b08865]/10 text-gray-700 hover:text-[#b08865] font-black text-[10px] px-2.5 py-1.5 rounded-lg transition active:scale-95 cursor-pointer"
                    >
                      View Original
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}


        </div>

        {/* RIGHT COLUMN: Contact, Seller Information & Security */}
        <div className="w-full md:w-80 bg-gray-50/50 p-4 sm:p-6 flex flex-col gap-5">
          {/* Seller Profile Card */}
          <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-xs">
            <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">
              Seller Profile
            </h4>
            <div className="flex items-center gap-3 mb-4">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80"
                alt={listing.sellerName}
                referrerPolicy="no-referrer"
                className="w-12 h-12 rounded-full object-cover border border-gray-200 shadow-inner shrink-0"
              />
              <div className="overflow-hidden">
                <h4 className="font-extrabold text-gray-800 text-sm truncate leading-snug">
                  {listing.sellerName}
                </h4>
                {sellerStats.isVerified ? (
                  <div className="flex items-center gap-1 text-xs text-green-600 font-extrabold mt-0.5 bg-green-50 px-1.5 py-0.5 rounded-md w-fit">
                    <ShieldCheck className="w-3.5 h-3.5 shrink-0 text-green-500" />
                    <span>Verified Seller</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1 text-xs text-gray-500 font-semibold mt-0.5 bg-gray-50 px-1.5 py-0.5 rounded-md w-fit">
                    <UserCheck className="w-3.5 h-3.5 shrink-0 text-gray-400" />
                    <span>Active Seller</span>
                  </div>
                )}
              </div>
            </div>

            {/* Seller Quick Stats */}
            <div className="grid grid-cols-2 gap-2 border-t border-gray-50 pt-3 text-center mb-1">
              <div className="bg-gray-50 rounded-lg p-2 flex flex-col">
                <span className="text-[9px] text-gray-400 font-bold uppercase">Feedback ★</span>
                <span className="text-xs font-extrabold text-gray-800 flex items-center justify-center gap-0.5 mt-0.5">
                  <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                  {sellerRating} ({reviewsCount})
                </span>
              </div>
              <div className="bg-gray-50 rounded-lg p-2 flex flex-col">
                <span className="text-[9px] text-gray-400 font-bold uppercase">Reputation</span>
                <span className="text-xs font-extrabold text-emerald-700 flex items-center justify-center gap-0.5 mt-0.5 font-mono">
                  <ShieldCheck className="w-3 h-3 text-emerald-600 shrink-0" />
                  {sellerReputationScore}%
                </span>
              </div>
            </div>

            {/* View Full Profile link */}
            <button
              onClick={() => setShowSellerOverlay(true)}
              className="mt-3 w-full bg-[#b08865]/10 hover:bg-[#b08865]/20 text-[#3e3023] py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>View Seller Profile & Ads</span>
            </button>
          </div>

          {/* Contact Action Panel */}
          <div className="flex flex-col gap-3">
            {/* Buy with Escrow Protection button */}
            <button
              onClick={() => setCheckoutOpen(true)}
              className="w-full bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white py-3.5 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition cursor-pointer shadow-md active:scale-98 transform"
            >
              <ShoppingBag className="w-5 h-5 text-yellow-300" />
              <span>Buy with Escrow Protection</span>
            </button>

            {/* Show Phone Number button */}
            <button
              onClick={() => setShowPhone(!showPhone)}
              className="w-full bg-[#b08865] hover:bg-[#937153] text-white py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition cursor-pointer shadow-xs active:scale-98"
            >
              <Phone className="w-4.5 h-4.5" />
              <span>{showPhone ? listing.sellerPhone : 'Show Contact Number'}</span>
            </button>

            {/* In-app Instant Chat message */}
            <button
              onClick={() => onInitiateChat(listing)}
              className="w-full bg-[#3e3023] hover:bg-[#291f17] text-white py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition cursor-pointer shadow-xs active:scale-98"
            >
              <MessageSquare className="w-4.5 h-4.5" />
              <span>Chat on Bozseller</span>
            </button>

            {/* Direct WhatsApp link */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full border border-green-200 hover:border-[#b08865] bg-green-50/50 hover:bg-green-50 text-[#3e3023] py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition text-center shadow-2xs"
            >
              <span className="bg-[#b08865] text-white w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black font-sans shrink-0">W</span>
              <span>Message on WhatsApp</span>
            </a>
          </div>

          {/* Collapsible In-Person Trading Safety Guidelines Section */}
          <div className="bg-amber-50/30 border border-[#eadecd] rounded-xl overflow-hidden shadow-2xs transition-all duration-300">
            {/* Header / Toggle Button */}
            <button
              onClick={() => setIsSafetyExpanded(!isSafetyExpanded)}
              className="w-full flex items-center justify-between p-4 bg-white/70 hover:bg-white transition cursor-pointer select-none"
            >
              <div className="flex items-center gap-2 text-[#3e3023]">
                <ShieldCheck className="w-5 h-5 text-[#b08865]" />
                <span className="font-extrabold text-sm tracking-tight text-left">In-Person Trading Safety Guidelines</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-[10px] font-black tracking-wider text-[#b08865] uppercase bg-[#faf8f5] px-2 py-0.5 rounded border border-[#eadecd]">
                  {activeCountry}
                </span>
                {isSafetyExpanded ? (
                  <ChevronUp className="w-4 h-4 text-gray-500" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-gray-500" />
                )}
              </div>
            </button>

            {/* Expandable Content Area */}
            {isSafetyExpanded && (
              <div className="p-4 border-t border-[#eadecd]/60 bg-white/40 flex flex-col gap-4 animate-in fade-in duration-200">
                {/* General Country-level Guidelines */}
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-gray-800">
                    <Info className="w-4 h-4 text-[#b08865]" />
                    <span>General Precautions ({activeCountry})</span>
                  </div>
                  <ul className="text-[11px] text-gray-600 font-medium leading-relaxed flex flex-col gap-2">
                    {tips.general.map((tip, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-[#b08865] mt-0.5 select-none font-bold">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Region-Specific Section */}
                {regionData && (
                  <div className="pt-3.5 border-t border-[#eadecd]/40 flex flex-col gap-3">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-gray-800">
                      <MapPin className="w-4 h-4 text-[#b08865]" />
                      <span>Recommended Meetup Spots in {activeRegionName}</span>
                    </div>
                    <p className="text-[10px] text-gray-500 leading-normal -mt-1 font-medium">
                      Insist on completing your trade at one of these well-lit, highly public, secure landmarks:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {regionData.safeSpots.map((spot, idx) => (
                        <span 
                          key={idx} 
                          className="bg-white border border-[#eadecd] text-[#7a5e45] text-[10px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 shadow-3xs"
                        >
                          <span className="text-yellow-500 select-none">📍</span>
                          <span>{spot}</span>
                        </span>
                      ))}
                    </div>

                    {/* Region-Specific Warnings */}
                    {regionData.warnings && regionData.warnings.length > 0 && (
                      <div className="mt-1 p-2.5 bg-red-50/50 border border-red-100 rounded-lg flex flex-col gap-1.5">
                        <div className="flex items-center gap-1 text-[10px] font-extrabold text-red-800 uppercase tracking-wider">
                          <AlertCircle className="w-3.5 h-3.5 text-red-600" />
                          <span>Local Area Warnings</span>
                        </div>
                        <ul className="text-[10px] text-red-700/90 font-semibold leading-relaxed flex flex-col gap-1">
                          {regionData.warnings.map((warn, idx) => (
                            <li key={idx} className="flex items-start gap-1">
                              <span className="text-red-500 select-none mr-1">•</span>
                              <span>{warn}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Social Share & Report */}
          <div className="flex justify-between items-center px-2 text-xs text-gray-400 font-bold mt-auto">
            <button 
              onClick={() => onToggleFavorite(listing.id)}
              className="flex items-center gap-1 hover:text-red-500 cursor-pointer transition"
            >
              <Star className={`w-4 h-4 ${isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
              <span>{isFavorite ? 'Saved Ad' : 'Save Ad'}</span>
            </button>
            <div className="flex gap-4">
              <button 
                onClick={() => {
                  const shareUrl = `${window.location.origin}?ad=${listing.id}`;
                  navigator.clipboard.writeText(shareUrl).then(() => {
                    setShowShareToast(true);
                  }).catch(() => {
                    // Fallback clipboard method
                    try {
                      const dummy = document.createElement('input');
                      document.body.appendChild(dummy);
                      dummy.value = shareUrl;
                      dummy.select();
                      document.execCommand('copy');
                      document.body.removeChild(dummy);
                      setShowShareToast(true);
                    } catch (err) {
                      console.error("Failed to copy link", err);
                    }
                  });
                }}
                className="flex items-center gap-1 hover:text-[#b08865] cursor-pointer transition"
              >
                <Share2 className="w-4 h-4" />
                <span>Share</span>
              </button>
              <button 
                onClick={() => setIsReporting(!isReporting)}
                className={`flex items-center gap-1 cursor-pointer transition ${isReporting ? 'text-red-500 font-bold' : 'hover:text-red-500'}`}
              >
                <AlertTriangle className="w-4 h-4" />
                <span>{isReporting ? 'Close Form' : 'Report'}</span>
              </button>
            </div>
          </div>

          {/* Inline Report Form */}
          {isReporting && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex flex-col gap-3 mt-2 animate-in slide-in-from-bottom-2 duration-200">
              <h5 className="text-xs font-black text-red-800 uppercase tracking-wider flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" />
                <span>Report Suspicious Ad</span>
              </h5>
              
              {reportSuccess ? (
                <div className="text-xs font-semibold text-green-700 flex flex-col gap-1">
                  <span className="font-bold">✓ Complaint Filed</span>
                  <p className="text-[10px] text-gray-500 leading-normal">Our moderator team has received your safety flag and will review this seller\'s credentials shortly.</p>
                </div>
              ) : (
                <div className="flex flex-col gap-2.5">
                  <div>
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-1">Reason</label>
                    <select
                      value={reportReason}
                      onChange={(e) => setReportReason(e.target.value)}
                      className="w-full bg-white border border-gray-200 rounded-lg p-1.5 text-xs text-gray-700 font-bold focus:outline-none focus:ring-1 focus:ring-red-500"
                    >
                      <option value="Suspicious Pricing / Fraud">Suspicious Pricing / Fraud</option>
                      <option value="Incorrect / Misleading Details">Incorrect / Misleading Details</option>
                      <option value="Stolen Photos / Counterfeit">Stolen Photos / Counterfeit</option>
                      <option value="Seller is Unresponsive / Rude">Seller is Unresponsive / Rude</option>
                      <option value="Inappropriate Content">Inappropriate Content</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-1">Additional Details</label>
                    <textarea
                      placeholder="Specify fraud, upfront deposit demands, stolen photos..."
                      value={reportDetails}
                      onChange={(e) => setReportDetails(e.target.value)}
                      rows={3}
                      required
                      className="w-full bg-white border border-gray-200 rounded-lg p-2 text-xs text-gray-700 focus:outline-none focus:ring-1 focus:ring-red-500 font-medium"
                    />
                  </div>

                  <button
                    type="button"
                    disabled={reportingSubmitting || !reportDetails.trim()}
                    onClick={async () => {
                      setReportingSubmitting(true);
                      try {
                        const res = await fetch(`/api/listings/${listing.id}/report`, {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({
                            reporterName: 'Kofi (Buyer)',
                            reason: reportReason,
                            details: reportDetails
                          })
                        });
                        if (res.ok) {
                          setReportSuccess(true);
                          setReportDetails('');
                        }
                      } catch (err) {
                        console.error(err);
                      } finally {
                        setReportingSubmitting(false);
                      }
                    }}
                    className="w-full bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-bold text-xs py-2 rounded-lg transition cursor-pointer"
                  >
                    {reportingSubmitting ? 'Submitting...' : 'Submit Flag'}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
        {/* End of Columns Wrapper */}
        </div>

        {/* SIMILAR LISTINGS FULL-WIDTH SECTION */}
        {similarListings.length > 0 && (
          <div className="bg-white p-6 sm:p-8 border-t border-gray-100 w-full" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-[#3db83a]" />
                  <h3 className="text-sm font-extrabold text-gray-800 uppercase tracking-wider">
                    Similar Listings in {listing.categoryName}
                  </h3>
                </div>
                <p className="text-xs text-gray-400 font-medium">
                  Other great options recommended based on your browsing category
                </p>
              </div>
              <span className="text-[10px] bg-green-50 text-[#3db83a] font-extrabold px-2.5 py-1 rounded-md border border-green-100">
                {similarListings.length} ITEMS FOUND
              </span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {similarListings.map(item => {
                const itemCountryConfig = COUNTRIES_CONFIG[item.country || 'Ghana'] || COUNTRIES_CONFIG['Ghana'];
                const itemCurrency = itemCountryConfig?.currency || 'GH₵';
                
                return (
                  <div 
                    key={item.id}
                    onClick={() => {
                      // Reset details and load the newly clicked item
                      setActiveImageIndex(0);
                      setShowPhone(false);
                      setIsReporting(false);
                      setReportSuccess(false);
                      setReportDetails('');
                      setLoading(true);

                      fetch(`/api/listings/${item.id}`)
                        .then(res => res.json())
                        .then(data => {
                          setListing(data);
                          setLoading(false);
                          
                          // Scroll to top of the modal container
                          const modalScrollable = document.querySelector('.overflow-y-auto');
                          if (modalScrollable) {
                            modalScrollable.scrollTo({ top: 0, behavior: 'smooth' });
                          }

                          // Fetch similar items in same category for this new listing
                          fetch(`/api/listings?categoryId=${data.categoryId}`)
                            .then(res2 => res2.json())
                            .then((similar: Listing[]) => {
                              setSimilarListings(similar.filter(x => x.id !== data.id).slice(0, 4));
                            })
                            .catch(err => console.error('Failed to load similar listings:', err));
                        })
                        .catch(err => {
                          console.error(err);
                          setLoading(false);
                        });
                    }}
                    className="group flex flex-col bg-gray-50/50 hover:bg-white border border-gray-100 hover:border-[#b08865]/30 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 shadow-2xs hover:shadow-md hover:-translate-y-0.5 text-left"
                  >
                    {/* Image Area */}
                    <div className="aspect-4/3 w-full overflow-hidden relative bg-gray-100">
                      <img 
                        src={item.imageUrls[0]} 
                        alt={item.title} 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                      />
                      {item.isFeatured && (
                        <div className="absolute top-2 left-2 bg-[#ff7c00] text-white text-[8px] font-black px-1.5 py-0.5 rounded-sm shadow-xs">
                          FEATURED
                        </div>
                      )}
                    </div>

                    {/* Info Area */}
                    <div className="p-3 flex flex-col flex-1">
                      <span className="text-[10px] text-[#b08865] font-black uppercase tracking-wider mb-1">
                        {item.subCategory || item.categoryName}
                      </span>
                      <h4 className="text-xs font-bold text-gray-800 line-clamp-2 leading-snug group-hover:text-[#b08865] transition flex-1">
                        {item.title}
                      </h4>
                      <div className="mt-2.5 pt-2 border-t border-gray-100/60 flex flex-col gap-0.5">
                        <span className="text-xs font-black text-[#3db83a]">
                          {itemCurrency} {item.price.toLocaleString()}
                        </span>
                        <div className="flex items-center gap-1 text-[9px] text-gray-400 font-bold truncate">
                          <MapPin className="w-3 h-3 text-gray-400 shrink-0" />
                          <span className="truncate">{item.region || item.neighborhood}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </motion.div>

      {/* FULL-SCREEN ZOOM LIGHTBOX / CAROUSEL MODAL */}
      {isZoomOpen && listing && (
        <div className="fixed inset-0 bg-black/95 z-[100] backdrop-blur-md flex flex-col justify-between p-4 md:p-6 select-none animate-in fade-in duration-200">
          
          {/* Header */}
          <div className="flex justify-between items-center text-white pb-3 border-b border-white/10 z-10">
            <div className="flex flex-col">
              <h3 className="text-sm font-bold text-gray-200 truncate max-w-[200px] sm:max-w-md">
                {listing.title}
              </h3>
              <p className="text-[11px] text-gray-400 font-medium">
                Photo {activeImageIndex + 1} of {listing.imageUrls.length}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={resetZoom}
                className="p-2 hover:bg-white/10 rounded-full text-gray-300 hover:text-white transition cursor-pointer"
                title="Reset view"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setIsZoomOpen(false)}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition cursor-pointer font-black"
                title="Close Lightbox (Esc)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Interactive Zoom Canvas Area */}
          <div 
            className={`flex-1 w-full flex items-center justify-center overflow-hidden relative my-4 ${
              zoomScale > 1 ? 'cursor-grab active:cursor-grabbing' : 'cursor-zoom-in'
            }`}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUpOrLeave}
            onMouseLeave={handleMouseUpOrLeave}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleMouseUpOrLeave}
            onClick={(e) => {
              // Only toggle zoom if clicked empty area at 100%
              if (zoomScale === 1 && e.target === e.currentTarget) {
                setZoomScale(2.5);
              }
            }}
          >
            {/* The Zoomable Image */}
            <div 
              className="w-full h-full flex items-center justify-center"
              style={{
                transform: `translate(${zoomOffset.x}px, ${zoomOffset.y}px) scale(${zoomScale})`,
                transition: isDragging ? 'none' : 'transform 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
              }}
              onDoubleClick={handleDoubleClick}
            >
              <img
                src={listing.imageUrls[activeImageIndex]}
                alt={listing.title}
                referrerPolicy="no-referrer"
                className="max-w-full max-h-[65vh] sm:max-h-[72vh] object-contain select-none pointer-events-none"
              />
            </div>

            {/* Carousel Side Arrows (Overlay) - Hidden when zoomed-in for clean panning */}
            {listing.imageUrls.length > 1 && zoomScale === 1 && (
              <>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveImageIndex(prev => (prev === 0 ? listing.imageUrls.length - 1 : prev - 1));
                    resetZoom();
                  }}
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-[#b08865] p-3 rounded-full text-white cursor-pointer transition shadow-xl hover:scale-105 active:scale-95 z-20"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveImageIndex(prev => (prev === listing.imageUrls.length - 1 ? 0 : prev + 1));
                    resetZoom();
                  }}
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-[#b08865] p-3 rounded-full text-white cursor-pointer transition shadow-xl hover:scale-105 active:scale-95 z-20"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              </>
            )}

            {/* floating controls overlay */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/75 backdrop-blur-md px-4.5 py-2 rounded-full border border-white/10 flex items-center gap-3.5 text-white shadow-2xl z-30">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setZoomScale(prev => {
                    const next = prev - 0.5;
                    if (next <= 1) { resetZoom(); return 1; }
                    return next;
                  });
                }}
                disabled={zoomScale <= 1}
                className="p-1 hover:bg-white/10 rounded-full disabled:opacity-30 disabled:hover:bg-transparent transition cursor-pointer"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              
              <span className="text-[11px] font-black tracking-widest min-w-[50px] text-center select-none">
                {Math.round(zoomScale * 100)}%
              </span>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setZoomScale(prev => Math.min(5, prev + 0.5));
                }}
                disabled={zoomScale >= 5}
                className="p-1 hover:bg-white/10 rounded-full disabled:opacity-30 disabled:hover:bg-transparent transition cursor-pointer"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>

              {zoomScale > 1 && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    resetZoom();
                  }}
                  className="pl-2 border-l border-white/20 text-yellow-400 hover:text-yellow-300 text-[10px] font-black uppercase tracking-wider transition cursor-pointer"
                >
                  Reset
                </button>
              )}
            </div>
          </div>

          {/* Bottom Thumbnail Navigation Strip inside Lightbox */}
          {listing.imageUrls.length > 1 && (
            <div className="flex gap-2 items-center justify-center overflow-x-auto py-3 border-t border-white/10 z-10 max-w-full">
              {listing.imageUrls.map((url, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setActiveImageIndex(idx);
                    resetZoom();
                  }}
                  className={`relative w-14 h-10 sm:w-16 sm:h-12 rounded-lg overflow-hidden border-2 shrink-0 transition-all ${
                    idx === activeImageIndex 
                      ? 'border-[#b08865] scale-95 shadow-lg shadow-[#b08865]/10 ring-2 ring-[#b08865]/30' 
                      : 'border-white/10 hover:border-white/35 opacity-45 hover:opacity-100'
                  }`}
                >
                  <img 
                    src={url} 
                    alt={`Lightbox Thumbnail ${idx + 1}`} 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover select-none" 
                  />
                  {idx === activeImageIndex && (
                    <div className="absolute inset-0 bg-[#b08865]/20" />
                  )}
                </button>
              ))}
            </div>
          )}

          {/* Help hints */}
          <div className="text-center text-[10px] text-gray-500 font-medium z-10">
            {zoomScale > 1 ? 'Drag/Swipe to pan photo • Double click to reset' : 'Pinch or use buttons to zoom • Click photo to zoom in'}
          </div>
        </div>
      )}

      {/* SELLER PROFILE OVERLAY */}
      <AnimatePresence>
        {showSellerOverlay && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4"
            onClick={() => setShowSellerOverlay(false)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="bg-white rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[85vh]"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header block with elegant design */}
              <div className="relative bg-[#faf8f5] p-6 border-b border-gray-100 flex flex-col items-center text-center">
                <button
                  onClick={() => setShowSellerOverlay(false)}
                  className="absolute top-4 right-4 p-2 bg-white/80 hover:bg-white text-gray-500 hover:text-gray-800 rounded-full shadow-xs transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>

                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80"
                  alt={listing.sellerName}
                  referrerPolicy="no-referrer"
                  className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-md mb-3"
                />

                <h3 className="text-lg font-black text-gray-800 tracking-tight flex items-center gap-1.5 justify-center">
                  <span>{listing.sellerName}</span>
                  {sellerStats.isVerified && (
                    <span className="bg-[#3db83a] text-white p-0.5 rounded-full flex items-center justify-center" title="Verified Seller">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </span>
                  )}
                </h3>

                {sellerStats.isVerified ? (
                  <span className="text-xs text-green-600 font-black tracking-widest uppercase mt-1 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Verified Bozseller Merchant</span>
                  </span>
                ) : (
                  <span className="text-xs text-gray-400 font-black tracking-widest uppercase mt-1">
                    Active Bozseller Member
                  </span>
                )}

                <div className="flex items-center gap-4 mt-3">
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Join Date</span>
                    <span className="text-xs font-extrabold text-gray-700 flex items-center gap-1 mt-0.5">
                      <Calendar className="w-3.5 h-3.5 text-[#b08865]" />
                      <span>{sellerStats.memberSince}</span>
                    </span>
                  </div>
                  <div className="h-6 w-px bg-gray-200"></div>
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Feedback Rating</span>
                    <span className="text-xs font-extrabold text-gray-700 flex items-center gap-1 mt-0.5">
                      <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                      <span>{sellerStats.rating} / 5.0</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Scrollable list of active listings */}
              <div className="p-6 overflow-y-auto flex-1 flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black text-gray-400 uppercase tracking-wider">
                    Other Active Ads ({sellerListings.length})
                  </h4>
                  <span className="text-[10px] text-gray-500 font-bold bg-gray-100 px-2 py-0.5 rounded-md">
                    Filter: Active Only
                  </span>
                </div>

                {sellerListingsLoading ? (
                  <div className="flex flex-col items-center justify-center py-10 gap-2">
                    <span className="w-6 h-6 border-2 border-[#b08865] border-t-transparent rounded-full animate-spin"></span>
                    <span className="text-xs text-gray-400 font-bold animate-pulse">Retrieving active catalog...</span>
                  </div>
                ) : sellerListings.length === 0 ? (
                  <div className="text-center py-8 text-xs text-gray-400 font-bold">
                    No other active listings found.
                  </div>
                ) : (
                  <div className="flex flex-col gap-2.5">
                    {sellerListings.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => {
                          setLoading(true);
                          fetch(`/api/listings/${item.id}`)
                            .then(res => res.json())
                            .then(data => {
                              setListing(data);
                              setActiveImageIndex(0);
                              setShowSellerOverlay(false);
                              setLoading(false);
                            })
                            .catch(err => {
                              console.error(err);
                              setLoading(false);
                            });
                        }}
                        className={`flex gap-3 p-2.5 bg-gray-50 hover:bg-[#b08865]/5 border border-gray-100 rounded-2xl cursor-pointer transition-all duration-200 group active:scale-[0.98] ${
                          item.id === listing.id ? 'ring-2 ring-[#b08865] bg-[#b08865]/5' : ''
                        }`}
                      >
                        <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 border border-gray-200">
                          <img
                            src={item.imageUrls[0]}
                            alt={item.title}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                          />
                        </div>
                        <div className="flex flex-col justify-center overflow-hidden flex-1 text-left">
                          <span className="text-xs font-extrabold text-gray-800 truncate group-hover:text-[#b08865] transition leading-snug">
                            {item.title}
                          </span>
                          <span className="text-[11px] text-green-700 font-black mt-0.5">
                            {COUNTRIES_CONFIG[item.country || 'Ghana']?.currency || 'GH₵'} {item.price.toLocaleString()}
                          </span>
                          <div className="flex items-center gap-1.5 text-[9px] text-gray-400 font-bold uppercase tracking-wider mt-1">
                            <span className="truncate">{item.categoryName}</span>
                            <span>•</span>
                            <span className="truncate">{item.neighborhood}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="p-4 bg-gray-50 border-t border-gray-100 text-center text-[10px] text-gray-400 font-bold uppercase tracking-wider">
                Bozseller Safety Guaranteed & Verified Merchant
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* PRICE ALERT CREATION DIALOG */}
      {showPriceAlertModal && listing && (
        <div className="fixed inset-0 bg-black/60 z-[110] flex items-center justify-center p-4 backdrop-blur-xs animate-in fade-in duration-200">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white w-full max-w-md rounded-2xl overflow-hidden shadow-2xl border border-gray-100 flex flex-col"
          >
            {/* Header */}
            <div className="bg-[#3db83a] text-white p-5 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5 animate-pulse" />
                <h3 className="text-base font-black uppercase tracking-wider">Create Price Alert</h3>
              </div>
              <button
                onClick={() => setShowPriceAlertModal(false)}
                className="text-white/80 hover:text-white bg-white/10 hover:bg-white/20 p-1.5 rounded-full transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form Content */}
            <form onSubmit={handleCreatePriceAlert} className="p-6 flex flex-col gap-4">
              <div className="p-3.5 bg-gray-50 border border-gray-100 rounded-xl flex items-center gap-3 text-left">
                {listing.imageUrls?.[0] && (
                  <img
                    src={listing.imageUrls[0]}
                    alt={listing.title}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-lg object-cover border border-gray-200 shrink-0"
                  />
                )}
                <div className="flex-1 overflow-hidden">
                  <h4 className="text-xs font-black text-gray-800 truncate">{listing.title}</h4>
                  <p className="text-[11px] text-gray-500 font-bold mt-0.5">
                    Current Price: <span className="text-green-700">{currencySymbol} {listing.price.toLocaleString()}</span>
                  </p>
                </div>
              </div>

              <div className="flex flex-col gap-1.5 text-left">
                <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wider">
                  Target Price Threshold ({currencySymbol})
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm font-black select-none">
                    {currencySymbol}
                  </span>
                  <input
                    type="number"
                    value={targetPrice}
                    onChange={(e) => setTargetPrice(e.target.value)}
                    required
                    min="1"
                    className="w-full pl-9 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-extrabold text-gray-800 focus:outline-none focus:ring-2 focus:ring-[#3db83a]/30 focus:border-[#3db83a] transition"
                    placeholder="Enter target price threshold..."
                  />
                </div>
                <span className="text-[10px] text-gray-500 font-medium leading-relaxed mt-0.5">
                  We will track live listings and notify you instantly on your dashboard when a similar item is posted below this amount.
                </span>
              </div>

              {priceAlertCreated ? (
                <div className="bg-green-50 border border-green-100 rounded-xl p-4 flex items-center gap-2.5 text-xs text-green-800 font-extrabold animate-in zoom-in-95 duration-200 text-left">
                  <Check className="w-5 h-5 text-green-600 shrink-0" />
                  <div>
                    <p className="font-black">Price Alert Set Successfully!</p>
                    <p className="text-[10px] text-green-700/80 font-semibold mt-0.5">Monitoring live marketplace posts...</p>
                  </div>
                </div>
              ) : (
                <div className="flex gap-2.5 mt-2">
                  <button
                    type="button"
                    onClick={() => setShowPriceAlertModal(false)}
                    className="flex-1 border border-gray-200 hover:border-gray-300 bg-white text-gray-700 py-3 rounded-xl text-xs font-bold transition cursor-pointer text-center"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-[#3db83a] hover:bg-[#2fa82c] text-white py-3 rounded-xl text-xs font-black transition cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Bell className="w-4 h-4" />
                    <span>Set Alert</span>
                  </button>
                </div>
              )}
            </form>
          </motion.div>
        </div>
      )}

      {/* Checkout Escrow Modal */}
      {listing && (
        <CheckoutModal
          isOpen={checkoutOpen}
          onClose={() => setCheckoutOpen(false)}
          listing={listing}
          selectedCurrency={selectedCurrency}
        />
      )}
    </motion.div>
  );
}

