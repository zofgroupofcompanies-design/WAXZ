import React, { useState, useEffect } from 'react';
import { X, Check, Zap, ShieldCheck, Globe, CreditCard, Sparkles, AlertTriangle, ArrowRight, RefreshCw, CheckCircle2 } from 'lucide-react';
import { SubscriptionStatusResponse, CountryPriceConfig, SellerPlanType } from '../types';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  sellerId?: string;
  onSubscriptionUpdated?: () => void;
}

export default function SubscriptionModal({ isOpen, onClose, sellerId, onSubscriptionUpdated }: SubscriptionModalProps) {
  const [loading, setLoading] = useState(true);
  const [subData, setSubData] = useState<SubscriptionStatusResponse | null>(null);
  const [selectedCountryCode, setSelectedCountryCode] = useState<string>('GH');
  const [selectedProvider, setSelectedProvider] = useState<'paystack' | 'stripe' | 'flutterwave'>('paystack');
  const [autoRenew, setAutoRenew] = useState(true);
  const [processingPlan, setProcessingPlan] = useState<SellerPlanType | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const fetchSubscriptionData = async (countryCode?: string) => {
    try {
      setLoading(true);
      const token = localStorage.getItem('datazone4_jwt_token');
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      let url = '/api/seller/subscription';
      if (sellerId) url += `?sellerId=${sellerId}`;

      const res = await fetch(url, { headers });
      if (res.ok) {
        const data: SubscriptionStatusResponse = await res.json();
        setSubData(data);
        setSelectedCountryCode(countryCode || data.subscription.countryCode || 'GH');
      }
    } catch (err) {
      console.error('Failed to load seller subscription:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setSuccessMessage(null);
      setErrorMessage(null);
      fetchSubscriptionData();
    }
  }, [isOpen, sellerId]);

  const handleCountryChange = async (newCountryCode: string) => {
    setSelectedCountryCode(newCountryCode);
    try {
      const token = localStorage.getItem('datazone4_jwt_token');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/seller/country', {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ countryCode: newCountryCode, sellerId })
      });

      if (res.ok) {
        fetchSubscriptionData(newCountryCode);
      }
    } catch (err) {
      console.error('Failed to update country:', err);
    }
  };

  const handleCheckout = async (targetPlan: SellerPlanType) => {
    setProcessingPlan(targetPlan);
    setSuccessMessage(null);
    setErrorMessage(null);

    try {
      const token = localStorage.getItem('datazone4_jwt_token');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/seller/subscription/checkout', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          plan: targetPlan,
          countryCode: selectedCountryCode,
          paymentProvider: selectedProvider,
          autoRenew,
          sellerId
        })
      });

      const result = await res.json();

      if (res.ok && result.success) {
        setSuccessMessage(result.message);
        fetchSubscriptionData(selectedCountryCode);
        if (onSubscriptionUpdated) {
          onSubscriptionUpdated();
        }
      } else {
        setErrorMessage(result.message || 'Subscription checkout failed. Please try again.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An error occurred during checkout.');
    } finally {
      setProcessingPlan(null);
    }
  };

  const [showDroppedDropdown, setShowDroppedDropdown] = useState(false);

  const handleSimulateTrialExpire = async () => {
    try {
      const token = localStorage.getItem('datazone4_jwt_token');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/seller/subscription/simulate-trial-expire', {
        method: 'POST',
        headers,
        body: JSON.stringify({ sellerId })
      });
      const data = await res.json();
      if (res.ok) {
        setSuccessMessage(data.message);
        fetchSubscriptionData(selectedCountryCode);
        if (onSubscriptionUpdated) onSubscriptionUpdated();
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Simulation failed');
    }
  };

  const handleResetTrial = async () => {
    try {
      const token = localStorage.getItem('datazone4_jwt_token');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/seller/subscription/reset-trial', {
        method: 'POST',
        headers,
        body: JSON.stringify({ sellerId })
      });
      const data = await res.json();
      if (res.ok) {
        setSuccessMessage(data.message);
        fetchSubscriptionData(selectedCountryCode);
        if (onSubscriptionUpdated) onSubscriptionUpdated();
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Reset failed');
    }
  };

  if (!isOpen) return null;

  const currentCountry = subData?.availableCountries?.find(c => c.countryCode === selectedCountryCode) || subData?.countryConfig || {
    countryCode: 'GH',
    countryName: 'Ghana',
    currency: 'GHS',
    currencySymbol: 'GH₵',
    monthlyPrice: 50
  };

  const activeCount = subData?.activeProductsCount || 0;
  const productLimit = subData?.productLimit || 5;
  const currentPlan = subData?.subscription?.plan || 'free';
  const isMonthlyActive = currentPlan === 'monthly' && subData?.subscription?.status === 'active';
  const trialInfo = subData?.trialInfo;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] flex flex-col text-white overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 border-b border-emerald-900/50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white flex items-center gap-2">
                Seller Subscription Plans
                <span className="text-xs bg-emerald-500/20 text-emerald-300 font-bold px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                  Bozseller Pro
                </span>
              </h2>
              <p className="text-xs text-slate-300">
                Choose the right plan to expand your product catalog and grow sales
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          
          {/* Notifications */}
          {successMessage && (
            <div className="p-4 bg-emerald-950/80 border border-emerald-500/50 rounded-xl text-emerald-200 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-sm">Subscription Updated!</p>
                <p className="text-xs text-emerald-300 mt-0.5">{successMessage}</p>
              </div>
            </div>
          )}

          {errorMessage && (
            <div className="p-4 bg-rose-950/80 border border-rose-500/50 rounded-xl text-rose-200 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-sm">Action Failed</p>
                <p className="text-xs text-rose-300 mt-0.5">{errorMessage}</p>
              </div>
            </div>
          )}

          {/* Current Status Card */}
          <div className="p-4 bg-slate-800/80 rounded-xl border border-slate-700/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Your Current Plan:</span>
                <span className={`text-xs font-bold px-2.5 py-0.5 rounded-md ${
                  isMonthlyActive
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : currentPlan === 'trial'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 animate-pulse'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                }`}>
                  {isMonthlyActive 
                    ? 'Monthly Seller (100 Max)' 
                    : currentPlan === 'trial'
                    ? '7-Day Free Trial (100 Max)'
                    : 'Free Seller (5 Max)'}
                </span>
              </div>

              {/* Progress limit bar */}
              <div className="mt-3 w-full max-w-sm">
                <div className="flex items-center justify-between text-xs font-medium mb-1">
                  <span className="text-slate-300">Active Listings Usage:</span>
                  <span className="text-emerald-400 font-bold">{activeCount} / {productLimit} Products</span>
                </div>
                <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 ${
                      activeCount >= productLimit ? 'bg-rose-500' : activeCount >= productLimit * 0.8 ? 'bg-amber-400' : 'bg-emerald-400'
                    }`}
                    style={{ width: `${Math.min(100, (activeCount / productLimit) * 100)}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Country Selector */}
            <div className="w-full md:w-auto flex flex-col gap-1.5 border-t md:border-t-0 md:border-l border-slate-700 pt-3 md:pt-0 md:pl-4">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-emerald-400" />
                Select Billing Country & Currency:
              </label>
              <select
                value={selectedCountryCode}
                onChange={(e) => handleCountryChange(e.target.value)}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-hidden focus:border-emerald-500 font-medium"
              >
                {(subData?.availableCountries || []).map((c) => (
                  <option key={c.countryCode} value={c.countryCode}>
                    {c.countryName} ({c.currencySymbol} {c.monthlyPrice} {c.currency}/mo)
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* 7-DAY FREE SELLER TRIAL ACTIVE BANNER */}
          {currentPlan === 'trial' && (
            <div className="p-4 bg-gradient-to-r from-cyan-950/80 via-slate-900 to-emerald-950/80 border border-cyan-500/40 rounded-xl flex items-start gap-3 shadow-md animate-in fade-in duration-200">
              <Sparkles className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5 animate-pulse" />
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-black text-cyan-300">
                    7-Day Free Seller Trial Active ({trialInfo?.daysLeft ?? 7} Day{trialInfo?.daysLeft === 1 ? '' : 's'} Remaining)
                  </h4>
                  <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded-full border border-cyan-500/30 font-bold uppercase">
                    100 Max Products
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  As a new seller, you enjoy full Pro seller privileges for <strong>7 days</strong> with up to 100 product listings completely free. After 7 days, products must be upgraded to a monthly subscription plan. If you fail to subscribe, listings beyond the 5-item free limit will drop down from the active marketplace.
                </p>
              </div>
            </div>
          )}

          {/* DROPPED PRODUCTS ALERT (When 7-day trial expired and seller failed to subscribe) */}
          {(trialInfo?.droppedProductsCount ?? 0) > 0 && (
            <div className="p-4 bg-rose-950/70 border border-rose-500/60 rounded-xl space-y-3 shadow-md">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-sm font-black text-rose-200 flex items-center gap-2">
                    <span>7-Day Free Trial Expired — {trialInfo?.droppedProductsCount} Product(s) Dropped Down</span>
                    <span className="text-[10px] bg-rose-500/30 text-rose-300 px-2 py-0.5 rounded-full font-bold uppercase">
                      Action Required
                    </span>
                  </h4>
                  <p className="text-xs text-rose-200/90 leading-relaxed">
                    Your 7-day free trial has expired without an active subscription plan. Because the free tier limit is 5 items, your excess products have dropped down and are temporarily hidden from the public marketplace. Upgrade to the Monthly Plan to immediately restore all dropped products!
                  </p>
                </div>
              </div>

              {/* Collapsible Dropdown for Dropped Items */}
              <div className="pt-2 border-t border-rose-900/60">
                <button
                  type="button"
                  onClick={() => setShowDroppedDropdown(!showDroppedDropdown)}
                  className="text-xs font-bold text-rose-300 hover:text-rose-100 flex items-center gap-1.5 transition cursor-pointer"
                >
                  <span>{showDroppedDropdown ? 'Hide' : 'View'} Dropped Products ({trialInfo?.droppedProductsCount})</span>
                  <span>{showDroppedDropdown ? '▲' : '▼'}</span>
                </button>

                {showDroppedDropdown && (
                  <div className="mt-2.5 bg-slate-900/90 border border-rose-900/50 rounded-lg p-3 space-y-2 max-h-48 overflow-y-auto">
                    {(trialInfo?.droppedProducts || []).map((item) => (
                      <div key={item.id} className="flex items-center justify-between text-xs py-1.5 border-b border-slate-800 last:border-b-0">
                        <div>
                          <span className="font-bold text-white block">{item.title}</span>
                          <span className="text-[10px] text-rose-400">{item.droppedReason || 'Dropped due to trial expiry'}</span>
                        </div>
                        <span className="font-mono font-bold text-slate-300">
                          {currentCountry.currencySymbol} {item.price.toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Plan Comparison Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* Free Seller Plan */}
            <div className={`p-5 rounded-2xl border flex flex-col justify-between transition ${
              currentPlan === 'free'
                ? 'bg-slate-800/90 border-slate-600 shadow-md ring-1 ring-slate-500'
                : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
            }`}>
              <div>
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-black text-white">Free Seller</h3>
                  <span className="text-xs bg-slate-800 text-slate-300 px-2.5 py-1 rounded-full font-bold">
                    Starter
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">For casual sellers testing the marketplace</p>

                <div className="mt-4 mb-5">
                  <span className="text-3xl font-black text-white">$0</span>
                  <span className="text-xs text-slate-400 ml-1">/ forever</span>
                </div>

                <div className="space-y-2.5 text-xs text-slate-300 border-t border-slate-800 pt-4">
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>5 products maximum</strong> active listings</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Upload product pictures</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Create and edit up to 5 active product listings</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Manage seller profile and existing products</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Upgrade to the monthly plan at any time</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => handleCheckout('free')}
                disabled={processingPlan !== null || currentPlan === 'free'}
                className={`mt-6 w-full py-2.5 rounded-xl font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
                  currentPlan === 'free'
                    ? 'bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-700'
                    : 'bg-slate-700 hover:bg-slate-600 text-white'
                }`}
              >
                {currentPlan === 'free' ? 'Current Active Plan' : 'Switch to Free Plan'}
              </button>
            </div>

            {/* Monthly Seller Pro Plan */}
            <div className="p-5 rounded-2xl border bg-gradient-to-b from-slate-800/90 via-emerald-950/40 to-slate-900 border-emerald-500/50 shadow-xl relative overflow-hidden flex flex-col justify-between ring-1 ring-emerald-500/30">
              <div className="absolute top-3 right-3 bg-emerald-500 text-slate-950 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full tracking-wider shadow-xs">
                Recommended
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-black text-emerald-300 flex items-center gap-1.5">
                    Monthly Seller
                    <Sparkles className="w-4 h-4 text-yellow-400" />
                  </h3>
                </div>
                <p className="text-xs text-slate-300 mt-1">For high-volume merchants and professional shops</p>

                <div className="mt-4 mb-5 flex items-baseline gap-1.5">
                  <span className="text-3xl font-black text-white">
                    {currentCountry.currencySymbol} {currentCountry.monthlyPrice}
                  </span>
                  <span className="text-xs font-semibold text-emerald-400">
                    {currentCountry.currency} / month
                  </span>
                </div>

                <div className="space-y-2.5 text-xs text-slate-200 border-t border-emerald-900/60 pt-4">
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong className="text-emerald-300">100 products maximum</strong> active listings</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Everything included in the Free plan</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Upload product pictures & high-res photos</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Create and edit up to 100 active product listings</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Automatic monthly renewal supported by payment provider</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Return to free plan if cancelled, excess listings restricted to 5</span>
                  </div>
                </div>
              </div>

              {/* Checkout Controls */}
              <div className="mt-6 pt-4 border-t border-emerald-900/60 space-y-3">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="text-slate-300 font-medium">Payment Method:</span>
                  <div className="flex gap-1.5">
                    {(['paystack', 'stripe', 'flutterwave'] as const).map((provider) => (
                      <button
                        key={provider}
                        onClick={() => setSelectedProvider(provider)}
                        className={`px-2.5 py-1 rounded-md text-[10px] font-bold capitalize transition border cursor-pointer ${
                          selectedProvider === provider
                            ? 'bg-emerald-500/30 border-emerald-400 text-white'
                            : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {provider}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-300 font-medium">Billing Option:</span>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={autoRenew}
                      onChange={(e) => setAutoRenew(e.target.checked)}
                      className="accent-emerald-500 rounded-xs"
                    />
                    <span className="text-xs text-slate-300">Auto monthly renewal</span>
                  </label>
                </div>

                <button
                  onClick={() => handleCheckout('monthly')}
                  disabled={processingPlan !== null}
                  className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black text-sm rounded-xl shadow-lg shadow-emerald-950/50 transition cursor-pointer flex items-center justify-center gap-2 transform active:scale-98"
                >
                  {processingPlan === 'monthly' ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                      Activating Subscription...
                    </>
                  ) : isMonthlyActive ? (
                    <>
                      <RefreshCw className="w-4 h-4 text-slate-950" />
                      Renew Monthly Subscription ({currentCountry.currencySymbol} {currentCountry.monthlyPrice})
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 fill-slate-950" />
                      Upgrade to Monthly Seller ({currentCountry.currencySymbol} {currentCountry.monthlyPrice} {currentCountry.currency})
                    </>
                  )}
                </button>
              </div>

            </div>

          </div>

          {/* Provider & Security Assurance Note */}
          <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800 text-xs text-slate-400 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Payments are processed securely via encrypted payment provider gateways. You can upgrade, cancel, or switch plans at any time.</span>
            </div>
          </div>

        </div>

        {/* Footer with Trial Simulation controls */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-400 font-bold uppercase">7-Day Trial Simulator:</span>
            <button
              type="button"
              onClick={handleSimulateTrialExpire}
              className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg text-[10px] font-bold transition cursor-pointer"
              title="Fast-forward time to simulate trial expiration and product dropdown"
            >
              Simulate 7-Day Expire
            </button>
            <button
              type="button"
              onClick={handleResetTrial}
              className="px-2.5 py-1 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 rounded-lg text-[10px] font-bold transition cursor-pointer"
              title="Reset trial to 7 fresh days and restore dropped products"
            >
              Reset 7-Day Trial
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition cursor-pointer ml-auto"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
}
