import React, { useState } from 'react';
import { X, Lock, Mail, User, Shield, KeyRound, CheckCircle, AlertCircle, Loader2, Sparkles, UserCheck, ShieldAlert, ArrowRight, Copy, Check, Eye, EyeOff, Globe } from 'lucide-react';
import { AuthUser, UserRole } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AuthUser | null;
  onAuthSuccess: (user: AuthUser, token: string) => void;
  onLogout: () => void;
}

export default function AuthModal({
  isOpen,
  onClose,
  currentUser,
  onAuthSuccess,
  onLogout
}: AuthModalProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showToken, setShowToken] = useState(false);
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserRole>('buyer');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [copiedToken, setCopiedToken] = useState(false);
  const currentToken = localStorage.getItem('datazone4_jwt_token') || '';

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    const endpoint = isRegistering ? '/api/auth/register' : '/api/auth/login';
    const body = isRegistering
      ? { name, email, password, role }
      : { email, password };

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || data.error || 'Authentication failed');
      }

      setSuccess(data.message || (isRegistering ? 'Registration successful!' : 'Login successful!'));
      onAuthSuccess(data.user, data.token);

      setTimeout(() => {
        onClose();
        setSuccess(null);
      }, 1200);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async (demoEmail: string, demoPass: string) => {
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: demoEmail, password: demoPass })
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || 'Demo login failed');
      }

      setSuccess(`Authenticated as ${data.user.role.toUpperCase()} (${data.user.name})`);
      onAuthSuccess(data.user, data.token);

      setTimeout(() => {
        onClose();
        setSuccess(null);
      }, 1000);
    } catch (err: any) {
      setError(err.message || 'Failed to authenticate demo account.');
    } finally {
      setLoading(false);
    }
  };

  const copyTokenToClipboard = () => {
    if (!currentToken) return;
    navigator.clipboard.writeText(currentToken);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl border border-amber-900/10 w-full max-w-lg overflow-hidden flex flex-col my-auto max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="bg-[#3e3023] text-white p-5 flex items-center justify-between relative border-b border-amber-800/40">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#b08865] rounded-xl text-white shadow-inner">
              <Shield className="w-6 h-6 text-yellow-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg tracking-tight text-white flex items-center gap-2">
                <span>Bozseller Security & Auth</span>
                <span className="text-[10px] bg-yellow-400 text-green-950 font-black px-2 py-0.5 rounded-full uppercase">
                  JWT + Bcrypt
                </span>
              </h3>
              <p className="text-xs text-amber-200/80 font-medium mt-0.5">
                Role-Based Access Control (Admin, Buyer, Seller)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-amber-200/70 hover:text-white p-1.5 rounded-full hover:bg-[#4d3d2e] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          
          {/* Status Alert if logged in */}
          {currentUser ? (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-500 text-white rounded-lg font-bold">
                    <UserCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-emerald-950 text-sm">{currentUser.name}</h4>
                    <p className="text-xs text-emerald-700 font-medium">{currentUser.email}</p>
                  </div>
                </div>

                <span className={`text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider ${
                  currentUser.role === 'admin' 
                    ? 'bg-purple-600 text-white shadow-xs' 
                    : currentUser.role === 'seller'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-blue-600 text-white shadow-xs'
                }`}>
                  Role: {currentUser.role}
                </span>
              </div>

              {/* JWT Session Token Info with Masking */}
              {currentToken && (
                <div className="bg-white border border-emerald-200/80 rounded-lg p-3 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-gray-700 flex items-center gap-1">
                      <KeyRound className="w-3.5 h-3.5 text-amber-600" />
                      Encrypted Session Token (JWT)
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setShowToken(!showToken)}
                        className="text-[11px] font-bold text-gray-500 hover:text-gray-800 flex items-center gap-1 cursor-pointer"
                      >
                        {showToken ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        <span>{showToken ? 'Hide' : 'Reveal'}</span>
                      </button>
                      <button
                        onClick={copyTokenToClipboard}
                        className="text-[11px] font-bold text-amber-700 hover:text-amber-900 flex items-center gap-1 cursor-pointer"
                      >
                        {copiedToken ? <Check className="w-3 h-3 text-green-600" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedToken ? 'Copied' : 'Copy JWT'}</span>
                      </button>
                    </div>
                  </div>
                  <p className="font-mono text-[10px] text-gray-500 truncate bg-gray-50 p-1.5 rounded border border-gray-200">
                    {showToken ? currentToken : '••••••••••••••••••••••••••••••••••••••••••••••••••••••••'}
                  </p>
                </div>
              )}

              <button
                onClick={onLogout}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold text-xs py-2.5 rounded-lg transition cursor-pointer shadow-xs"
              >
                Sign Out / Clear Auth Token
              </button>
            </div>
          ) : (
            <>


              {/* Quick Preset Demo Login Accounts */}
              <div className="bg-amber-50/60 border border-amber-200/80 rounded-xl p-3.5">
                <span className="text-[11px] font-extrabold text-amber-900 uppercase tracking-wider block mb-2">
                  ⚡ One-Click Demo Role Accounts
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleDemoLogin('seller@datazone4.com', 'seller123')}
                    className="bg-amber-600 hover:bg-amber-700 text-white py-2 px-2 rounded-lg text-xs font-bold transition flex flex-col items-center justify-center gap-0.5 cursor-pointer shadow-xs"
                  >
                    <User className="w-3.5 h-3.5 text-amber-200" />
                    <span>Seller Role</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDemoLogin('buyer@datazone4.com', 'buyer123')}
                    className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-2 rounded-lg text-xs font-bold transition flex flex-col items-center justify-center gap-0.5 cursor-pointer shadow-xs"
                  >
                    <UserCheck className="w-3.5 h-3.5 text-blue-200" />
                    <span>Buyer Role</span>
                  </button>
                </div>
              </div>

              {/* Error and Success notifications */}
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2 font-medium">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {success && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2 font-medium">
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{success}</span>
                </div>
              )}

              {/* Login / Register Form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                {isRegistering && (
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">
                      Full Name
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        required={isRegistering}
                        placeholder="e.g. Kwame Mensah"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-[#b08865] focus:border-transparent outline-none"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                    <input
                      type="email"
                      required
                      placeholder="e.g. user@datazone4.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-[#b08865] focus:border-transparent outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    Password (Bcrypt Encrypted)
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-9 pr-10 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-[#b08865] focus:border-transparent outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600 cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {isRegistering && (
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">
                      Account Role / Permissions
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setRole('buyer')}
                        className={`py-2 px-3 rounded-lg border text-xs font-bold transition cursor-pointer text-center ${
                          role === 'buyer'
                            ? 'bg-blue-50 border-blue-500 text-blue-700 ring-2 ring-blue-500/20'
                            : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                        }`}
                      >
                        Buyer
                      </button>

                      <button
                        type="button"
                        onClick={() => setRole('seller')}
                        className={`py-2 px-3 rounded-lg border text-xs font-bold transition cursor-pointer text-center ${
                          role === 'seller'
                            ? 'bg-amber-50 border-amber-500 text-amber-700 ring-2 ring-amber-500/20'
                            : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                        }`}
                      >
                        Seller
                      </button>
                    </div>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-[#3e3023] hover:bg-[#2b2118] text-white font-bold text-sm py-2.5 rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  {loading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <span>{isRegistering ? 'Register Account' : 'Sign In'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              {/* Mode Toggle Link */}
              <div className="text-center pt-2 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsRegistering(!isRegistering);
                    setError(null);
                    setSuccess(null);
                  }}
                  className="text-xs font-bold text-[#b08865] hover:underline cursor-pointer"
                >
                  {isRegistering
                    ? 'Already have an account? Sign In'
                    : "Don't have an account? Register new account"}
                </button>
              </div>
            </>
          )}

        </div>

        {/* Footer info */}
        <div className="bg-gray-50 px-6 py-3 border-t border-gray-200/80 text-[11px] text-gray-500 font-medium flex items-center justify-between">
          <span>Cryptographic Bcrypt (Salt: 10) & JWT Secret</span>
          <span className="font-bold text-gray-700">Bozseller v1.0</span>
        </div>

      </div>
    </div>
  );
}
